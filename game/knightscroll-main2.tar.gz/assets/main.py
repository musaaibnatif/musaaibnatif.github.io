import asyncio
import pygame
import random
import math

from entity import (
    Entity, TreasureChest, Particle, Spark, DamageNumber, PowerUp,
    DemonicTower, LavaParticle, BOSS_VARIANTS, SHIELD_BLUE, CRIT_ORANGE,
    _get_font, _get_two_circle_glow, set_frame_ticks
)

pygame.init()

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = int(SCREEN_WIDTH * 0.8)
FPS = 60

try:
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SCALED, vsync=1)
except TypeError:
    try:
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SCALED)
    except Exception:
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
except Exception:
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

pygame.display.set_caption("A Knight's Last Stand")
clock = pygame.time.Clock()

# Fantasy palette
BG_VOID = (8, 6, 10)
BG_IRON = (24, 22, 30)
BG_STONE = (38, 34, 44)
PARCHMENT = (240, 222, 184)
PARCH_DIM = (190, 170, 130)
PARCH_QUIET = (130, 115, 88)
GILT = (220, 174, 88)
GILT_BRIGHT = (255, 220, 130)
GILT_DEEP = (130, 96, 40)
RUNE_RED = (200, 60, 50)
HP_GOOD = (130, 195, 135)
HP_MID = (220, 180, 90)
HP_LOW = (200, 70, 70)
SPEED_C = (90, 220, 240)
DMG_C = (255, 130, 80)
SHIELD_C = (150, 200, 255)
FURY_C = (245, 110, 70)
BLACK = (0, 0, 0)

font_display = _get_font(40)
font_h1 = _get_font(28)
font_h2 = _get_font(20)
font_body = _get_font(15)
font_label = _get_font(12)
font_caption = _get_font(10)

_TEXT_CACHE = {}
_TEXT_CACHE_LIMIT = 512


def get_text(font, text, color):
    key = (id(font), str(text), color)
    surf = _TEXT_CACHE.get(key)
    if surf is not None:
        return surf
    surf = font.render(str(text), True, color).convert_alpha()
    if len(_TEXT_CACHE) >= _TEXT_CACHE_LIMIT:
        _TEXT_CACHE.pop(next(iter(_TEXT_CACHE)))
    _TEXT_CACHE[key] = surf
    return surf


_FULLSCREEN_OVERLAY = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA).convert_alpha()
# OPT: cache the last-used rgba so the death/pause/victory overlays — which
# call this every frame with a constant color — don't re-fill 800k pixels on
# every single frame. The final-animation overlays vary, so they'll just
# refill when the color changes (same cost as before, no regression).
_LAST_OVERLAY_RGBA = None


def blit_fullscreen_overlay(surface, rgba):
    global _LAST_OVERLAY_RGBA
    if rgba != _LAST_OVERLAY_RGBA:
        _FULLSCREEN_OVERLAY.fill(rgba)
        _LAST_OVERLAY_RGBA = rgba
    surface.blit(_FULLSCREEN_OVERLAY, (0, 0))

# Background
try:
    bg_image = pygame.image.load("img/Background/Background.png").convert()
    bg_tile = pygame.transform.scale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
except Exception:
    bg_tile = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        col = (int(18 + 15 * t), int(20 + 24 * t), int(28 + 14 * t))
        pygame.draw.line(bg_tile, col, (0, y), (SCREEN_WIDTH, y))


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_color(c1, c2, t):
    return (int(lerp(c1[0], c2[0], t)), int(lerp(c1[1], c2[1], t)), int(lerp(c1[2], c2[2], t)))


def build_atmosphere_overlay():
    surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        if t < 0.4:
            a = int(35 * (1 - t / 0.4))
            c = (60, 80, 110, a)
        elif t > 0.7:
            a = int(45 * ((t - 0.7) / 0.3))
            c = (10, 12, 18, a)
        else:
            c = (0, 0, 0, 0)
        pygame.draw.line(surf, c, (0, y), (SCREEN_WIDTH, y))
    return surf.convert_alpha()


ATMOSPHERE = build_atmosphere_overlay()
_HELL_BG = None
_PANEL_CACHE = {}
# OPT: persistent surface used for the hellscape fade-in. The original code
# called `get_hell_bg().copy()` every frame the hellscape was partially
# visible — that's a 1000x800 surface allocated + copied every frame. We now
# build a *display-format* alpha-capable copy once and just call set_alpha.
_HELL_BG_FADE = None


def _get_hell_bg_fade():
    """Return a single persistent surface that is the hellscape with set_alpha
    capability. Set the alpha on the returned surface before blitting."""
    global _HELL_BG_FADE
    if _HELL_BG_FADE is None:
        # Convert to a display-compatible per-pixel alpha format so set_alpha
        # works alongside any existing alpha. One-time copy, never reallocated.
        base = get_hell_bg()
        _HELL_BG_FADE = base.copy().convert_alpha()
    return _HELL_BG_FADE


def build_hellscape_bg():
    surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        if t < 0.35:
            c = lerp_color((35, 8, 8), (140, 35, 18), t / 0.35)
        elif t < 0.55:
            c = lerp_color((140, 35, 18), (220, 80, 30), (t - 0.35) / 0.20)
        elif t < 0.75:
            c = lerp_color((220, 80, 30), (90, 25, 15), (t - 0.55) / 0.20)
        else:
            c = lerp_color((90, 25, 15), (15, 5, 5), (t - 0.75) / 0.25)
        pygame.draw.line(surf, c, (0, y), (SCREEN_WIDTH, y))

    horizon = int(SCREEN_HEIGHT * 0.55)
    for offset in range(-3, 4):
        alpha = max(0, 80 - abs(offset) * 25)
        line_surf = pygame.Surface((SCREEN_WIDTH, 1), pygame.SRCALPHA)
        line_surf.fill((255, 180, 80, alpha))
        surf.blit(line_surf, (0, horizon + offset))

    ground_y = int(SCREEN_HEIGHT * 0.8)
    pygame.draw.rect(surf, (18, 8, 8), (0, ground_y, SCREEN_WIDTH, SCREEN_HEIGHT - ground_y))
    rng = random.Random(99)
    for _ in range(7):
        cx = rng.randint(20, SCREEN_WIDTH - 20)
        cy = rng.randint(ground_y + 15, SCREEN_HEIGHT - 15)
        pts = [(cx, cy)]
        for _ in range(rng.randint(3, 5)):
            cx += rng.randint(-25, 25)
            cy += rng.randint(-6, 6)
            pts.append((cx, cy))
        for i in range(len(pts) - 1):
            pygame.draw.line(surf, (255, 90, 30), pts[i], pts[i + 1], 3)
            pygame.draw.line(surf, (255, 220, 120), pts[i], pts[i + 1], 1)
    return surf.convert()


def get_hell_bg():
    global _HELL_BG
    if _HELL_BG is None:
        _HELL_BG = build_hellscape_bg()
    return _HELL_BG


def draw_world_bg(surface, scroll_offset, hell_amount):
    if hell_amount >= 0.999:
        surface.blit(get_hell_bg(), (0, 0))
        return
    # OPT: only 2 tiles can ever be visible on a SCREEN_WIDTH-sized viewport.
    # The original blitted 3 (one always fully off-screen). Unrolled into a
    # static tuple so pygame doesn't have to consume a generator every frame.
    base_x = int(scroll_offset // SCREEN_WIDTH) * SCREEN_WIDTH - scroll_offset
    surface.blits(
        ((bg_tile, (base_x, 0)),
         (bg_tile, (base_x + SCREEN_WIDTH, 0))),
        doreturn=False,
    )
    surface.blit(ATMOSPHERE, (0, 0))
    if hell_amount > 0:
        # OPT: was `get_hell_bg().copy()` then set_alpha — that's a fresh
        # screen-sized (1000x800) surface allocation + memcpy every frame
        # the hellscape was partially visible. Now reuses one persistent
        # surface; only set_alpha varies.
        hell = _get_hell_bg_fade()
        hell.set_alpha(int(255 * hell_amount))
        surface.blit(hell, (0, 0))


def build_fantasy_panel(w, h):
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(surf, (4, 3, 6, 230), (2, 2, w, h))
    pygame.draw.rect(surf, BG_IRON, (0, 0, w, h))
    pygame.draw.line(surf, BG_STONE, (1, 1), (w - 2, 1), 1)
    pygame.draw.line(surf, BG_STONE, (1, 1), (1, h - 2), 1)
    pygame.draw.line(surf, BG_VOID, (w - 1, 0), (w - 1, h - 1), 1)
    pygame.draw.line(surf, BG_VOID, (0, h - 1), (w - 1, h - 1), 1)
    inset = 6
    pygame.draw.rect(surf, BG_VOID, (inset, inset, w - inset * 2, h - inset * 2))
    pygame.draw.rect(surf, GILT_DEEP, (inset, inset, w - inset * 2, h - inset * 2), 1)

    def corner(cx, cy, dx, dy):
        pygame.draw.line(surf, GILT, (cx, cy), (cx + 14 * dx, cy), 2)
        pygame.draw.line(surf, GILT, (cx, cy), (cx, cy + 14 * dy), 2)
        pygame.draw.circle(surf, GILT_BRIGHT, (cx, cy), 2)
        pygame.draw.circle(surf, RUNE_RED, (cx, cy), 1)

    corner(2, 2, 1, 1)
    corner(w - 3, 2, -1, 1)
    corner(2, h - 3, 1, -1)
    corner(w - 3, h - 3, -1, -1)
    return surf.convert_alpha()


def get_panel(w, h):
    key = (w, h)
    if key not in _PANEL_CACHE:
        _PANEL_CACHE[key] = build_fantasy_panel(w, h)
    return _PANEL_CACHE[key]


def draw_panel(surface, x, y, w, h):
    surface.blit(get_panel(w, h), (x, y))


# OPT: pre-render static HUD labels. These never change, so re-rendering them
# every frame at 60 FPS was hundreds of font_caption.render calls per second
# for no reason.
_LABEL_VITALITY = font_caption.render("VITALITY", True, GILT_BRIGHT).convert_alpha()
_LABEL_VALOR = font_caption.render("VALOR", True, PARCH_QUIET).convert_alpha()
_LABEL_MARCH = font_caption.render("MARCH", True, PARCH_QUIET).convert_alpha()
_LABEL_TOWERS = font_caption.render("EXORCISM TOWERS", True, GILT_BRIGHT).convert_alpha()
_LABEL_NEXT = font_caption.render("NEXT", True, PARCH_QUIET).convert_alpha()
_LABEL_SOULS = font_caption.render("SOULS BOUND", True, PARCH_QUIET).convert_alpha()


def draw_hud(surface, player, distance):
    x, y, w, h = 12, 12, 290, 134
    draw_panel(surface, x, y, w, h)
    pad = 18
    surface.blit(_LABEL_VITALITY, (x + pad, y + 12))

    bar_x, bar_y, bar_w, bar_h = x + pad, y + 28, w - pad * 2, 12
    ratio = max(0, min(1, player.health / player.max_health))
    pygame.draw.rect(surface, GILT_DEEP, (bar_x - 2, bar_y - 2, bar_w + 4, bar_h + 4))
    pygame.draw.rect(surface, (40, 12, 12), (bar_x, bar_y, bar_w, bar_h))
    hp_color = HP_GOOD if ratio > 0.6 else (HP_MID if ratio > 0.3 else HP_LOW)
    pygame.draw.rect(surface, hp_color, (bar_x, bar_y, int(bar_w * ratio), bar_h))
    pygame.draw.line(surface, GILT_BRIGHT, (bar_x, bar_y), (bar_x + bar_w, bar_y), 1)
    hp_text = get_text(font_label, f"{int(player.health)} / {player.max_health}", PARCHMENT)
    surface.blit(hp_text, (bar_x + bar_w // 2 - hp_text.get_width() // 2, bar_y + bar_h // 2 - hp_text.get_height() // 2))

    div_y = bar_y + bar_h + 12
    pygame.draw.line(surface, GILT_DEEP, (x + 16, div_y), (x + w - 16, div_y), 1)
    dx = x + w // 2
    pygame.draw.polygon(surface, GILT, [(dx, div_y - 3), (dx + 4, div_y), (dx, div_y + 3), (dx - 4, div_y)])

    row_y = div_y + 8
    surface.blit(_LABEL_VALOR, (x + pad, row_y))
    score = get_text(font_h1, str(player.score), GILT)
    surface.blit(score, (x + pad, row_y + 12))
    surface.blit(_LABEL_MARCH, (x + w - pad - 80, row_y))
    dist = get_text(font_h2, f"{distance}m", PARCHMENT)
    surface.blit(dist, (x + w - pad - dist.get_width(), row_y + 14))


def draw_shrine_tracker(surface, shrines_activated, total_shrines, next_dist_m):
    x, y, w, h = 12, 156, 290, 56
    draw_panel(surface, x, y, w, h)
    pad = 16
    surface.blit(_LABEL_TOWERS, (x + pad, y + 10))
    if next_dist_m is not None and next_dist_m > 0:
        val = get_text(font_label, f"{next_dist_m}m", PARCHMENT)
        vx = x + w - pad - val.get_width()
        surface.blit(_LABEL_NEXT, (vx - _LABEL_NEXT.get_width() - 6, y + 10))
        surface.blit(val, (vx, y + 9))

    icon_y = y + 32
    spacing = 30
    start_x = x + w // 2 - ((total_shrines - 1) * spacing) // 2
    for i in range(total_shrines):
        ix = start_x + i * spacing
        if i < shrines_activated:
            pygame.draw.circle(surface, GILT, (ix, icon_y), 9)
            pygame.draw.circle(surface, BG_VOID, (ix, icon_y), 7)
            pygame.draw.line(surface, RUNE_RED, (ix, icon_y - 4), (ix, icon_y + 4), 2)
            pygame.draw.line(surface, RUNE_RED, (ix - 4, icon_y), (ix + 4, icon_y), 2)
            pygame.draw.circle(surface, GILT_BRIGHT, (ix, icon_y), 1)
        else:
            pygame.draw.circle(surface, GILT_DEEP, (ix, icon_y), 9)
            pygame.draw.circle(surface, BG_VOID, (ix, icon_y), 7)
            pygame.draw.line(surface, PARCH_QUIET, (ix, icon_y - 3), (ix, icon_y + 3), 1)
            pygame.draw.line(surface, PARCH_QUIET, (ix - 3, icon_y), (ix + 3, icon_y), 1)

_STRENGTH_TEXT_CACHE = {}


def get_strength_text_surface(text, max_width):
    key = (text, max_width)
    surf = _STRENGTH_TEXT_CACHE.get(key)
    if surf is not None:
        return surf

    # Try bigger first, then fall back until it fits the panel.
    for font in (font_label, font_caption):
        candidate = get_text(font, text, GILT_BRIGHT)
        if candidate.get_width() <= max_width:
            _STRENGTH_TEXT_CACHE[key] = candidate
            return candidate

    # Final safety: scale the cached caption surface instead of rerendering every frame.
    base = get_text(font_caption, text, GILT_BRIGHT)
    scale = max_width / max(1, base.get_width())
    new_size = (
        max(1, int(base.get_width() * scale)),
        max(1, int(base.get_height() * scale))
    )
    surf = pygame.transform.scale(base, new_size).convert_alpha()
    _STRENGTH_TEXT_CACHE[key] = surf
    return surf


def draw_strength_indicator(surface, player):
    if player.shrines_cleared <= 0:
        return

    # Taller box fixes vertical clipping with the heavier custom font.
    x, y, w, h = 12, 222, 290, 48
    draw_panel(surface, x, y, w, h)

    cx, cy = x + 22, y + h // 2
    pygame.draw.circle(surface, GILT, (cx, cy), 8)
    pygame.draw.circle(surface, BG_VOID, (cx, cy), 6)
    pygame.draw.line(surface, RUNE_RED, (cx, cy - 3), (cx, cy + 3), 2)
    pygame.draw.line(surface, RUNE_RED, (cx - 3, cy), (cx + 3, cy), 2)

    text_x = x + 38
    max_text_w = w - 54

    surface.blit(_LABEL_SOULS, (text_x, y + 9))

    strength_text = f"+{player.shrines_cleared * 8}% STRENGTH"
    value = get_strength_text_surface(strength_text, max_text_w)

    # Bottom-align inside the taller panel so tall glyphs do not get chopped.
    surface.blit(value, (text_x, y + h - value.get_height() - 8))


_POWERUP_SLOT_CACHE = {}
_POWERUP_TIMER_BADGE_CACHE = {}
_POWERUP_TIMER_BADGE_CACHE_LIMIT = 64


def get_powerup_timer_badge(secs):
    secs = max(1, int(secs))
    key = secs

    badge = _POWERUP_TIMER_BADGE_CACHE.get(key)
    if badge is not None:
        return badge

    timer_w, timer_h = 30, 16
    badge = pygame.Surface((timer_w, timer_h), pygame.SRCALPHA).convert_alpha()

    pygame.draw.rect(badge, BG_VOID, (0, 0, timer_w, timer_h))
    pygame.draw.rect(badge, GILT_DEEP, (0, 0, timer_w, timer_h), 1)

    num = get_text(font_label, str(secs), PARCHMENT)
    suffix = get_text(font_caption, "s", PARCH_DIM)

    num_x = 4
    num_y = timer_h // 2 - num.get_height() // 2 - 1
    suffix_x = timer_w - suffix.get_width() - 3
    suffix_y = timer_h - suffix.get_height() - 2

    badge.blit(num, (num_x, num_y))
    badge.blit(suffix, (suffix_x, suffix_y))

    if len(_POWERUP_TIMER_BADGE_CACHE) >= _POWERUP_TIMER_BADGE_CACHE_LIMIT:
        _POWERUP_TIMER_BADGE_CACHE.pop(next(iter(_POWERUP_TIMER_BADGE_CACHE)))

    _POWERUP_TIMER_BADGE_CACHE[key] = badge
    return badge

def get_powerup_slot(size):
    slot = _POWERUP_SLOT_CACHE.get(size)
    if slot is not None:
        return slot

    slot = pygame.Surface((size, size), pygame.SRCALPHA).convert_alpha()
    pygame.draw.rect(slot, BG_VOID, (0, 0, size, size))
    pygame.draw.rect(slot, BG_IRON, (2, 2, size - 4, size - 4))
    pygame.draw.rect(slot, GILT_DEEP, (0, 0, size, size), 1)
    pygame.draw.rect(slot, GILT, (3, 3, size - 6, size - 6), 1)
    pygame.draw.line(slot, GILT_BRIGHT, (4, 4), (size - 5, 4), 1)

    _POWERUP_SLOT_CACHE[size] = slot
    return slot

def draw_powerup_strip(surface, player):
    # Build the HUD from the player's actual timer attributes only.
    # Do not store active buffs in a separate list, because that is how duplicate icons happen.
    buff_defs = (
        ("speed", "speed_boost_timer", 60 * 10, SPEED_C),
        ("damage", "double_dmg_timer", 60 * 10, DMG_C),
        ("shield", "shield_timer", 60 * 10, SHIELD_C),
        ("fury", "fury_timer", 60 * 30, FURY_C),
    )

    icons = []
    seen = set()

    for kind, attr, max_t, color in buff_defs:
        timer = int(getattr(player, attr, 0))

        if timer <= 0:
            continue

        # Defensive dedupe. There should only ever be one entry per kind.
        if kind in seen:
            continue

        seen.add(kind)
        icons.append((kind, timer, max_t, color))

    if not icons:
        return

    size = 60
    gap = 10
    icon_size = 42

    x = SCREEN_WIDTH - (len(icons) * size + (len(icons) - 1) * gap) - 16
    y = 16

    slot = get_powerup_slot(size)

    for kind, timer, max_t, color in icons:
        ratio = min(1.0, timer / max_t)
        secs = max(1, math.ceil(timer / 60))

        surface.blit(slot, (x, y))

        icon = PowerUp.get_icon(kind, icon_size, glow=False)
        surface.blit(icon, (x + (size - icon_size) // 2, y + 5))

        badge = get_powerup_timer_badge(secs)
        surface.blit(
            badge,
            (
                x + (size - badge.get_width()) // 2,
                y + 42
            )
        )
        
        track_y = y + size - 5
        track_w = size - 8

        pygame.draw.rect(surface, BG_VOID, (x + 4, track_y, track_w, 3))
        pygame.draw.rect(surface, color, (x + 4, track_y, int(track_w * ratio), 3))

        x += size + gap

# OPT: pre-render static key-hint surfaces. The original `draw_keys` called
# font_label.render twice per hint (3 hints) every frame — 6 text renders per
# frame for static labels.
_KEY_HINTS_RENDERED = [
    (
        font_label.render(action, True, PARCH_DIM).convert_alpha(),
        font_label.render(key, True, PARCHMENT).convert_alpha(),
    )
    for key, action in [("WASD", "Move"), ("F", "Strike"), ("ESC", "Pause")]
]


def draw_keys(surface):
    y = SCREEN_HEIGHT - 32
    x = SCREEN_WIDTH - 14
    for act_text, key_text in reversed(_KEY_HINTS_RENDERED):
        key_w, key_h = key_text.get_width() + 16, 22
        x -= act_text.get_width()
        surface.blit(act_text, (x, y + 4))
        x -= key_w + 6
        pygame.draw.rect(surface, BG_VOID, (x, y, key_w, key_h))
        pygame.draw.rect(surface, BG_STONE, (x + 1, y + 1, key_w - 2, key_h - 2))
        pygame.draw.rect(surface, GILT_DEEP, (x, y, key_w, key_h), 1)
        pygame.draw.line(surface, GILT, (x + 2, y + 1), (x + key_w - 3, y + 1), 1)
        surface.blit(key_text, (x + 8, y + 4))
        x -= 18


# OPT: pre-rendered cheat message surfaces. Was being rendered fresh every
# frame the cheat message was visible (240 frames worth of redundant renders).
_CHEAT_TEXT = "ANCIENT POWER AWAKENED"

_CHEAT_MAIN = get_text(font_h2, _CHEAT_TEXT, GILT_BRIGHT)
_CHEAT_OUTLINE = get_text(font_h2, _CHEAT_TEXT, BLACK)
_CHEAT_X = SCREEN_WIDTH // 2 - _CHEAT_MAIN.get_width() // 2
_CHEAT_Y = 28
 

def draw_death_screen(surface, score, distance):
    blit_fullscreen_overlay(surface, (*BG_VOID, 200))
    title = get_text(font_display, "YOU HAVE FALLEN", HP_LOW)
    surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 150))
    card_w, card_h = 360, 100
    card_x, card_y = SCREEN_WIDTH // 2 - card_w // 2, SCREEN_HEIGHT // 2 - 70
    draw_panel(surface, card_x, card_y, card_w, card_h)
    pygame.draw.line(surface, GILT_DEEP, (card_x + card_w // 2, card_y + 14), (card_x + card_w // 2, card_y + card_h - 14), 1)
    for i, (name, value, color) in enumerate([("VALOR", str(score), GILT), ("MARCH", f"{distance}m", PARCHMENT)]):
        cx = card_x + card_w // 4 + i * card_w // 2
        lab = get_text(font_caption, name, PARCH_QUIET)
        val = get_text(font_h1, value, color)
        surface.blit(lab, (cx - lab.get_width() // 2, card_y + 22))
        surface.blit(val, (cx - val.get_width() // 2, card_y + 50))
    hint = get_text(font_h1, "Press R to rise again", GILT_BRIGHT)
    surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT // 2 + 75))


def draw_pause_screen(surface):
    blit_fullscreen_overlay(surface, (*BG_VOID, 160))
    title = get_text(font_display, "PAUSED", PARCHMENT)
    surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 70))
    hint = get_text(font_body, "Press ESC to resume", PARCH_DIM)
    surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT // 2 - 10))


def draw_victory_screen(surface):
    blit_fullscreen_overlay(surface, (*BG_VOID, 220))
    title = get_text(font_display, "THE DAMNED ARE FREED", GILT)
    surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 110))
    sub = get_text(font_body, "All exorcism towers have been activated.", PARCH_DIM)
    surface.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, SCREEN_HEIGHT // 2 - 60))
    hint = get_text(font_h1, "Press R to play again", GILT_BRIGHT)
    surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT // 2))

END_SEQUENCE_FRAMES = 420
_END_TEXT_OFFSETS = ((-2, 0), (2, 0), (0, -2), (0, 2), (-1, -1), (1, -1), (-1, 1), (1, 1))


def _ease_out_cubic(t):
    t = max(0.0, min(1.0, t))
    return 1.0 - (1.0 - t) ** 3


def _ease_in_cubic(t):
    t = max(0.0, min(1.0, t))
    return t ** 3


def _get_final_tower_screen_anchor(scroll_offset):
    for tower in towers:
        if getattr(tower, "is_final", False):
            return int(tower.world_x - scroll_offset), GROUND_Y - tower.HEIGHT // 2

    return SCREEN_WIDTH // 2, GROUND_Y - 120


def _draw_end_text(surface, text, y, size, color, shake=0):
    font = _get_font(size)
    txt = get_text(font, text, color)
    outline = get_text(font, text, BG_VOID)

    x = SCREEN_WIDTH // 2 - txt.get_width() // 2 + shake

    surface.blits(
        ((outline, (x + ox, y + oy)) for ox, oy in _END_TEXT_OFFSETS),
        doreturn=False
    )

    surface.blit(txt, (x, y))


def _draw_ending_eye(surface, x, y, size, phase, open_amount):
    if open_amount <= 0:
        pygame.draw.line(surface, (70, 0, 0), (x - size, y), (x + size, y), 2)
        return

    eye_w = int(size * 2.5)
    eye_h = max(3, int(size * open_amount))

    pygame.draw.ellipse(
        surface,
        (8, 0, 0),
        (x - eye_w // 2 - 2, y - eye_h // 2 - 2, eye_w + 4, eye_h + 4)
    )

    pygame.draw.ellipse(
        surface,
        (230, 205, 175),
        (x - eye_w // 2, y - eye_h // 2, eye_w, eye_h)
    )

    pupil_x = x + int(math.sin(phase * 1.8) * 3)

    pygame.draw.circle(surface, (190, 12, 8), (pupil_x, y), max(3, size // 2))
    pygame.draw.circle(surface, BLACK, (pupil_x, y), max(2, size // 3))
    pygame.draw.circle(surface, (255, 255, 255), (pupil_x - 1, y - 1), 1)

    if open_amount > 0.65:
        drip = int(8 + 18 * open_amount)
        pygame.draw.line(surface, (55, 0, 0), (x, y + eye_h // 2), (x, y + eye_h // 2 + drip), 3)
        pygame.draw.line(surface, RUNE_RED, (x, y + eye_h // 2), (x, y + eye_h // 2 + drip), 1)
        pygame.draw.circle(surface, RUNE_RED, (x, y + eye_h // 2 + drip), 2)

def _draw_looming_presence(surface, shrine_x, shrine_y, timer, progress, shake):
    t = timer * 0.04
    emerge = _ease_out_cubic(max(0.0, min(1.0, (progress - 0.16) / 0.62)))

    if emerge <= 0:
        return

    cx = shrine_x + shake
    base_y = shrine_y + 48
    height = int(120 + 240 * emerge)
    width = int(48 + 88 * emerge)

    # Huge shadow silhouette behind the shrine
    body_pts = [
        (cx - width, base_y),
        (cx - width + 20, base_y - height * 0.28),
        (cx - width * 0.58, base_y - height * 0.72),
        (cx - width * 0.28, base_y - height * 0.96),
        (cx, base_y - height),
        (cx + width * 0.28, base_y - height * 0.96),
        (cx + width * 0.58, base_y - height * 0.72),
        (cx + width - 20, base_y - height * 0.28),
        (cx + width, base_y),
    ]

    pygame.draw.polygon(surface, (12, 0, 0), body_pts)
    pygame.draw.polygon(surface, (85, 0, 0), body_pts, 2)

    # Shoulder / wing-like abyssal mass
    wing_alpha = 16 + int(20 * emerge)
    wing = _get_two_circle_glow(
        (70, 0, 0, wing_alpha),
        (180, 20, 10, 8 + int(10 * emerge)),
        74,
        18,
        surf_w=180
    )

    surface.blit(
        wing,
        (cx - 138, base_y - height + 58),
        special_flags=pygame.BLEND_RGBA_ADD
    )
    surface.blit(
        wing,
        (cx - 42, base_y - height + 58),
        special_flags=pygame.BLEND_RGBA_ADD
    )

    # Crown horns
    horn_y = int(base_y - height + 34)
    for sign in (-1, 1):
        horn = [
            (cx + sign * 18, horn_y + 16),
            (cx + sign * 66, horn_y - 30),
            (cx + sign * 54, horn_y + 2),
            (cx + sign * 32, horn_y + 20),
        ]
        pygame.draw.polygon(surface, (16, 0, 0), horn)
        pygame.draw.polygon(surface, (135, 20, 10), horn, 1)

    # Giant face eye
    eye_open = max(0.0, min(1.0, (progress - 0.28) / 0.34))
    if eye_open > 0:
        eye_y = int(base_y - height + 86 + math.sin(t * 1.8) * 2)
        _draw_ending_eye(surface, cx, eye_y, 18, t + 1.7, eye_open)

    # Chest furnace/core
    core_open = max(0.0, min(1.0, (progress - 0.42) / 0.26))
    if core_open > 0:
        chest = _get_two_circle_glow(
            (180, 12, 10, 36 + int(30 * core_open)),
            (255, 160, 55, 90 + int(40 * core_open)),
            28,
            9,
            surf_w=84
        )
        surface.blit(
            chest,
            (cx - chest.get_width() // 2, int(base_y - height * 0.52) - chest.get_height() // 2),
            special_flags=pygame.BLEND_RGBA_ADD
        )

def draw_final_end_animation(surface, timer, scroll_offset):
    progress = max(0.0, min(1.0, timer / END_SEQUENCE_FRAMES))
    t = timer * 0.04

    shrine_x, shrine_y = _get_final_tower_screen_anchor(scroll_offset)

    # Small shake that ramps up, then dies near the fade.
    shake_power = math.sin(progress * math.pi)
    shake = int(math.sin(timer * 0.65) * 5 * shake_power)

    # Dark blood-red screen wash with more dread.
    wash_alpha = int(48 + 125 * _ease_out_cubic(progress))
    pulse = int(18 * (0.5 + 0.5 * math.sin(timer * 0.18)))

    blit_fullscreen_overlay(
        surface,
        (70, 0, 0, max(0, min(220, wash_alpha + pulse)))
    )

    # Deepening void layer so it feels less flat and more apocalyptic.
    if progress > 0.18:
        void_alpha = int(26 + 54 * _ease_out_cubic((progress - 0.18) / 0.82))
        blit_fullscreen_overlay(surface, (16, 0, 0, void_alpha))
    # Final fade to black at the end.
    if progress > 0.82:
        fade = int(220 * _ease_in_cubic((progress - 0.82) / 0.18))
        blit_fullscreen_overlay(surface, (0, 0, 0, fade))

    # Giant hell presence behind the final shrine.
    presence_strength = _ease_out_cubic(min(1.0, progress * 1.45))
    halo_r = 150 + int(45 * math.sin(timer * 0.04))
    
    halo = _get_two_circle_glow(
        (120, 0, 0, 28 + int(30 * presence_strength)),
        (255, 60, 20, 18 + int(25 * presence_strength)),
        132,
        42,
        surf_w=290
    )

    surface.blit(
        halo,
        (shrine_x - halo.get_width() // 2 + shake, shrine_y - halo.get_height() // 2),
        special_flags=pygame.BLEND_RGBA_ADD
    )

    _draw_looming_presence(surface, shrine_x, shrine_y, timer, progress, shake)
    # Expanding ground shockwaves.
    for i in range(4):
        ring_t = (progress * 3.2 - i * 0.34) % 1.0
        ring_w = int(80 + ring_t * 520)
        ring_h = int(18 + ring_t * 70)
        alpha = int((1.0 - ring_t) * 80 * presence_strength)

        if alpha <= 0:
            continue

        ring_rect = pygame.Rect(0, 0, ring_w, ring_h)
        ring_rect.center = (shrine_x + shake, GROUND_Y - 8)

        pygame.draw.ellipse(surface, (255, 70, 20, alpha), ring_rect, 2)
        pygame.draw.ellipse(surface, (90, 0, 0, max(10, alpha // 2)), ring_rect.inflate(10, 4), 1)

    # Blood rifts tearing through the air.
    rift_count = 9

    for i in range(rift_count):
        lane = (i + 0.5) / rift_count
        base_x = int(lane * SCREEN_WIDTH)
        drift = int(math.sin(t * 0.8 + i * 1.4) * 18)
        open_t = max(0.0, min(1.0, (progress - i * 0.035) / 0.45))

        if open_t <= 0:
            continue

        top = int(40 - 50 * open_t)
        bottom = int(SCREEN_HEIGHT + 20 * open_t)
        x1 = base_x + drift + shake
        x2 = base_x - drift // 2

        pygame.draw.line(surface, (24, 0, 0), (x1, top), (x2, bottom), 6)
        pygame.draw.line(surface, (130, 5, 8), (x1, top + 10), (x2, bottom - 10), 3)
        pygame.draw.line(surface, (255, 55, 20), (x1, top + 24), (x2, bottom - 22), 1)

        # Fire climbing along the rift.
        for j in range(3):
            flame_y = int((timer * (2.4 + j * 0.4) + i * 71 + j * 120) % (SCREEN_HEIGHT + 120)) - 80
            flame_x = int(x1 + math.sin(t + j + i) * 8)

            flame = _get_two_circle_glow(
                (220, 35, 10, 42),
                (255, 190, 85, 95),
                8,
                3,
                surf_w=28
            )

            surface.blit(
                flame,
                (flame_x - flame.get_width() // 2, flame_y - flame.get_height() // 2),
                special_flags=pygame.BLEND_RGBA_ADD
            )

    # World-splitting ground fissures and crawling presence.
    fissure_strength = _ease_out_cubic(max(0.0, min(1.0, (progress - 0.14) / 0.70)))

    fissure_xs = (
        -300, -238, -182, -126, -74, -26,
        28, 84, 138, 192, 248, 306
    )

    for i, ox in enumerate(fissure_xs):
        start_x = shrine_x + ox + int(math.sin(t * 0.9 + i) * 6)
        start_y = GROUND_Y - 2

        seg1 = int(20 + 40 * fissure_strength)
        seg2 = int(12 + 28 * fissure_strength)
        bend1 = int(math.sin(t * 1.2 + i * 0.6) * 12)
        bend2 = int(math.cos(t * 1.5 + i * 0.4) * 10)

        mid_x = start_x + bend1
        mid_y = start_y + seg1
        end_x = mid_x + bend2
        end_y = mid_y + seg2

        pygame.draw.line(surface, (24, 0, 0), (start_x, start_y), (mid_x, mid_y), 5)
        pygame.draw.line(surface, (24, 0, 0), (mid_x, mid_y), (end_x, end_y), 4)

        pygame.draw.line(surface, (135, 8, 10), (start_x, start_y), (mid_x, mid_y), 2)
        pygame.draw.line(surface, (135, 8, 10), (mid_x, mid_y), (end_x, end_y), 2)

        pygame.draw.line(surface, (255, 70, 25), (start_x, start_y + 1), (mid_x, mid_y - 1), 1)
        pygame.draw.line(surface, (255, 70, 25), (mid_x, mid_y), (end_x, end_y - 1), 1)

        # Small ember leak at the crack mouth.
        ember = _get_two_circle_glow(
            (180, 20, 10, 28),
            (255, 185, 85, 78),
            5,
            2,
            surf_w=18
        )
        surface.blit(
            ember,
            (start_x - ember.get_width() // 2, start_y - ember.get_height() // 2),
            special_flags=pygame.BLEND_RGBA_ADD
        )

    # Claw-like shadow tendrils rising out of some fissures.
    tendril_strength = _ease_out_cubic(max(0.0, min(1.0, (progress - 0.32) / 0.42)))

    if tendril_strength > 0:
        tendril_xs = (-208, -118, -42, 54, 126, 214)

        for i, ox in enumerate(tendril_xs):
            root_x = shrine_x + ox
            root_y = GROUND_Y + 2
            height = int((38 + 46 * (0.5 + 0.5 * math.sin(t * 1.3 + i))) * tendril_strength)
            lean = int(math.sin(t * 1.7 + i * 0.9) * 18)

            # Main arm
            pygame.draw.line(
                surface,
                (15, 0, 0),
                (root_x, root_y),
                (root_x + lean, root_y - height),
                8
            )
            pygame.draw.line(
                surface,
                (90, 0, 0),
                (root_x, root_y),
                (root_x + lean, root_y - height),
                3
            )

            # Finger-like branches
            tip_x = root_x + lean
            tip_y = root_y - height

            for j in (-1, 1):
                fx = tip_x + j * 14
                fy = tip_y - 8
                pygame.draw.line(surface, (15, 0, 0), (tip_x, tip_y), (fx, fy), 4)
                pygame.draw.line(surface, (110, 8, 8), (tip_x, tip_y), (fx, fy), 1)    # Eyes opening around the shrine/world as the presence enters.
    eye_positions = (
        (-250, -116, 12, 0.08),
        (250, -104, 12, 0.12),
        (-182, -8, 11, 0.18),
        (182, 4, 11, 0.22),
        (-116, -168, 14, 0.28),
        (116, -160, 14, 0.34),
        (-34, -220, 16, 0.40),
        (34, -220, 16, 0.44),
        (0, -262, 20, 0.52),
    )

    for i, (ox, oy, size, delay) in enumerate(eye_positions):
        open_amt = max(0.0, min(1.0, (progress - delay) / 0.24))

        if open_amt <= 0:
            continue

        ex = shrine_x + ox + int(math.sin(t * 0.8 + i) * 4) + shake
        ey = shrine_y + oy + int(math.sin(t * 1.1 + i) * 3)

        _draw_ending_eye(surface, ex, ey, size, t + i, open_amt)

    # Deterministic ash/embers. No random per frame.
    for i in range(36):
        lane = (i * 37) % SCREEN_WIDTH
        y = int((SCREEN_HEIGHT + 80 - ((timer * (1.2 + (i % 5) * 0.18) + i * 29) % (SCREEN_HEIGHT + 130))))
        x = int(lane + math.sin(t * 0.55 + i) * 22) % SCREEN_WIDTH
        size = 1 + (i % 3)

        if i % 4 == 0:
            pygame.draw.circle(surface, (255, 115, 40), (x, y), size)
        else:
            pygame.draw.circle(surface, (120, 12, 8), (x, y), size)

    if timer < 120:
        _draw_end_text(
            surface,
            "THE SEAL IS BROKEN",
            SCREEN_HEIGHT // 2 - 86 + shake,
            50,
            (255, 205, 110),
            shake
        )

    elif timer < 260:
        _draw_end_text(
            surface,
            "IT HAS BEGUN TO MANIFEST",
            SCREEN_HEIGHT // 2 - 90 + shake,
            46,
            (255, 120, 65),
            shake
        )

    elif timer < 385:
        _draw_end_text(
            surface,
            "SOMETHING AWAKENS",
            SCREEN_HEIGHT // 2 - 96 + shake,
            60,
            (255, 220, 130),
            shake
        )

GROUND_Y = SCREEN_HEIGHT - 66
ACTIVE_RANGE = SCREEN_WIDTH + 400
TOTAL_SHRINES = 5
PIXELS_PER_METER = 50
SHRINE_DISTANCE_M = 200
SHRINE_SPACING = SHRINE_DISTANCE_M * PIXELS_PER_METER
CHUNK_SIZE = 1500

spawned_chunks = set()
skeletons = []
chests = []
particles = []
sparks = []
damage_numbers = []
powerups = []
lava_particles = []
towers = []
tower_bosses = {}

MAX_PARTICLES = 140
MAX_SPARKS = 180
MAX_DAMAGE_NUMBERS = 90
MAX_LAVA_PARTICLES = 160


def trim_effect_lists():
    if len(particles) > MAX_PARTICLES:
        del particles[:-MAX_PARTICLES]
    if len(sparks) > MAX_SPARKS:
        del sparks[:-MAX_SPARKS]
    if len(damage_numbers) > MAX_DAMAGE_NUMBERS:
        del damage_numbers[:-MAX_DAMAGE_NUMBERS]
    if len(lava_particles) > MAX_LAVA_PARTICLES:
        del lava_particles[:-MAX_LAVA_PARTICLES]


def get_shrine_world_x(index):
    return 90 + (index + 1) * SHRINE_SPACING


def spawn_chunk(chunk_index, current_tier):
    if chunk_index in spawned_chunks:
        return
    spawned_chunks.add(chunk_index)
    chunk_start = chunk_index * CHUNK_SIZE
    chunk_end = chunk_start + CHUNK_SIZE

    if chunk_index == 0:
        skeletons.append(Entity("Skeleton", random.randint(chunk_start + 700, chunk_end - 200), GROUND_Y - 10, 3, tier=current_tier))
        return

    spawned_tower = False
    for tower_idx in range(TOTAL_SHRINES):
        shrine_x = get_shrine_world_x(tower_idx)
        if chunk_start <= shrine_x < chunk_end:
            is_final = tower_idx == TOTAL_SHRINES - 1
            tower = DemonicTower(shrine_x, GROUND_Y, tower_idx, is_final=is_final)
            towers.append(tower)
            variant = None if is_final else (tower_idx % len(BOSS_VARIANTS))
            boss = Entity("Skeleton", shrine_x - 120, GROUND_Y - 10, 3,
                          force_lucky=True, tier=tower_idx, is_final_boss=is_final,
                          boss_variant=variant)
            skeletons.append(boss)
            tower_bosses[tower_idx] = boss
            spawned_tower = True
            break

    lucky_chance = min(0.45, 0.18 + current_tier * 0.05)
    num_skels = random.randint(2, 3) + min(1, current_tier // 3)
    if spawned_tower:
        num_skels = max(1, num_skels - 1)
    for _ in range(num_skels):
        x = random.randint(chunk_start + 100, chunk_end - 100)
        s = Entity("Skeleton", x, GROUND_Y - 10, 3, tier=current_tier)
        if random.random() < lucky_chance and not s.lucky_skel:
            s.lucky_skel = True
            s.health = int(70 * (1 + current_tier * 0.20))
            s.max_health = s.health
            s.base_dmg_min = int(12 * (1 + current_tier * 0.15))
            s.base_dmg_max = int(22 * (1 + current_tier * 0.15))
            s.attack_cooldown_max = 55
        skeletons.append(s)

    # Chests should feel rare and valuable, not like constant clutter.
    # Roughly 1 chest every ~12 chunks on average, and never more than 1 per chunk.
    CHEST_SPAWN_CHANCE = 0.12
    if not spawned_tower and random.random() < CHEST_SPAWN_CHANCE:
        x = random.randint(chunk_start + 180, chunk_end - 180)
        chests.append(TreasureChest(x, GROUND_Y))

def ensure_world_around(player_x, current_tier):
    current_chunk = int(player_x // CHUNK_SIZE)
    for i in range(current_chunk, current_chunk + 4):
        if i >= 0:
            spawn_chunk(i, current_tier)


def cull_far_behind(player_x):
    cutoff = player_x - CHUNK_SIZE * 2
    skeletons[:] = [s for s in skeletons if s.anchor_x > cutoff]
    chests[:] = [c for c in chests if c.world_x > cutoff and not c.collected]
    powerups[:] = [p for p in powerups if p.world_x > cutoff and not p.collected]


def reset_game():
    global spawned_chunks, skeletons, chests, particles, sparks, damage_numbers
    global powerups, lava_particles, towers, tower_bosses
    spawned_chunks = set()
    skeletons = []
    chests = []
    particles = []
    sparks = []
    damage_numbers = []
    powerups = []
    lava_particles = []
    towers = []
    tower_bosses = {}
    player = Entity("Player", 90, GROUND_Y - 10, 3)
    for i in range(3):
        spawn_chunk(i, 0)
    return player, 0.0


def trigger_lava_burst(x, y, count=10, intensity=1.0):
    for _ in range(count):
        lava_particles.append(LavaParticle(x + random.randint(-30, 30), y, intensity=intensity))


def apply_enemy_reward_drop(ev):
    """Apply enemy reward drops.

    Normal skeletons send heal_amount=0 and drop_powerup=False, so they only give score.
    Lucky skeletons can give health, power-ups, or rarely both.
    Bosses always give health and may also drop a power-up.
    """
    heal_amount = ev.get("heal_amount", 0)
    if heal_amount > 0:
        player.health = min(player.max_health, player.health + heal_amount)
        damage_numbers.append(DamageNumber(
            ev["x"], ev["y"] - 10, f"+{heal_amount}", color=HP_GOOD
        ))
        for _ in range(4):
            particles.append(Particle(ev["x"], ev["y"] + 22, "heart"))

    if ev.get("drop_powerup"):
        powerups.append(PowerUp(
            ev["x"], ev["y"] + 20, random.choice(["speed", "damage", "shield"])
        ))


def get_next_shrine_x(shrines_activated):
    for tower in towers:
        if not tower.activated:
            return tower.world_x
    if shrines_activated < TOTAL_SHRINES:
        return get_shrine_world_x(shrines_activated)
    return None

def spawn_covenant_bosses(center_x):
    # 4 named bosses + final boss
    positions = [-700, -350, 0, 350, 700]

    for i, offset in enumerate(positions[:4]):
        boss = Entity(
            "Skeleton",
            center_x + offset,
            GROUND_Y - 10,
            3,
            force_lucky=True,
            tier=i,
            boss_variant=i
        )
        skeletons.append(boss)

    final_boss = Entity(
        "Skeleton",
        center_x + positions[4],
        GROUND_Y - 10,
        3,
        force_lucky=True,
        tier=TOTAL_SHRINES - 1,
        is_final_boss=True
    )
    skeletons.append(final_boss)

def draw_covenant_prompt(surface):
    box_x = 16
    box_y = 18
    box_w = SCREEN_WIDTH - 32
    box_h = 260

    draw_panel(surface, box_x, box_y, box_w, box_h)

    title_font = _get_font(64)
    main_font = _get_font(34)
    sub_font = _get_font(22)

    title = get_text(title_font, "ANCIENT COVENANT", GILT_BRIGHT)
    line1 = get_text(main_font, "Type GOD to accept the covenant.", PARCHMENT)
    line2 = get_text(sub_font, "Heavenly ichor shall descend upon the chosen.", PARCH_DIM)
    
    title_x = SCREEN_WIDTH // 2 - title.get_width() // 2
    line1_x = SCREEN_WIDTH // 2 - line1.get_width() // 2
    line2_x = SCREEN_WIDTH // 2 - line2.get_width() // 2

    surface.blit(title, (title_x, box_y + 34))
    surface.blit(line1, (line1_x, box_y + 122))
    surface.blit(line2, (line2_x, box_y + 178))
# Hidden cheat sequence: type GODMODE during gameplay.
CHEAT_SEQUENCE = "god"
cheat_buffer = ""
cheat_message_timer = 0
covenant_triggered = False
covenant_prompt_active = False
covenant_prompt_timer = 0

async def main():
    global player, scroll_offset, game_over, victory, paused, hitstop_timer, cull_counter
    global shrines_activated, current_tier, hellscape_progress, hellscape_target
    global final_animation_phase, final_animation_timer, cheat_buffer, cheat_message_timer
    global covenant_triggered, covenant_prompt_active, covenant_prompt_timer

    player, scroll_offset = reset_game()
    #temp
    #player.anchor_x = 145090
    #player._sync_rect_to_anchor()
    #scroll_offset = max(0, player.anchor_x - SCREEN_WIDTH // 2)

    
    game_over = False
    victory = False
    paused = False
    hitstop_timer = 0
    cull_counter = 0
    shrines_activated = 0
    current_tier = 0
    hellscape_progress = 0.0
    hellscape_target = 0.0
    final_animation_phase = 0
    final_animation_timer = 0
    covenant_triggered = False
    covenant_prompt_active = False

    run = True
    while run:
        # OPT (pygbag-critical): tick_busy_loop spins the CPU in a Python-level
        # busy wait, which in a browser starves the main thread, drops frames,
        # and drains battery. clock.tick yields properly and pairs with the
        # browser's vsync via pygame.display.flip() + asyncio.sleep(0) below.
        clock.tick(FPS)
        # OPT: snapshot pygame.time.get_ticks() once and let entity.py read it
        # cheaply from a module-level int instead of crossing the Python→WASM
        # boundary on every _draw_* method. Saves dozens of bridge calls per
        # entity per frame in the browser.
        set_frame_ticks(pygame.time.get_ticks())
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and (game_over or victory):
                    player, scroll_offset = reset_game()
                    game_over = False
                    victory = False
                    paused = False
                    shrines_activated = 0
                    current_tier = 0
                    hellscape_progress = 0.0
                    hellscape_target = 0.0
                    final_animation_phase = 0
                    final_animation_timer = 0
                    covenant_triggered = False
                    covenant_prompt_active = False
                    covenant_prompt_timer = 0
                    cheat_buffer = ""
                    cheat_message_timer = 0

                elif event.key == pygame.K_ESCAPE and not game_over and not victory:
                    paused = not paused

                elif not game_over and not victory:
                    typed = getattr(event, "unicode", "").lower()
                    if typed and typed.isprintable() and len(typed) == 1:
                        cheat_buffer = (cheat_buffer + typed)[-len(CHEAT_SEQUENCE):]

                        if cheat_buffer == CHEAT_SEQUENCE:
                            player.activate_cheat_mode()

                            covenant_prompt_active = False
                            covenant_prompt_timer = 0   # this instantly removes the big Ancient Covenant box

                            cheat_message_timer = 240   # this shows Ancient Power Awakened after
                            cheat_buffer = ""

        if hellscape_progress < hellscape_target:
            hellscape_progress = min(hellscape_target, hellscape_progress + 0.005)

        if final_animation_phase == 1:
            final_animation_timer += 1
            hellscape_target = 1.0

            # Escalating lava chaos.
            # Uses existing LavaParticle system, but gets more violent over time.
            burst_rate = max(2, 8 - final_animation_timer // 70)
            intensity = 1.2 + min(1.6, final_animation_timer / 220.0)

            if final_animation_timer % burst_rate == 0:
                lava_x = scroll_offset + random.randint(-120, SCREEN_WIDTH + 120)
                trigger_lava_burst(
                    lava_x,
                    GROUND_Y + random.randint(-10, 8),
                    count=4 + min(8, final_animation_timer // 60),
                    intensity=intensity
                )

            # Big shrine-centered bursts at key moments.
            if final_animation_timer in (1, 105, 220, 330):
                final_tower_x = None

                for tower in towers:
                    if getattr(tower, "is_final", False):
                        final_tower_x = tower.world_x
                        break

                if final_tower_x is None:
                    final_tower_x = scroll_offset + SCREEN_WIDTH // 2

                trigger_lava_burst(final_tower_x, GROUND_Y, count=26, intensity=2.2)

                for _ in range(24):
                    sparks.append(
                        Spark(
                            final_tower_x + random.randint(-80, 80),
                            GROUND_Y - random.randint(30, 180),
                            color=(255, 80, 25)
                        )
                    )

            if final_animation_timer > END_SEQUENCE_FRAMES:
                final_animation_phase = 2
                victory = True
        # OPT: cache the boolean check that's used 4+ times per frame.
        is_final_anim = final_animation_phase == 1
        tick_world = not paused and not game_over and not victory and hitstop_timer <= 0 and not is_final_anim
        effect_tick = tick_world or is_final_anim
        if hitstop_timer > 0:
            hitstop_timer -= 1
        if cheat_message_timer > 0:
            cheat_message_timer -= 1
        if covenant_prompt_timer > 0:
            covenant_prompt_timer -= 1

        distance_m = max(0, int((player.anchor_x - 90) / PIXELS_PER_METER))
        if not covenant_triggered and distance_m >= SHRINE_DISTANCE_M * 6:
            covenant_triggered = True
            covenant_prompt_active = True
            covenant_prompt_timer = 360
            cheat_buffer = ""
            spawn_covenant_bosses(player.anchor_x + 250)

        # Scale enemies based on distance traveled, not shrine activation
        MAX_ENEMY_TIER = 5
        distance_tier = min(MAX_ENEMY_TIER, distance_m // SHRINE_DISTANCE_M)
        current_tier = distance_tier

        ensure_world_around(player.anchor_x, current_tier)

        if tick_world:
            target_scroll = max(0.0, player.anchor_x - SCREEN_WIDTH // 2)
            scroll_offset += (target_scroll - scroll_offset) * 0.18
        else:
            scroll_offset = max(0.0, scroll_offset)

        draw_world_bg(screen, scroll_offset, hellscape_progress)

        # OPT: cache active-range bounds once per frame. Replaces
        # `abs(thing.world_x - player.anchor_x) > ACTIVE_RANGE` (which calls
        # abs() once per entity) with two cheap comparisons. Also hoists the
        # player.anchor_x lookup so we don't pay attribute access per entity.
        anchor_x = player.anchor_x
        min_x = anchor_x - ACTIVE_RANGE
        max_x = anchor_x + ACTIVE_RANGE

        for tower in towers:
            wx = tower.world_x
            if wx < min_x or wx > max_x:
                continue
            if tick_world:
                boss = tower_bosses.get(tower.tier_index)
                result = tower.update(player, boss)
                if result == "activated":
                    shrines_activated += 1
                    player.shrines_cleared += 1

                    # Only normal shrines trigger the falling ethereal/fire animation.
                    # Final shrine explicitly cancels it.
                    if tower.is_final:
                        player.ethereal_glow_timer = 0
                    else:
                        player.ethereal_glow_timer = 120

                    # Shrine reward: slightly increase max health and heal the player
                    player.max_health += 12.5
                    player.health = player.max_health
                    
                    if tower.is_final and final_animation_phase == 0:
                        hellscape_target = 1.0
                        final_animation_phase = 1
                        final_animation_timer = 0
                    for _ in range(15):
                        sparks.append(Spark(tower.world_x + random.randint(-30, 30), GROUND_Y - 100, color=GILT))
            tower.draw(screen, scroll_offset)

        for chest in chests:
            wx = chest.world_x
            if wx < min_x or wx > max_x:
                continue
            if tick_world:
                chest.check_collect(player, particles, powerups, lucky_skeleton=None)
                chest.update()
            chest.draw(screen, scroll_offset)

        for pu in powerups:
            wx = pu.world_x
            if wx < min_x or wx > max_x:
                continue

            if tick_world:
                pu.update()

                if pu.check_collect(player):
                    damage_numbers.append(
                        DamageNumber(
                            pu.world_x,
                            pu.world_y - 38,
                            getattr(pu, "collect_message", "POWER UP"),
                            color=pu.colors()[0],
                            size=12,
                        )
                    )

                    for _ in range(8):
                        sparks.append(Spark(pu.world_x, pu.world_y, color=pu.colors()[0]))

            if not pu.collected:
                pu.draw(screen, scroll_offset)

        if tick_world:
            powerups[:] = [p for p in powerups if not p.collected]

        for particle in particles:
            if effect_tick:
                particle.update()
            particle.draw(screen, scroll_offset)
        if effect_tick:
            particles[:] = [p for p in particles if not p.dead]

        for lp in lava_particles:
            if effect_tick:
                lp.update()
            lp.draw(screen, scroll_offset)
        if effect_tick:
            lava_particles[:] = [lp for lp in lava_particles if not lp.dead]
        if not game_over and not is_final_anim:
            # OPT: was two passes over the full skeletons list. Now a single
            # pass that builds both lists and uses the cached bounds. Avoids
            # the abs() call per skeleton too. With many off-screen skeletons
            # this halves the iteration cost of skeleton list scans.
            active_skels = []
            alive_active = []
            for s in skeletons:
                ax = s.anchor_x
                if ax < min_x or ax > max_x:
                    continue
                active_skels.append(s)
                if s.alive:
                    alive_active.append(s)

            if tick_world:
                player.move(SCREEN_HEIGHT, screen, alive_active)
                player.update()

                for skel in active_skels:
                    if skel.alive:
                        skel.ai(screen, player)
                    skel.check_alive()
                    skel.update()

                if player.heal_on_kill > 0:
                    damage_numbers.append(DamageNumber(player.rect.centerx, player.rect.top, f"+{player.heal_on_kill}", color=HP_GOOD))
                    player.health = min(player.max_health, player.health + player.heal_on_kill)
                    player.heal_on_kill = 0

                for ev in player.events:
                    et = ev["type"]
                    if et == "hit_landed":
                        hitstop_timer = max(hitstop_timer, 4 if ev.get("crit") else 2)
                        color = CRIT_ORANGE if ev.get("crit") else (255, 230, 80)
                        text = f"{ev['damage']}!" if ev.get("crit") else str(ev["damage"])
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"], text, color=color, big=ev.get("crit", False)))
                        for _ in range(6 if ev.get("crit") else 3):
                            sparks.append(Spark(ev["x"], ev["y"], color=(255, 160, 60) if ev.get("crit") else (255, 220, 100)))
                    elif et == "hit_taken":
                        hitstop_timer = max(hitstop_timer, 4)
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"], str(ev["damage"]), color=(255, 80, 80), big=True))
                        for _ in range(5):
                            sparks.append(Spark(ev["x"], ev["y"], color=(255, 80, 80)))
                    elif et == "shield_reduce":
                        damage_numbers.append(
                            DamageNumber(
                                ev["x"],
                                ev["y"] - 16,
                                "-50% DMG",
                                color=SHIELD_BLUE,
                                size=12,
                            )
                        )
                        for _ in range(6):
                            sparks.append(Spark(ev["x"], ev["y"], color=SHIELD_BLUE))
                    elif et == "enemy_died":
                        apply_enemy_reward_drop(ev)
                    elif et == "boss_died":
                        trigger_lava_burst(ev["x"], ev["y"] + 50, count=12)
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"] - 20, "BOSS DEFEATED", color=GILT, big=True))
                        apply_enemy_reward_drop(ev)
                    elif et == "final_boss_died":
                        for _ in range(40):
                            trigger_lava_burst(ev["x"], ev["y"] + 50, count=3, intensity=1.5)
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"] - 40, "THE DAMNED KING FALLS", color=(255, 100, 30), big=True))
                        apply_enemy_reward_drop(ev)
                player.events.clear()
                trim_effect_lists()

                cull_counter += 1
                if cull_counter >= 60:
                    cull_counter = 0
                    cull_far_behind(player.anchor_x)
                if not player.alive:
                    game_over = True

            player.draw(screen, scroll_offset)
            for skel in active_skels:
                if skel.alive or skel.respawn_timer < 250:
                    skel.draw(screen, scroll_offset)
                    skel.draw_health_bar(screen, scroll_offset)
        else:
            player.draw(screen, scroll_offset)

        for sp in sparks:
            if effect_tick:
                sp.update()
            sp.draw(screen, scroll_offset)
        if effect_tick:
            sparks[:] = [s for s in sparks if not s.dead]

        for dn in damage_numbers:
            if effect_tick:
                dn.update()
            dn.draw(screen, scroll_offset)
        if effect_tick:
            damage_numbers[:] = [d for d in damage_numbers if not d.dead]
            trim_effect_lists()

        if not game_over and not victory:
            next_x = get_next_shrine_x(shrines_activated)
            next_dist_m = None if next_x is None else max(0, int((next_x - player.anchor_x) / PIXELS_PER_METER))
            draw_hud(screen, player, distance_m)
            draw_shrine_tracker(screen, shrines_activated, TOTAL_SHRINES, next_dist_m)
            draw_strength_indicator(screen, player)
            draw_powerup_strip(screen, player)
            draw_keys(screen)
            if covenant_prompt_timer > 0:
                draw_covenant_prompt(screen)
            elif cheat_message_timer > 0:
                # OPT: reuse the pre-rendered cheat text surfaces.
                cx, cy = _CHEAT_X, _CHEAT_Y
                screen.blits(
                    ((_CHEAT_OUTLINE, (cx - 1, cy)),
                     (_CHEAT_OUTLINE, (cx + 1, cy)),
                     (_CHEAT_OUTLINE, (cx, cy - 1)),
                     (_CHEAT_OUTLINE, (cx, cy + 1))),
                    doreturn=False,
                )
                screen.blit(_CHEAT_MAIN, (cx, cy))

            # OPT: removed duplicate cheat-message render that was here. The
            # block above already draws the message in the elif branch; this
            # second `if cheat_message_timer > 0` block was rendering the same
            # text + outline twice every frame.

        if is_final_anim:
            draw_final_end_animation(screen, final_animation_timer, scroll_offset)
        if game_over:
            draw_death_screen(screen, player.score, distance_m)
        elif paused:
            draw_pause_screen(screen)
        elif victory:
            draw_victory_screen(screen)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
