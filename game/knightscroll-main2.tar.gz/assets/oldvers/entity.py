import pygame
import random
import os
import math

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = int(SCREEN_WIDTH * 0.8)

GREEN = (0, 255, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GOLD = (255, 223, 0)
COIN_GOLD = (255, 200, 30)
COIN_DARK = (180, 130, 10)
HEART_RED = (220, 40, 60)
CRIT_ORANGE = (255, 140, 30)
SHIELD_BLUE = (80, 180, 255)
BLOOD_RED = (140, 15, 20)

_SPRITE_CACHE = {}
_FLIPPED_CACHE = {}
_FONTS = {}
_DAMAGE_TEXT_CACHE = {}
_PARTICLE_FRAMES = None

ACT_IDLE = 0
ACT_RUN = 1
ACT_JUMP = 2
ACT_ATTACK = 3
ACT_DEATH = 4
ACT_HIT = 5
ACT_REACT = 6
ANIMATION_TYPES = ["idle", "run", "jump", "attack", "death", "hit", "react"]
FRAME_MS = 90

# (name, primary color, secondary color, crown style)
BOSS_VARIANTS = [
    ("Warden",  (180, 80, 200),  (90, 40, 120),  "spiked"),
    ("Reaper",  (40, 180, 200),  (15, 90, 130),  "horned"),
    ("Defiler", (90, 230, 130),  (30, 120, 60),  "antler"),
    ("Tyrant",  (255, 200, 60),  (180, 120, 20), "regal"),
]


def _get_font(size):
    if size not in _FONTS:
        _FONTS[size] = pygame.font.Font("freesansbold.ttf", size)
    return _FONTS[size]


def _placeholder_frame(char_type, animation, scale):
    w = int(28 * scale)
    h = int(42 * scale)
    surf = pygame.Surface((max(8, w), max(8, h)), pygame.SRCALPHA)
    color = (210, 210, 230) if char_type == "Player" else (190, 180, 160)
    pygame.draw.rect(surf, color, surf.get_rect(), border_radius=4)
    pygame.draw.rect(surf, BLACK, surf.get_rect(), 1, border_radius=4)
    return surf.convert_alpha()


def _numeric_key(filename):
    stem = os.path.splitext(filename)[0]
    try:
        return int(stem)
    except ValueError:
        return stem


def load_animations(char_type, scale):
    key = (char_type, round(scale, 3))
    if key in _SPRITE_CACHE:
        return _SPRITE_CACHE[key]

    animation_list = []
    for animation in ANIMATION_TYPES:
        frames = []
        folder = f"img/{char_type}/{animation}"
        if os.path.isdir(folder):
            pngs = [f for f in os.listdir(folder) if f.lower().endswith(".png")]
            pngs.sort(key=_numeric_key)
            for filename in pngs:
                path = os.path.join(folder, filename)
                try:
                    orig_img = pygame.image.load(path).convert_alpha()
                    crop_rect = orig_img.get_bounding_rect()
                    if crop_rect.width <= 0 or crop_rect.height <= 0:
                        crop_img = orig_img.copy()
                    else:
                        crop_img = orig_img.subsurface(crop_rect).copy()
                    img = pygame.transform.scale(
                        crop_img,
                        (max(1, int(crop_img.get_width() * scale)),
                         max(1, int(crop_img.get_height() * scale)))
                    ).convert_alpha()
                    frames.append(img)
                except Exception:
                    pass
        if not frames:
            frames.append(_placeholder_frame(char_type, animation, scale))
        animation_list.append(frames)

    _SPRITE_CACHE[key] = animation_list
    _FLIPPED_CACHE[key] = [
        [pygame.transform.flip(frame, True, False).convert_alpha() for frame in frames]
        for frames in animation_list
    ]
    return animation_list


def get_flipped(char_type, scale):
    return _FLIPPED_CACHE.get((char_type, round(scale, 3)))


def draw_boss_crown(surface, x, y, w, style, color, time_offset=0):
    t = pygame.time.get_ticks() * 0.003 + time_offset
    cx = x + w // 2
    cy = y - 4

    if style == "spiked":
        pts = [(cx - 14, cy), (cx - 10, cy - 14), (cx - 4, cy - 6),
               (cx, cy - 18), (cx + 4, cy - 6), (cx + 10, cy - 14), (cx + 14, cy)]
        pygame.draw.polygon(surface, (20, 10, 15), pts)
        pygame.draw.polygon(surface, color, pts, 2)
        pygame.draw.circle(surface, color, (cx, cy - 4), 3)
    elif style == "horned":
        pts_l = []
        for i in range(8):
            ang = math.pi - (i / 7) * math.pi * 0.5
            r = 4 + i * 2
            pts_l.append((cx - 6 + math.cos(ang) * r, cy - math.sin(ang) * r))
        pts_r = []
        for i in range(8):
            ang = (i / 7) * math.pi * 0.5
            r = 4 + i * 2
            pts_r.append((cx + 6 + math.cos(ang) * r, cy - math.sin(ang) * r))
        pygame.draw.lines(surface, (15, 8, 12), False, pts_l, 5)
        pygame.draw.lines(surface, color, False, pts_l, 2)
        pygame.draw.lines(surface, (15, 8, 12), False, pts_r, 5)
        pygame.draw.lines(surface, color, False, pts_r, 2)
    elif style == "antler":
        def branch(ox, oy, angle, length, depth):
            ex = ox + math.cos(angle) * length
            ey = oy + math.sin(angle) * length
            pygame.draw.line(surface, (15, 8, 12), (ox, oy), (ex, ey), 4)
            pygame.draw.line(surface, color, (ox, oy), (ex, ey), 2)
            if depth > 0:
                branch(ex, ey, angle - 0.6, length * 0.6, depth - 1)
                branch(ex, ey, angle + 0.6, length * 0.6, depth - 1)
        branch(cx - 5, cy, -math.pi / 2 - 0.3, 12, 1)
        branch(cx + 5, cy, -math.pi / 2 + 0.3, 12, 1)
    elif style == "regal":
        band_top = cy - 6
        pygame.draw.rect(surface, (20, 12, 8), (cx - 16, band_top, 32, 8))
        pygame.draw.rect(surface, color, (cx - 16, band_top, 32, 8), 1)
        for offset, h in [(-12, 6), (0, 12), (12, 6)]:
            pygame.draw.polygon(surface, color, [
                (cx + offset - 3, band_top),
                (cx + offset + 3, band_top),
                (cx + offset, band_top - h)
            ])
            pygame.draw.circle(surface, (255, 80, 80), (cx + offset, band_top - h + 2), 2)
        pygame.draw.circle(surface, (255, 60, 60), (cx, band_top + 4), 2)


def draw_final_boss_crown(surface, x, y, w):
    t = pygame.time.get_ticks() * 0.005
    cx = x + w // 2
    cy = y - 4
    for i in range(-2, 3):
        ox = i * 6
        h = 18 if i == 0 else (14 if abs(i) == 1 else 10)
        pygame.draw.polygon(surface, (60, 20, 5), [(cx + ox - 4, cy), (cx + ox + 4, cy), (cx + ox, cy - h)])
        pygame.draw.polygon(surface, (255, 200, 60), [(cx + ox - 3, cy), (cx + ox + 3, cy), (cx + ox, cy - h + 2)])
        flicker = int(math.sin(t + i) * 50 + 200)
        pygame.draw.circle(surface, (flicker, flicker // 2, 30), (cx + ox, cy - h + 4), 1)
    pygame.draw.circle(surface, (255, 40, 30), (cx, cy + 2), 4)
    pygame.draw.circle(surface, (255, 200, 200), (cx - 1, cy + 1), 1)


class Entity:
    def __init__(self, char_type, x, y, scale, force_lucky=False, tier=0,
                 is_final_boss=False, boss_variant=None):
        self.alive = True
        self.char_type = char_type
        self.direction = 1
        self.vel_y = 0
        self.jump = False
        self.flip = False
        self.attacking = False
        self.running = False
        self.hit = False
        self.reacting = False
        self.has_seen_player = False
        self.frame_index = 0
        self.action = ACT_IDLE
        self.update_time = pygame.time.get_ticks()

        self.move_counter = 0
        self.idling = False
        self.idling_counter = 0
        self.lucky_skel = False
        self.is_boss = False
        self.is_final_boss = is_final_boss
        self.boss_variant = boss_variant
        self.tier = tier
        self.respawn_timer = 0
        self.heal_on_kill = 0
        self.collected = False
        self.score = 0

        self.swing_active = False
        self.swing_locked_rect = None
        # Tracks every target hit during the current swing.
        # This lets one player attack damage multiple overlapping enemies,
        # while still preventing repeated damage to the same enemy in one swing.
        self.swing_dealt = False
        self.swing_hit_targets = set()
        self.swing_started_this_attack = False

        self.attack_cooldown = 0
        self.attack_cooldown_max = 70
        self.fury_timer = 0
        self.speed_boost_timer = 0
        self.double_dmg_timer = 0
        self.shield_timer = 0
        self.invuln_timer = 0
        self.shrines_cleared = 0
        self.ethereal_glow_timer = 0

        # Hidden cheat mode. Activated from main.py by typing the cheat sequence.
        self.cheat_mode = False
        self.cheat_speed = 25
        self.cheat_damage = 999999
        self.cheat_mode = False
        self.covenant_fx_timer = 0
        
        self.events = []

        if char_type == "Skeleton":
            if force_lucky:
                self.lucky_skel = True
                self.is_boss = True
            elif random.randint(1, 12) == 1:
                self.lucky_skel = True

        if char_type == "Skeleton":
            if self.is_final_boss:
                actual_scale = scale * 2.4
            elif self.is_boss:
                actual_scale = scale * 1.9
            elif self.lucky_skel:
                actual_scale = scale * 1.4
            else:
                actual_scale = scale
        else:
            actual_scale = scale
        self.actual_scale = actual_scale

        self.animation_list = load_animations(char_type, actual_scale)
        self.flipped_list = get_flipped(char_type, actual_scale)
        self.image = self.animation_list[ACT_IDLE][0]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.anchor_x = self.rect.centerx
        self.anchor_y = self.rect.bottom
        self.vision = pygame.Rect(0, 0, int(280 + actual_scale * 30), 80)

        hp_mul = 1 + tier * 0.20
        dmg_mul = 1 + tier * 0.15

        if char_type == "Player":
            self.health = 100
            self.max_health = 100
            self.attack_rect_w = int(2.6 * self.rect.width)
            self.attack_rect_h = int(1.0 * self.rect.height)
            self.base_dmg_min, self.base_dmg_max = 8, 20
            self.attack_cooldown_max = 25
        else:
            w = self.rect.width
            h = self.rect.height
            if self.is_final_boss:
                self.health = int(400 * hp_mul)
                self.base_dmg_min = int(30 * dmg_mul)
                self.base_dmg_max = int(55 * dmg_mul)
                self.attack_cooldown_max = 25
            elif self.is_boss:
                self.health = int(180 * hp_mul)
                self.base_dmg_min = int(18 * dmg_mul)
                self.base_dmg_max = int(35 * dmg_mul)
                self.attack_cooldown_max = 32
            elif self.lucky_skel:
                self.health = int(70 * hp_mul)
                self.base_dmg_min = int(12 * dmg_mul)
                self.base_dmg_max = int(22 * dmg_mul)
                self.attack_cooldown_max = 38
            else:
                self.health = int(40 * hp_mul)
                self.base_dmg_min = int(8 * dmg_mul)
                self.base_dmg_max = int(16 * dmg_mul)
                self.attack_cooldown_max = 50
            self.max_health = self.health
            self.attack_rect_w = int(0.85 * w)
            self.attack_rect_h = int(0.85 * h)

        # Stable body dimensions used for UI and body-blocking. The sprite frames are
        # cropped per-frame, so current image width/height can change during run/attack
        # animations. Keeping a stable body size prevents bars from wobbling and keeps
        # elite collision from changing frame-to-frame.
        body_actions = [ACT_IDLE, ACT_RUN, ACT_JUMP, ACT_HIT, ACT_REACT]
        body_frames = []
        for action_id in body_actions:
            if 0 <= action_id < len(self.animation_list):
                body_frames.extend(self.animation_list[action_id])
        if not body_frames:
            body_frames = [frame for frames in self.animation_list for frame in frames]
        self.body_visual_w = max(frame.get_width() for frame in body_frames)
        self.body_visual_h = max(frame.get_height() for frame in body_frames)
        self.cooldown_bar_w = max(42, int(self.body_visual_w * 0.65))

    def activate_cheat_mode(self):
        """Enable hidden god-mode cheat for the player."""
        if self.char_type != "Player":
            return
        self.cheat_mode = True
        self.cheat_speed = 25
        # Keep the visible HP normal so the HUD/browser does not get weird.
        # Infinite health is handled by ignoring enemy damage and refilling every frame.
        self.health = self.max_health
        # Damage is calculated from the target's current HP, so it one-shots
        # without rendering massive 999999 damage numbers.
        self.speed_boost_timer = 0
        self.double_dmg_timer = 0
        self.fury_timer = 0
        self.invuln_timer = 0
        self.attack_cooldown_max = 0
        self.covenant_fx_timer = 180
        

    def _sync_rect_to_anchor(self):
        new_rect = self.image.get_rect()
        new_rect.midbottom = (int(self.anchor_x), int(self.anchor_y))
        self.rect = new_rect

    def _attack_impact_frame(self):
        frames = len(self.animation_list[ACT_ATTACK])
        if frames <= 0:
            return 0
        if self.char_type == "Skeleton":
            # The skeleton impact frame is the 8th image: zero-based index 7.
            return min(7, frames - 1)
        return min(2, frames - 1)

    def update(self):
        if self.alive:
            if self.hit:
                self._set_action(ACT_HIT)
            elif self.attacking:
                self._set_action(ACT_ATTACK)
            elif self.reacting:
                self._set_action(ACT_REACT)
            elif self.jump and self.char_type == "Player":
                self._set_action(ACT_JUMP)
            elif self.running:
                self._set_action(ACT_RUN)
            else:
                self._set_action(ACT_IDLE)

        if self.char_type == "Player" and self.cheat_mode:
            self.health = self.max_health

        self.check_alive()
        self.image = self.animation_list[self.action][self.frame_index]
        self._sync_rect_to_anchor()

        if self.action == ACT_ATTACK and self.alive:
            impact_frame = self._attack_impact_frame()
            if not self.swing_started_this_attack and self.frame_index >= impact_frame:
                self._start_swing()
                self.swing_started_this_attack = True

        now = pygame.time.get_ticks()
        if now - self.update_time > FRAME_MS:
            self.update_time = now
            self.frame_index += 1

        if self.frame_index >= len(self.animation_list[self.action]):
            if self.action == ACT_REACT:
                self.reacting = False
                self.frame_index = 0
            elif self.action == ACT_HIT:
                self.hit = False
                self.frame_index = 0
            elif self.action == ACT_DEATH:
                self.frame_index = len(self.animation_list[self.action]) - 1
                self.alive = False
            elif self.action == ACT_ATTACK:
                self._end_swing()
                self.attacking = False
                self.swing_started_this_attack = False
                if self.attack_cooldown_max > 0:
                    # Cooldown starts AFTER the swing finishes. Before this, the timer
                    # was burning down during the attack animation, which made higher
                    # cooldown settings feel like they did nothing.
                    self.attack_cooldown = max(self.attack_cooldown, self.attack_cooldown_max)
                self.frame_index = 0
            else:
                self.frame_index = 0

        for attr in ("speed_boost_timer", "double_dmg_timer", "shield_timer",
                     "invuln_timer", "attack_cooldown", "fury_timer",
                     "ethereal_glow_timer", "covenant_fx_timer"):
            value = getattr(self, attr, 0)
            if value > 0:
                setattr(self, attr, value - 1)

    def _set_action(self, new_action):
        if new_action != self.action:
            self.action = new_action
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()
            if new_action == ACT_ATTACK:
                self.swing_started_this_attack = self.swing_active
            else:
                self.swing_started_this_attack = False
                if self.swing_active:
                    self._end_swing()

    def _start_swing(self):
        off = int(self.rect.width * 0.55)
        cx = self.rect.centerx + off * self.direction
        cy = self.rect.centery
        self.swing_locked_rect = pygame.Rect(0, 0, self.attack_rect_w, self.attack_rect_h)
        self.swing_locked_rect.center = (cx, cy)
        self.swing_active = True
        self.swing_dealt = False
        self.swing_hit_targets.clear()

    def _end_swing(self):
        self.swing_active = False
        self.swing_locked_rect = None
        self.swing_dealt = False
        self.swing_hit_targets.clear()

    def move(self, screen_height, surface, targets):
        base_speed = 7
        if self.cheat_mode:
            speed = self.cheat_speed
        else:
            speed = int(base_speed * 1.6) if self.speed_boost_timer > 0 else base_speed
        gravity = 0.75
        dx = 0
        dy = 0
        self.running = False
        key = pygame.key.get_pressed()

        if self.alive and not self.attacking:
            if key[pygame.K_a] and not key[pygame.K_d]:
                dx = -speed
                self.flip = True
                self.direction = -1
                self.running = True
            elif key[pygame.K_d] and not key[pygame.K_a]:
                dx = speed
                self.flip = False
                self.direction = 1
                self.running = True
            if key[pygame.K_w] and not self.jump:
                self.vel_y = -11
                self.jump = True
            if key[pygame.K_f] and self.attack_cooldown <= 0:
                self.attacking = True
                self.swing_started_this_attack = False
                self.frame_index = 0

        if self.swing_active:
            self._try_apply_swing(targets)

        self.vel_y += gravity
        dy += self.vel_y
        ground_y = screen_height - 66
        if self.anchor_y + dy > ground_y:
            self.vel_y = 0
            self.jump = False
            dy = ground_y - self.anchor_y

        old_rect = self.rect.copy()
        self.anchor_x += dx

        # Body-blocking only applies to elites: lucky skeletons and bosses.
        # Normal skeletons stay pass-through so the player can run through them.
        if self.char_type == "Player" and dx != 0 and targets:
            self._sync_rect_to_anchor()
            swept_rect = old_rect.union(self.rect)
            for target in targets:
                if not getattr(target, "alive", False):
                    continue
                if getattr(target, "char_type", None) != "Skeleton":
                    continue

                blocks_player = (
                    getattr(target, "lucky_skel", False)
                    or getattr(target, "is_boss", False)
                    or getattr(target, "is_final_boss", False)
                )
                if not blocks_player:
                    continue

                block_rect = target.rect
                if not (self.rect.colliderect(block_rect) or swept_rect.colliderect(block_rect)):
                    continue

                # Resolve based on where the player came from, not just the key being
                # pressed. This fixes the exploit where starting slightly overlapped and
                # pressing away could snap the player through the elite to the other side.
                if old_rect.right <= block_rect.left and dx > 0:
                    self.rect.right = block_rect.left
                elif old_rect.left >= block_rect.right and dx < 0:
                    self.rect.left = block_rect.right
                elif old_rect.centerx <= block_rect.centerx:
                    self.rect.right = block_rect.left
                else:
                    self.rect.left = block_rect.right

                self.anchor_x = self.rect.centerx
                dx = 0
                break

        self.anchor_y += dy
        if self.anchor_x < 30:
            self.anchor_x = 30
        self._sync_rect_to_anchor()

    def ai(self, surface, target):
        if self.is_final_boss:
            speed = 3.0
        elif self.is_boss:
            speed = 2.6
        elif self.lucky_skel:
            speed = 2.0
        else:
            speed = 1.6

        gravity = 0.75
        dx = 0
        dy = 0
        self.running = False

        if self.alive and not self.attacking:
            dist_to_player = target.rect.centerx - self.rect.centerx
            abs_dist = abs(dist_to_player)

            if abs_dist < 500:
                self.direction = 1 if dist_to_player > 0 else -1
                self.flip = self.direction == -1

            self.vision.center = (self.rect.centerx + 140 * self.direction, self.rect.centery)
            can_see = self.vision.colliderect(target.rect) and abs_dist < 350

            if can_see and not self.has_seen_player and not self.reacting:
                self.reacting = True
                self.has_seen_player = True
                self.frame_index = 0

            attack_range = self.rect.width * 0.7
            if can_see and not self.reacting:
                if abs_dist < attack_range and self.attack_cooldown <= 0:
                    if target.alive:
                        self.attacking = True
                        self.swing_started_this_attack = False
                        self.frame_index = 0
                else:
                    dx = speed * self.direction
                    self.running = True
            elif not self.reacting:
                if not self.idling and random.randint(1, 800) == 1:
                    self.idling = True
                    self.idling_counter = 60
                if not self.idling:
                    dx = speed * self.direction * 0.4
                    self.running = True
                    self.move_counter += 1
                    if self.move_counter > 60:
                        self.direction *= -1
                        self.flip = self.direction == -1
                        self.move_counter = 0
                else:
                    self.idling_counter -= 1
                    if self.idling_counter <= 0:
                        self.idling = False

        if self.swing_active:
            self._try_apply_swing([target])

        self.vel_y += gravity
        dy += self.vel_y
        ground_y = SCREEN_HEIGHT - 66
        if self.anchor_y + dy > ground_y:
            self.vel_y = 0
            self.jump = False
            dy = ground_y - self.anchor_y

        self.anchor_x += dx
        self.anchor_y += dy
        self._sync_rect_to_anchor()

    def _try_apply_swing(self, targets):
        if self.swing_locked_rect is None:
            return

        hit_anything = False

        for target in targets:
            if not getattr(target, "alive", False):
                continue

            target_id = id(target)
            if target_id in self.swing_hit_targets:
                continue

            if not self.swing_locked_rect.colliderect(target.rect):
                continue

            self._deal_damage(target)
            self.swing_hit_targets.add(target_id)
            hit_anything = True

            # Player swings should cleave through every enemy in the hitbox.
            # Enemy swings only need to hit the player once.
            if self.char_type != "Player":
                break

        if hit_anything:
            self.swing_dealt = True

    def _deal_damage(self, target):
        if self.char_type == "Player":
            if self.cheat_mode:
                is_crit = False
                dmg = max(1, int(getattr(target, "health", 1)))
            else:
                is_crit = random.random() < 0.15
                dmg = random.randint(self.base_dmg_min, self.base_dmg_max)
                if self.shrines_cleared > 0:
                    dmg = int(dmg * (1 + 0.08 * self.shrines_cleared))
                if self.fury_timer > 0:
                    dmg = int(dmg * 1.25)
                if self.double_dmg_timer > 0:
                    dmg *= 2
                if is_crit:
                    dmg = int(dmg * 1.8)
            target.health -= dmg
            target.hit = True
            target.frame_index = 0
            target.check_alive()
            self.events.append({"type": "hit_landed", "x": target.rect.centerx, "y": target.rect.top,
                                "damage": dmg, "crit": is_crit})

            if not target.alive and not target.collected:
                if target.is_final_boss:
                    self.score += 500
                    # Bosses always give health and have a chance to drop a power-up.
                    self.events.append({
                        "type": "final_boss_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "heal_amount": 100,
                        "drop_powerup": random.random() < 0.65,
                    })
                elif target.is_boss:
                    self.score += random.randint(150, 250)
                    # Bosses always give health and have a chance to drop a power-up.
                    self.events.append({
                        "type": "boss_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "heal_amount": random.randint(40, 60),
                        "drop_powerup": random.random() < 0.55,
                    })
                elif target.lucky_skel:
                    self.score += random.randint(40, 70)
                    # Lucky skeletons are the only normal enemy type that can reward health/power-ups.
                    # These are independent rolls, so getting both is possible but rare.
                    drop_health = random.random() < 0.30
                    drop_powerup = random.random() < 0.25
                    self.events.append({
                        "type": "enemy_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "lucky": True,
                        "heal_amount": random.randint(15, 25) if drop_health else 0,
                        "drop_powerup": drop_powerup,
                    })
                else:
                    self.score += random.randint(10, 16)
                    # Normal skeletons only give score. No health and no power-up drops.
                    self.events.append({
                        "type": "enemy_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "lucky": False,
                        "heal_amount": 0,
                        "drop_powerup": False,
                    })
                target.collected = True

        elif self.char_type == "Skeleton":
            if getattr(target, "cheat_mode", False):
                target.health = target.max_health
                return
            if target.shield_timer > 0:
                target.events.append({"type": "shield_block", "x": target.rect.centerx, "y": target.rect.top})
                target.hit = True
                target.frame_index = 0
                return
            if target.invuln_timer > 0:
                return
            dmg = random.randint(self.base_dmg_min, self.base_dmg_max)
            target.health -= dmg
            target.hit = True
            target.frame_index = 0
            target.invuln_timer = 30
            target.events.append({"type": "hit_taken", "x": target.rect.centerx, "y": target.rect.top, "damage": dmg})

    def draw_health_bar(self, surface, scroll_offset):
        if self.char_type == "Player" or not self.alive:
            return
        ratio = max(0, min(1, self.health / self.max_health))
        if self.is_final_boss:
            bar_len = 140
            bar_color = (255, 80, 30)
        elif self.is_boss:
            if self.boss_variant is not None and self.boss_variant < len(BOSS_VARIANTS):
                _, bar_color, _, _ = BOSS_VARIANTS[self.boss_variant]
            else:
                bar_color = GOLD
            bar_len = 110
        elif self.lucky_skel:
            bar_len = 80
            bar_color = (255, 200, 80)
        else:
            bar_len = 56
            bar_color = (80, 220, 100)

        screen_x = int(self.rect.centerx - scroll_offset - bar_len // 2)
        bar_y = self.rect.y - 12
        pygame.draw.rect(surface, BLACK, (screen_x - 1, bar_y, bar_len + 2, 6))
        pygame.draw.rect(surface, (50, 15, 15), (screen_x, bar_y + 1, bar_len, 4))
        pygame.draw.rect(surface, bar_color, (screen_x, bar_y + 1, int(bar_len * ratio), 4))

        if self.attack_cooldown > 0:
            cd_ratio = self.attack_cooldown / self.attack_cooldown_max
            cd_y = bar_y - 5
            pygame.draw.line(surface, (55, 45, 60), (screen_x, cd_y), (screen_x + bar_len, cd_y), 2)
            pygame.draw.line(surface, (200, 100, 200), (screen_x, cd_y),
                             (screen_x + int(bar_len * cd_ratio), cd_y), 2)

        if self.is_final_boss:
            label_text = "THE DAMNED KING"
            label_color = (255, 100, 50)
        elif self.is_boss and self.boss_variant is not None and self.boss_variant < len(BOSS_VARIANTS):
            name, primary_color, _, _ = BOSS_VARIANTS[self.boss_variant]
            label_text = name.upper()
            label_color = primary_color
        else:
            label_text = None
            label_color = None

        if label_text:
            font = _get_font(13)
            label = font.render(label_text, True, label_color)
            outline = font.render(label_text, True, BLACK)
            lx = self.rect.centerx - scroll_offset - label.get_width() // 2
            for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                surface.blit(outline, (lx + ox, bar_y - 18 + oy))
            surface.blit(label, (lx, bar_y - 18))

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.alive = False
            self._set_action(ACT_DEATH)

    def draw(self, surface, scroll_offset):
        screen_x = int(self.rect.x - scroll_offset)
        if screen_x < -self.rect.width or screen_x > SCREEN_WIDTH:
            return
        img = self.flipped_list[self.action][self.frame_index] if self.flip else self.image

        if (self.char_type == "Skeleton" and self.is_boss and not self.is_final_boss
                and self.boss_variant is not None and self.alive):
            name, aura_color, secondary_color, crown_style = BOSS_VARIANTS[self.boss_variant]
            cx = screen_x + img.get_width() // 2
            cy = self.rect.y + img.get_height() // 2
            t = pygame.time.get_ticks() * 0.004
            for i in range(3):
                radius = int(img.get_width() * 0.55 + math.sin(t + i) * 4 + i * 3)
                glow = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(glow, (*aura_color, max(6, 30 - i * 8)), (radius, radius), radius)
                surface.blit(glow, (cx - radius, cy - radius), special_flags=pygame.BLEND_RGBA_ADD)

        if self.char_type == "Skeleton" and self.is_final_boss and self.alive:
            cx = screen_x + img.get_width() // 2
            cy = self.rect.y + img.get_height() // 2
            t = pygame.time.get_ticks() * 0.005
            for i in range(4):
                radius = int(img.get_width() * 0.7 + math.sin(t + i) * 6 + i * 4)
                glow = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(glow, (255, 80 - i * 15, 30, 25), (radius, radius), radius)
                surface.blit(glow, (cx - radius, cy - radius), special_flags=pygame.BLEND_RGBA_ADD)

        if self.alive:
            # -------------------------
            # BEHIND PLAYER EFFECTS
            # -------------------------
            if self.char_type == "Player" and self.cheat_mode:
                self._draw_godmode_tracers(surface, screen_x, img)
                self._draw_godmode_glow(surface, screen_x, img)

                if self.covenant_fx_timer > 0:
                    self._draw_covenant_descent(surface, screen_x, img)

            if self.char_type == "Player" and self.speed_boost_timer > 0:
                self._draw_speed_aura(surface, screen_x, img)

            if self.char_type == "Player" and self.double_dmg_timer > 0:
                self._draw_strength_aura(surface, screen_x, img)

            if self.char_type == "Player" and self.fury_timer > 0:
                self._draw_fury_aura(surface, screen_x, img)

            if self.char_type == "Player" and self.ethereal_glow_timer > 0:
                self._draw_ethereal_descent(surface, screen_x, img)

            if self.char_type == "Player":
                self._draw_shrine_sigils(surface, screen_x, img, layer="back")

            # -------------------------
            # PLAYER SPRITE
            # -------------------------
            surface.blit(img, (screen_x, self.rect.y))

            # -------------------------
            # ON-TOP PLAYER EFFECTS
            # -------------------------

            # Put godmode core first so other buffs can still show over it
            if self.char_type == "Player" and self.cheat_mode:
                self._draw_godmode_core(surface, screen_x, img)

            if self.char_type == "Player" and self.shield_timer > 0:
                self._draw_shield(surface, screen_x, img)

            if self.char_type == "Player" and self.double_dmg_timer > 0:
                self._draw_strength_core(surface, screen_x, img)

            if self.char_type == "Player" and self.invuln_timer > 0:
                self._draw_damage_flash(surface, screen_x, img)

            if self.char_type == "Player":
                self._draw_shrine_sigils(surface, screen_x, img, layer="front")
                self._draw_player_cooldown(surface, scroll_offset)

            # -------------------------
            # BOSS CROWNS
            # -------------------------
            if (self.char_type == "Skeleton" and self.is_boss and not self.is_final_boss
                    and self.boss_variant is not None):
                name, aura_color, secondary_color, crown_style = BOSS_VARIANTS[self.boss_variant]
                draw_boss_crown(
                    surface,
                    screen_x,
                    self.rect.y,
                    img.get_width(),
                    crown_style,
                    aura_color,
                    time_offset=self.boss_variant * 0.7
                )

            elif self.char_type == "Skeleton" and self.is_final_boss:
                draw_final_boss_crown(surface, screen_x, self.rect.y, img.get_width())

        elif self.respawn_timer < 250:
            self.respawn_timer += 1
            rest_y = self.anchor_y - img.get_height()
            surface.blit(img, (screen_x, rest_y))

    def _draw_player_cooldown(self, surface, scroll_offset):
        if self.char_type != "Player" or self.attack_cooldown <= 0 or self.attack_cooldown_max <= 0:
            return
        ratio = max(0, min(1, self.attack_cooldown / self.attack_cooldown_max))
        bar_w = self.cooldown_bar_w
        bar_x = int(self.anchor_x - scroll_offset - bar_w // 2)
        bar_y = int(self.anchor_y - self.body_visual_h - 10)
        # No box. Fixed width and fixed anchor-based position, so it no longer
        # grows/shrinks or jitters when the sprite frame changes.
        pygame.draw.line(surface, (70, 70, 80), (bar_x, bar_y), (bar_x + bar_w, bar_y), 2)
        pygame.draw.line(surface, (180, 210, 255), (bar_x, bar_y),
                         (bar_x + int(bar_w * ratio), bar_y), 2)

    def _draw_shield(self, surface, screen_x, img):
        """Transparent blue shield layered over the player sprite, fixed size and tied to the model."""
        mask = pygame.mask.from_surface(img)
        glow = mask.to_surface(setcolor=(SHIELD_BLUE[0], SHIELD_BLUE[1], SHIELD_BLUE[2], 22),
                               unsetcolor=(0, 0, 0, 0)).convert_alpha()
        core = mask.to_surface(setcolor=(SHIELD_BLUE[0], SHIELD_BLUE[1], SHIELD_BLUE[2], 45),
                               unsetcolor=(0, 0, 0, 0)).convert_alpha()
        for ox, oy in [(-2, 0), (2, 0), (0, -2), (0, 2), (-1, -1), (1, -1), (-1, 1), (1, 1)]:
            surface.blit(glow, (screen_x + ox, self.rect.y + oy), special_flags=pygame.BLEND_RGBA_ADD)
        surface.blit(core, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)
        
    def _draw_godmode_tracers(self, surface, screen_x, img):
        trail_dir = -self.direction
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2
        t = pygame.time.get_ticks() * 0.02

        if self.running:
            for i in range(4):
                line_len = 10 + i * 6
                line_x = cx + trail_dir * (12 + i * 8)
                line_y = cy - 10 + i * 7 + math.sin(t + i * 0.8) * 2

                pygame.draw.line(surface, (235, 210, 110),
                                 (line_x, line_y),
                                 (line_x + trail_dir * line_len, line_y), 2)

                pygame.draw.line(surface, (255, 245, 180),
                                 (line_x, line_y - 1),
                                 (line_x + trail_dir * max(4, line_len - 4), line_y - 1), 1)
        else:
            foot_y = self.rect.y + img.get_height() - 6
            for i in range(2):
                spark_x = cx + math.cos(t * 0.7 + i * math.pi) * 6
                spark = pygame.Surface((10, 10), pygame.SRCALPHA)
                pygame.draw.circle(spark, (240, 215, 120, 55), (5, 5), 3)
                pygame.draw.circle(spark, (255, 245, 180, 110), (5, 5), 1)
                surface.blit(spark, (spark_x - 5, foot_y - 5), special_flags=pygame.BLEND_RGBA_ADD)


    def _draw_godmode_glow(self, surface, screen_x, img):
        mask = pygame.mask.from_surface(img)
        glow = mask.to_surface(setcolor=(235, 205, 110, 18), unsetcolor=(0, 0, 0, 0)).convert_alpha()
        for ox, oy in [(-2, 0), (2, 0), (0, -2), (0, 2), (-2, -1), (2, -1), (-1, 2), (1, 2)]:
            surface.blit(glow, (screen_x + ox, self.rect.y + oy), special_flags=pygame.BLEND_RGBA_ADD)


    def _draw_godmode_core(self, surface, screen_x, img):
        mask = pygame.mask.from_surface(img)
        core = mask.to_surface(setcolor=(255, 235, 150, 26), unsetcolor=(0, 0, 0, 0)).convert_alpha()
        surface.blit(core, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)


    def _draw_covenant_descent(self, surface, screen_x, img):
        progress = 1.0 - max(0, self.covenant_fx_timer) / 180.0
        cx = screen_x + img.get_width() // 2
        top_y = self.rect.y - 120
        bottom_y = self.rect.y + img.get_height()

        beam_w = img.get_width() + 20
        beam_h = bottom_y - top_y
        beam = pygame.Surface((beam_w, beam_h), pygame.SRCALPHA)

        # soft heavenly column
        for x in range(0, beam_w, 4):
            alpha = 20 + int(25 * math.sin((x * 0.2) + pygame.time.get_ticks() * 0.01))
            pygame.draw.line(beam, (255, 240, 180, max(0, min(55, alpha))), (x, 0), (x, beam_h), 2)

        # dripping ichor
        drip_base = int(progress * (beam_h + 40)) - 40
        for i in range(7):
            drip_x = 8 + i * ((beam_w - 16) // 6)
            drip_y = drip_base - i * 10
            pygame.draw.line(beam, (255, 225, 130, 130), (drip_x, max(0, drip_y - 16)), (drip_x, min(beam_h, drip_y)), 2)
            pygame.draw.circle(beam, (255, 240, 170, 180), (drip_x, max(0, min(beam_h - 1, drip_y))), 3)

        surface.blit(beam, (cx - beam_w // 2, top_y), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_strength_aura(self, surface, screen_x, img):
        mask = pygame.mask.from_surface(img)
        glow = mask.to_surface(setcolor=(255, 110, 70, 18), unsetcolor=(0, 0, 0, 0)).convert_alpha()
        for ox, oy in [(-2, 0), (2, 0), (0, -2), (0, 2), (-2, -1), (2, -1), (-1, 2), (1, 2)]:
            surface.blit(glow, (screen_x + ox, self.rect.y + oy), special_flags=pygame.BLEND_RGBA_ADD)

        cx = screen_x + img.get_width() // 2 + self.direction * int(img.get_width() * 0.30)
        cy = self.rect.y + int(img.get_height() * 0.62)
        t = pygame.time.get_ticks() * 0.01
        for i in range(4):
            ang = t + i * 1.55
            ember_x = cx + math.cos(ang) * 6 + self.direction * 3
            ember_y = cy + math.sin(ang * 1.4) * 8
            size = 2 + (i % 2)
            ember = pygame.Surface((size * 6, size * 6), pygame.SRCALPHA)
            pygame.draw.circle(ember, (255, 90, 50, 90), (size * 3, size * 3), size * 2)
            pygame.draw.circle(ember, (255, 205, 120, 180), (size * 3, size * 3), size)
            surface.blit(ember, (ember_x - size * 3, ember_y - size * 3),
                         special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_strength_core(self, surface, screen_x, img):
        mask = pygame.mask.from_surface(img)
        core = mask.to_surface(setcolor=(255, 165, 95, 26), unsetcolor=(0, 0, 0, 0)).convert_alpha()
        surface.blit(core, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_speed_aura(self, surface, screen_x, img):
        trail_dir = -self.direction
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2
        t = pygame.time.get_ticks() * 0.02

        if self.running:
            # Clean speed lines behind the player instead of a full-body glow.
            for i in range(4):
                line_len = 10 + i * 6
                line_x = cx + trail_dir * (12 + i * 8)
                line_y = cy - 10 + i * 7 + math.sin(t + i * 0.8) * 2

                pygame.draw.line(
                    surface,
                    (90, 220, 240),
                    (line_x, line_y),
                    (line_x + trail_dir * line_len, line_y),
                    2
                )

                pygame.draw.line(
                    surface,
                    (200, 250, 255),
                    (line_x, line_y - 1),
                    (line_x + trail_dir * max(4, line_len - 4), line_y - 1),
                    1
                )

            # Small foot streaks so the buff still reads as active when moving.
            foot_y = self.rect.y + img.get_height() - 6
            for i in range(2):
                streak_x = cx + trail_dir * (8 + i * 10)
                streak_y = foot_y + i * 2

                pygame.draw.line(
                    surface,
                    (120, 235, 255),
                    (streak_x, streak_y),
                    (streak_x + trail_dir * (8 + i * 4), streak_y),
                    2
                )

        else:
            # Idle state: tiny hint near the feet, not a shield-like body glow.
            foot_y = self.rect.y + img.get_height() - 6

            for i in range(2):
                spark_x = cx + math.cos(t * 0.7 + i * math.pi) * 6
                spark = pygame.Surface((10, 10), pygame.SRCALPHA)
                pygame.draw.circle(spark, (120, 235, 255, 55), (5, 5), 3)
                pygame.draw.circle(spark, (220, 250, 255, 110), (5, 5), 1)

                surface.blit(
                    spark,
                    (spark_x - 5, foot_y - 5),
                    special_flags=pygame.BLEND_RGBA_ADD
                )
    def _draw_damage_flash(self, surface, screen_x, img):
        """Red damage flash that follows only the visible sprite pixels.
        This avoids the ugly red square/box that happens when tinting the
        whole transparent sprite surface.
        """
        if self.invuln_timer <= 0:
            return

        alpha = 70 if (self.invuln_timer // 4) % 2 == 0 else 35
        mask = pygame.mask.from_surface(img)
        flash = mask.to_surface(
            setcolor=(255, 65, 55, alpha),
            unsetcolor=(0, 0, 0, 0)
        ).convert_alpha()
        surface.blit(flash, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_fury_aura(self, surface, screen_x, img):
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2
        t = pygame.time.get_ticks() * 0.006
        for i in range(3):
            angle = t + i * 2.1
            wisp_x = cx + math.cos(angle) * (img.get_width() // 2 + 4)
            wisp_y = cy + math.sin(angle * 1.3) * (img.get_height() // 3) - 4
            size = 4 + int(math.sin(t * 2 + i) * 2)
            s = pygame.Surface((size * 4, size * 4), pygame.SRCALPHA)
            pygame.draw.circle(s, (255, 80, 30, 120), (size * 2, size * 2), size)
            pygame.draw.circle(s, (255, 200, 80, 200), (size * 2, size * 2), max(1, size // 2))
            surface.blit(s, (wisp_x - size * 2, wisp_y - size * 2), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_ethereal_descent(self, surface, screen_x, img):
        if self.ethereal_glow_timer <= 0:
            return
        max_t = 120
        progress = max(0, min(1, 1.0 - self.ethereal_glow_timer / max_t))
        cx = screen_x + img.get_width() // 2
        body_cy = self.rect.y + img.get_height() // 2

        if progress < 0.4:
            descent_t = progress / 0.4
            orb_y = self.rect.y - 80 + descent_t * 80
            for i in range(6):
                trail_y = orb_y - i * 6
                alpha = max(0, 180 - i * 25)
                size = max(2, 8 - i)
                s = pygame.Surface((size * 4, size * 4), pygame.SRCALPHA)
                pygame.draw.circle(s, (255, 60, 40, alpha), (size * 2, size * 2), size * 2)
                pygame.draw.circle(s, (255, 180, 100, alpha), (size * 2, size * 2), size)
                surface.blit(s, (cx - size * 2, trail_y - size * 2), special_flags=pygame.BLEND_RGBA_ADD)
        elif progress < 0.7:
            absorb_t = (progress - 0.4) / 0.3
            intensity = math.sin(absorb_t * math.pi)
            alpha = int(140 * intensity)
            glow_w = img.get_width() + 16
            glow_h = img.get_height() + 16
            glow = pygame.Surface((glow_w, glow_h), pygame.SRCALPHA)
            for r in range(5, 0, -1):
                layer_alpha = max(0, alpha - r * 20)
                pygame.draw.ellipse(glow, (255, 50, 30, layer_alpha), (r, r, glow_w - r * 2, glow_h - r * 2))
            surface.blit(glow, (screen_x - 8, self.rect.y - 8), special_flags=pygame.BLEND_RGBA_ADD)
            t = pygame.time.get_ticks() * 0.01
            for i in range(5):
                ang = t + i * (math.tau / 5)
                wisp_x = cx + math.cos(ang) * (img.get_width() // 2 + 6)
                wisp_y = body_cy + math.sin(ang * 2) * (img.get_height() // 3)
                size = 4
                s = pygame.Surface((size * 4, size * 4), pygame.SRCALPHA)
                pygame.draw.circle(s, (255, 60, 40, alpha), (size * 2, size * 2), size * 2)
                pygame.draw.circle(s, (255, 180, 100, alpha), (size * 2, size * 2), size)
                surface.blit(s, (wisp_x - size * 2, wisp_y - size * 2), special_flags=pygame.BLEND_RGBA_ADD)
        else:
            fade_t = (progress - 0.7) / 0.3
            alpha = int(100 * (1 - fade_t))
            if alpha > 0:
                glow_w = img.get_width() + 12
                glow_h = img.get_height() + 12
                glow = pygame.Surface((glow_w, glow_h), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (255, 50, 30, alpha), (0, 0, glow_w, glow_h))
                surface.blit(glow, (screen_x - 6, self.rect.y - 6), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_shrine_sigils(self, surface, screen_x, img, layer="front"):
        if self.shrines_cleared <= 0:
            return

        orb_count = self.shrines_cleared

        # center of the orbit around upper torso / chest
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + int(img.get_height() * 0.38)

        # ellipse size
        radius_x = max(20, int(img.get_width() * 0.55))
        radius_y = max(16, int(img.get_height() * 0.3))

        t = pygame.time.get_ticks() * 0.0045

        orbiters = []
        for i in range(orb_count):
            angle = t + (i * math.tau / orb_count)

            sx = cx + math.cos(angle) * radius_x
            sy = cy + math.sin(angle) * radius_y

            # lower half of the ellipse = front
            # upper half = back
            in_front = math.sin(angle) > 0

            if layer == "front" and not in_front:
                continue
            if layer == "back" and in_front:
                continue

            # make back orbs a little smaller/dimmer
            if in_front:
                size = 5
                glow_alpha = 80
            else:
                size = 4
                glow_alpha = 45

            orbiters.append((sx, sy, size, glow_alpha))

        for sx, sy, size, glow_alpha in orbiters:
            glow = pygame.Surface((size * 4, size * 4), pygame.SRCALPHA)
            pygame.draw.circle(glow, (255, 70, 50, glow_alpha), (size * 2, size * 2), size * 2)
            pygame.draw.circle(glow, (255, 140, 110, glow_alpha // 2), (size * 2, size * 2), size + 1)
            surface.blit(glow, (sx - size * 2, sy - size * 2), special_flags=pygame.BLEND_RGBA_ADD)

            pygame.draw.circle(surface, (245, 120, 100), (int(sx), int(sy)), size)
            pygame.draw.circle(surface, (255, 175, 150), (int(sx), int(sy)), max(2, size - 2))
            pygame.draw.line(surface, (170, 35, 30), (int(sx), int(sy - size + 1)), (int(sx), int(sy + size - 1)), 1)
            pygame.draw.line(surface, (170, 35, 30), (int(sx - size + 1), int(sy)), (int(sx + size - 1), int(sy)), 1)
            pygame.draw.circle(surface, (255, 225, 200), (int(sx), int(sy)), 1)

CHEST_BODY = (110, 70, 35)
CHEST_LID = (75, 45, 20)
CHEST_BAND = (50, 30, 15)
CHEST_GOLD = (255, 200, 60)
CHEST_HIGHLIGHT = (160, 110, 60)


class TreasureChest:
    def __init__(self, x, y, guarded=False):
        self.world_x = x
        self.y = y
        self.width = 52
        self.height = 40
        self.rect = pygame.Rect(self.world_x, self.y - self.height, self.width, self.height)
        self.opened = False
        self.collected = False
        self.open_timer = 0
        self.display_timer = 90
        self.reward_text = ""
        self.reward_color = GREEN
        self.guarded = guarded
        self.guard_alive = guarded
        self._closed = self._build_closed()
        self._open = self._build_open()

    def _build_closed(self):
        surf = pygame.Surface((self.width + 4, self.height + 4), pygame.SRCALPHA)
        w, h = self.width, self.height
        ox, oy = 2, 2
        pygame.draw.rect(surf, CHEST_BODY, (ox, oy, w, h), border_radius=5)
        pygame.draw.rect(surf, CHEST_LID, (ox, oy, w, h // 2), border_radius=5)
        for gx in range(ox + 6, ox + w - 6, 8):
            pygame.draw.line(surf, CHEST_HIGHLIGHT, (gx, oy + h // 2 + 2), (gx, oy + h - 4), 1)
        pygame.draw.rect(surf, CHEST_BAND, (ox, oy + h // 2 - 2, w, 4))
        for cx, cy in [(ox + 4, oy + 4), (ox + w - 6, oy + 4), (ox + 4, oy + h - 6), (ox + w - 6, oy + h - 6)]:
            pygame.draw.circle(surf, CHEST_GOLD, (cx, cy), 2)
        lx, ly = ox + w // 2, oy + h // 2
        pygame.draw.rect(surf, CHEST_GOLD, (lx - 5, ly - 4, 10, 10), border_radius=2)
        pygame.draw.rect(surf, CHEST_BAND, (lx - 5, ly - 4, 10, 10), 1, border_radius=2)
        pygame.draw.circle(surf, CHEST_BAND, (lx, ly + 1), 2)
        pygame.draw.rect(surf, CHEST_BAND, (ox, oy, w, h), 2, border_radius=5)
        return surf.convert_alpha()

    def _build_open(self):
        surf = pygame.Surface((self.width + 4, self.height + 16), pygame.SRCALPHA)
        w, h = self.width, self.height
        ox, oy = 2, 14
        glow = pygame.Surface((w, h // 2 + 4), pygame.SRCALPHA)
        for r in range(6):
            pygame.draw.ellipse(glow, (255, 220, 100, max(0, 25 - r * 4)),
                                (r * 2, r * 2, w - r * 4, h // 2 + 4 - r * 4))
        surf.blit(glow, (ox, oy + 4))
        pygame.draw.rect(surf, CHEST_BODY, (ox, oy + h // 3, w, h * 2 // 3), border_radius=4)
        pygame.draw.rect(surf, CHEST_BAND, (ox, oy + h // 3, w, h * 2 // 3), 2, border_radius=4)
        lid_pts = [(ox + 2, oy + h // 3), (ox + w - 2, oy + h // 3), (ox + w - 4, oy - 12), (ox + 4, oy - 12)]
        pygame.draw.polygon(surf, CHEST_LID, lid_pts)
        pygame.draw.polygon(surf, CHEST_BAND, lid_pts, 2)
        for px, py in [(ox + 12, oy + h // 3), (ox + 24, oy + h // 3 - 2), (ox + 36, oy + h // 3)]:
            pygame.draw.circle(surf, CHEST_GOLD, (px, py), 4)
        return surf.convert_alpha()

    def can_open(self, lucky_skeleton=None):
        if not self.guarded:
            return True
        if lucky_skeleton is None or not lucky_skeleton.alive:
            self.guard_alive = False
            return True
        return False

    def check_collect(self, player, particles, powerups, lucky_skeleton=None):
        if self.opened or not self.rect.colliderect(player.rect):
            return
        if not self.can_open(lucky_skeleton):
            return
        self.opened = True
        # Chests only give health or power-ups now. No score/coin rewards.
        # Health is slightly more common so a rare chest usually feels useful.
        roll = "powerup" if self.guarded else random.choices(
            ["heal", "powerup"],
            weights=[60, 40],
            k=1
        )[0]

        if roll == "heal":
            heal = random.randint(20, 45)
            player.health = min(player.max_health, player.health + heal)
            self.reward_text = f"+{heal} HP"
            self.reward_color = (80, 230, 100)
            for _ in range(5):
                particles.append(Particle(self.world_x + self.width // 2, self.rect.y, "heart"))
        else:
            kind = random.choice(["speed", "damage", "shield"])
            powerups.append(PowerUp(self.world_x + self.width // 2, self.rect.y - 10, kind))
            self.reward_text = "POWER-UP!"
            self.reward_color = SHIELD_BLUE

    def update(self):
        if self.opened:
            self.open_timer += 1
            if self.open_timer > self.display_timer:
                self.collected = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        if sx < -self.width or sx > SCREEN_WIDTH + self.width:
            return
        if not self.opened:
            surface.blit(self._closed, (sx - 2, self.rect.y - 2))
        else:
            surface.blit(self._open, (sx - 2, self.rect.y - 14))
            if self.open_timer < self.display_timer:
                font = _get_font(18)
                float_offset = min(self.open_timer, 30)
                txt = font.render(self.reward_text, True, self.reward_color)
                outline = font.render(self.reward_text, True, BLACK)
                ox_pos = sx + self.width // 2 - txt.get_width() // 2
                oy_pos = self.rect.y - 30 - float_offset
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    surface.blit(outline, (ox_pos + dx, oy_pos + dy))
                surface.blit(txt, (ox_pos, oy_pos))


class DemonicTower:
    WIDTH = 90
    HEIGHT = 220

    def __init__(self, world_x, ground_y, tier_index, is_final=False):
        self.world_x = world_x
        self.ground_y = ground_y
        self.tier_index = tier_index
        self.is_final = is_final
        self.rect = pygame.Rect(world_x - self.WIDTH // 2, ground_y - self.HEIGHT, self.WIDTH, self.HEIGHT)
        self.bound = True
        self.activating = False
        self.activated = False
        self.channel_progress = 0
        self.channel_max = 180
        rng = random.Random(world_x)
        self.eye_positions = [(rng.randint(-self.WIDTH // 2 + 12, self.WIDTH // 2 - 12),
                               rng.randint(20, self.HEIGHT - 30), rng.uniform(0, math.tau))
                              for _ in range(6)]

    def update(self, player, boss):
        if self.activated:
            return None
        if self.bound and (boss is None or not boss.alive):
            self.bound = False
        if not self.bound and not self.activated:
            touching = self.rect.colliderect(player.rect)
            if touching:
                self.activating = True
                self.channel_progress += 1
                if self.channel_progress >= self.channel_max:
                    self.activated = True
                    return "activated"
            else:
                self.channel_progress = max(0, self.channel_progress - 2)
                self.activating = self.channel_progress > 0
        return None

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset - self.WIDTH // 2)
        if sx < -self.WIDTH * 2 or sx > SCREEN_WIDTH + self.WIDTH:
            return
        t = pygame.time.get_ticks() * 0.001
        top_y = self.rect.y
        bx, by, base_w = sx, top_y, self.WIDTH

        if self.activated:
            for r in range(5, 0, -1):
                radius = self.WIDTH + r * 12
                aura = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(aura, (255, 60, 20, 18), (radius, radius), radius)
                surface.blit(aura, (sx + self.WIDTH // 2 - radius, top_y + self.HEIGHT // 2 - radius),
                             special_flags=pygame.BLEND_RGBA_ADD)
        elif self.activating:
            progress = self.channel_progress / self.channel_max
            for r in range(4, 0, -1):
                radius = int(self.WIDTH * 0.7 + r * 10 + math.sin(t * 6) * 4)
                aura = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(aura, (255, 200, 80, int(30 * progress)), (radius, radius), radius)
                surface.blit(aura, (sx + self.WIDTH // 2 - radius, top_y + self.HEIGHT // 2 - radius),
                             special_flags=pygame.BLEND_RGBA_ADD)
        elif self.bound:
            pulse = (math.sin(t * 1.5) + 1) * 0.5
            radius = int(self.WIDTH * 0.6 + pulse * 6)
            aura = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(aura, (90, 30, 110, 50), (radius, radius), radius)
            surface.blit(aura, (sx + self.WIDTH // 2 - radius, top_y + self.HEIGHT // 2 - radius))

        body_color = (15, 8, 12) if not self.activated else (35, 10, 8)
        highlight = (50, 30, 50) if not self.activated else (90, 25, 15)
        top_w = int(self.WIDTH * 0.5)
        body_pts = [
            (bx + 4, by + self.HEIGHT), (bx, by + self.HEIGHT - 30), (bx + 6, by + self.HEIGHT - 80),
            (bx, by + self.HEIGHT - 130), (bx + 8, by + 60), (bx + (base_w - top_w) // 2, by + 30),
            (bx + base_w // 2 - 6, by + 5), (bx + base_w // 2 + 4, by - 4),
            (bx + base_w // 2 + 14, by + 8), (bx + base_w - (base_w - top_w) // 2, by + 30),
            (bx + base_w - 6, by + 60), (bx + base_w + 2, by + 130),
            (bx + base_w - 4, by + self.HEIGHT - 80), (bx + base_w + 2, by + self.HEIGHT - 30),
            (bx + base_w - 6, by + self.HEIGHT),
        ]
        pygame.draw.polygon(surface, body_color, body_pts)
        pygame.draw.polygon(surface, highlight, body_pts, 2)

        rng = random.Random(self.world_x + 1)
        for _ in range(8 if self.activated else 4):
            cx = bx + rng.randint(10, base_w - 10)
            cy_start = by + rng.randint(20, self.HEIGHT - 20)
            cy_end = cy_start + rng.randint(20, 50)
            crack_color = (140, 30, 20) if self.activated else (60, 30, 60)
            pygame.draw.line(surface, crack_color, (cx, cy_start), (cx + rng.randint(-5, 5), cy_end), 2)
            if self.activated:
                pygame.draw.line(surface, (255, 100, 30), (cx, cy_start), (cx + rng.randint(-5, 5), cy_end), 1)

        eye_phase = "closed" if self.bound else ("opening" if self.activating else "open")
        for ex, ey, twitch_seed in self.eye_positions:
            eye_x = bx + base_w // 2 + ex
            eye_y = by + ey
            if eye_phase == "closed":
                pygame.draw.line(surface, (60, 20, 30), (eye_x - 5, eye_y), (eye_x + 5, eye_y), 2)
            elif eye_phase == "opening":
                progress = self.channel_progress / self.channel_max
                eye_h = int(2 + progress * 6)
                pygame.draw.ellipse(surface, (200, 200, 220), (eye_x - 5, eye_y - eye_h // 2, 10, eye_h))
            else:
                pygame.draw.ellipse(surface, (220, 210, 200), (eye_x - 6, eye_y - 5, 12, 10))
                pdx = int(math.cos(t * 2 + twitch_seed) * 2)
                pdy = int(math.sin(t * 1.7 + twitch_seed) * 1)
                pygame.draw.circle(surface, (180, 30, 20), (eye_x + pdx, eye_y + pdy), 3)
                pygame.draw.circle(surface, BLACK, (eye_x + pdx, eye_y + pdy), 2)
                pygame.draw.circle(surface, WHITE, (eye_x + pdx - 1, eye_y + pdy - 1), 1)

        mex = bx + base_w // 2
        mey = by + 40
        if eye_phase == "closed":
            pygame.draw.line(surface, (80, 30, 40), (mex, mey - 12), (mex, mey + 12), 4)
        else:
            progress = (self.channel_progress / self.channel_max) if eye_phase == "opening" else 1.0
            eye_w = int(20 + progress * 8)
            eye_h = int(8 + progress * 14)
            pygame.draw.ellipse(surface, (240, 220, 200), (mex - eye_w // 2, mey - eye_h // 2, eye_w, eye_h))
            iris_r = int(4 + progress * 4)
            pygame.draw.circle(surface, (200, 40, 20), (mex, mey), iris_r)
            pygame.draw.circle(surface, BLACK, (mex, mey), max(2, iris_r - 2))

        for sign in (-1, 1):
            pygame.draw.polygon(surface, (10, 5, 8), [
                (bx + base_w // 2 + 8 * sign, by + 4),
                (bx + base_w // 2 + 22 * sign, by - 18),
                (bx + base_w // 2 + 14 * sign, by - 5),
            ])

        mouth_y = by + self.HEIGHT - 60
        mouth_x = bx + base_w // 2
        if eye_phase == "open":
            maw_pts = [(mouth_x - 14, mouth_y), (mouth_x - 10, mouth_y - 4), (mouth_x, mouth_y - 6),
                       (mouth_x + 10, mouth_y - 4), (mouth_x + 14, mouth_y), (mouth_x + 8, mouth_y + 12),
                       (mouth_x, mouth_y + 16), (mouth_x - 8, mouth_y + 12)]
            pygame.draw.polygon(surface, (10, 0, 0), maw_pts)
            for i in range(-2, 3):
                tx = mouth_x + i * 5
                pygame.draw.polygon(surface, (220, 210, 190), [(tx - 1, mouth_y - 1), (tx + 1, mouth_y - 1), (tx, mouth_y + 4)])
                pygame.draw.polygon(surface, (220, 210, 190), [(tx - 1, mouth_y + 14), (tx + 1, mouth_y + 14), (tx, mouth_y + 9)])
        else:
            pygame.draw.line(surface, (40, 10, 10), (mouth_x - 14, mouth_y + 3), (mouth_x + 14, mouth_y + 3), 3)

        if self.activating and not self.activated:
            progress = self.channel_progress / self.channel_max
            bar_w, bar_h = 100, 6
            bar_x = bx + base_w // 2 - bar_w // 2
            bar_y = by - 30
            pygame.draw.rect(surface, (10, 5, 5), (bar_x - 2, bar_y - 2, bar_w + 4, bar_h + 4))
            pygame.draw.rect(surface, (40, 10, 10), (bar_x, bar_y, bar_w, bar_h))
            pygame.draw.rect(surface, (255, 100, 30), (bar_x, bar_y, int(bar_w * progress), bar_h))
            if self.is_final:
                shrine_text = "UNLEASHING THE CHAINS OF THE ANCIENT ONES"
                shrine_color = (170, 0, 0)       # blood red
                shadow_color = (30, 0, 0)
                label_font = _get_font(9)
            else:
                shrine_text = "EXORCISING"
                shrine_color = (255, 180, 80)
                shadow_color = (10, 5, 5)
                label_font = _get_font(11)

            label = label_font.render(shrine_text, True, shrine_color)
            shadow = label_font.render(shrine_text, True, shadow_color)

            label_x = bar_x + bar_w // 2 - label.get_width() // 2
            label_y = bar_y - 16

            # shadow/outline
            for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1), (2, 2)]:
                surface.blit(shadow, (label_x + ox, label_y + oy))

            surface.blit(label, (label_x, label_y))
            if self.is_final:
                hint_text = "DON'T DO IT"
                hint_font = _get_font(10)
                hint = hint_font.render(hint_text, True, (190, 0, 0))
                hint_shadow = hint_font.render(hint_text, True, (20, 0, 0))

                hint_x = bar_x + bar_w // 2 - hint.get_width() // 2
                hint_y = bar_y - 32

                for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    surface.blit(hint_shadow, (hint_x + ox, hint_y + oy))

                surface.blit(hint, (hint_x, hint_y))


def _build_particle_frames():
    frames = {"coin": [], "heart": None}
    for i in range(8):
        squash = abs(math.cos(i * math.pi / 8))
        w = max(2, int(14 * squash))
        h = 14
        surf = pygame.Surface((16, 16), pygame.SRCALPHA)
        ox = (16 - w) // 2
        oy = (16 - h) // 2
        pygame.draw.ellipse(surf, COIN_DARK, (ox - 1, oy - 1, w + 2, h + 2))
        pygame.draw.ellipse(surf, COIN_GOLD, (ox, oy, w, h))
        if w > 4:
            pygame.draw.ellipse(surf, (255, 240, 150), (ox + 1, oy + 1, max(2, w // 3), max(2, h // 3)))
        frames["coin"].append(surf.convert_alpha())
    size = 14
    heart_surf = pygame.Surface((size + 2, size + 2), pygame.SRCALPHA)
    r = size // 4
    pygame.draw.circle(heart_surf, HEART_RED, (r + 1, r + 2), r)
    pygame.draw.circle(heart_surf, HEART_RED, (size - r + 1, r + 2), r)
    pygame.draw.polygon(heart_surf, HEART_RED, [(1, r + 2), (size + 1, r + 2), (size // 2 + 1, size + 1)])
    pygame.draw.circle(heart_surf, (255, 200, 210), (r, r + 1), max(1, r // 2))
    frames["heart"] = heart_surf.convert_alpha()
    return frames


def _get_particle_frames():
    global _PARTICLE_FRAMES
    if _PARTICLE_FRAMES is None:
        _PARTICLE_FRAMES = _build_particle_frames()
    return _PARTICLE_FRAMES


class Particle:
    LIFETIME = 60

    def __init__(self, world_x, world_y, kind):
        self.world_x = world_x
        self.world_y = world_y
        self.kind = kind
        angle = random.uniform(-2.6, -0.6)
        speed = random.uniform(3.5, 6.0)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.life = 0
        self.dead = False
        self.spin_offset = random.randint(0, 7)
        self.spin_speed = random.uniform(0.5, 1.0)

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.25
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -20 or sx > SCREEN_WIDTH + 20:
            return
        frames = _get_particle_frames()
        img = frames["coin"][(int(self.life * self.spin_speed) + self.spin_offset) % 8] if self.kind == "coin" else frames["heart"]
        if self.life > self.LIFETIME * 0.66:
            t = (self.life - self.LIFETIME * 0.66) / (self.LIFETIME * 0.34)
            img = img.copy()
            img.set_alpha(max(0, int(255 * (1 - t))))
        surface.blit(img, (sx - img.get_width() // 2, sy - img.get_height() // 2))


class Spark:
    LIFETIME = 18

    def __init__(self, world_x, world_y, color=(255, 220, 100)):
        self.world_x = world_x
        self.world_y = world_y
        angle = random.uniform(0, math.tau)
        speed = random.uniform(2, 6)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed - 1
        self.life = 0
        self.color = color
        self.dead = False

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.3
        self.vx *= 0.92
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -10 or sx > SCREEN_WIDTH + 10:
            return
        t = 1 - self.life / self.LIFETIME
        size = max(1, int(4 * t))
        pygame.draw.circle(surface, self.color, (sx, sy), size)


def _get_damage_surf(text, color, size):
    key = (text, color, size)
    if key not in _DAMAGE_TEXT_CACHE:
        font = _get_font(size)
        main = font.render(text, True, color).convert_alpha()
        outline = font.render(text, True, BLACK).convert_alpha()
        _DAMAGE_TEXT_CACHE[key] = (main, outline)
        if len(_DAMAGE_TEXT_CACHE) > 100:
            _DAMAGE_TEXT_CACHE.pop(next(iter(_DAMAGE_TEXT_CACHE)))
    return _DAMAGE_TEXT_CACHE[key]


class DamageNumber:
    LIFETIME = 50

    def __init__(self, world_x, world_y, text, color=(255, 230, 80), big=False):
        self.world_x = world_x + random.randint(-15, 15)
        self.world_y = world_y
        self.vx = random.uniform(-0.6, 0.6)
        self.vy = -2.2
        self.text = text
        self.color = color
        self.big = big
        self.life = 0
        self.dead = False
        self.size = 28 if big else 20

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.08
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -50 or sx > SCREEN_WIDTH + 50:
            return
        main, outline = _get_damage_surf(self.text, self.color, self.size)
        t = self.life / self.LIFETIME
        alpha = int(255 * (1 - max(0, t - 0.5) * 2))
        if alpha < 255:
            main = main.copy()
            outline = outline.copy()
            main.set_alpha(alpha)
            outline.set_alpha(alpha)
        ox = sx - main.get_width() // 2
        oy = sy
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            surface.blit(outline, (ox + dx, oy + dy))
        surface.blit(main, (ox, oy))


class PowerUp:
    _SPRITES = None

    @classmethod
    def _build_sprites(cls):
        sprites = {}
        colors = {
            "speed": ((90, 220, 240), (20, 90, 130)),
            "damage": ((255, 110, 70), (140, 30, 20)),
            "shield": ((150, 200, 255), (40, 90, 170)),
        }
        size = 40
        for kind, (fg, bg) in colors.items():
            s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
            cx = cy = size
            for r in range(10, 0, -1):
                pygame.draw.circle(s, (*fg, 8), (cx, cy), size // 2 + r)
            shield_pts = [(cx - 14, cy - 14), (cx + 14, cy - 14), (cx + 14, cy + 4), (cx, cy + 16), (cx - 14, cy + 4)]
            inner_pts = [(cx - 12, cy - 12), (cx + 12, cy - 12), (cx + 12, cy + 3), (cx, cy + 13), (cx - 12, cy + 3)]
            pygame.draw.polygon(s, (15, 12, 10), shield_pts)
            pygame.draw.polygon(s, bg, inner_pts)
            pygame.draw.polygon(s, (220, 184, 100), shield_pts, 2)

            if kind == "speed":
                for i, length in enumerate([8, 6, 4]):
                    y_off = -3 + i * 3
                    pygame.draw.line(s, fg, (cx - 4, cy + y_off), (cx - 4 - length, cy + y_off - 2), 2)
                pygame.draw.polygon(s, fg, [(cx - 2, cy - 4), (cx + 5, cy - 4), (cx + 5, cy + 3),
                                            (cx + 8, cy + 3), (cx + 8, cy + 6), (cx - 2, cy + 6)])
                pygame.draw.line(s, WHITE, (cx - 2, cy + 1), (cx + 5, cy + 1), 1)
            elif kind == "damage":
                pygame.draw.line(s, (220, 220, 230), (cx - 8, cy - 8), (cx + 8, cy + 8), 2)
                pygame.draw.line(s, (220, 220, 230), (cx + 8, cy - 8), (cx - 8, cy + 8), 2)
                pygame.draw.circle(s, (220, 184, 100), (cx - 8, cy - 8), 2)
                pygame.draw.circle(s, (220, 184, 100), (cx + 8, cy - 8), 2)
                pygame.draw.line(s, (220, 184, 100), (cx - 11, cy - 5), (cx - 5, cy - 11), 2)
                pygame.draw.line(s, (220, 184, 100), (cx + 5, cy - 11), (cx + 11, cy - 5), 2)
            elif kind == "shield":
                kite_pts = [(cx, cy - 8), (cx + 7, cy - 5), (cx + 7, cy + 2), (cx, cy + 10),
                            (cx - 7, cy + 2), (cx - 7, cy - 5)]
                pygame.draw.polygon(s, fg, kite_pts)
                pygame.draw.polygon(s, WHITE, kite_pts, 1)
                pygame.draw.line(s, WHITE, (cx, cy - 6), (cx, cy + 8), 2)
                pygame.draw.line(s, WHITE, (cx - 5, cy + 1), (cx + 5, cy + 1), 2)
            sprites[kind] = s.convert_alpha()
        cls._SPRITES = sprites

    def __init__(self, world_x, world_y, kind):
        if PowerUp._SPRITES is None:
            PowerUp._build_sprites()
        self.world_x = world_x
        self.world_y = world_y
        self.kind = kind
        self.collected = False
        self.spawn_tick = pygame.time.get_ticks()
        self.bob_offset = 0
        self.size = 28
        self.rect = pygame.Rect(world_x - self.size // 2, world_y - self.size // 2, self.size, self.size)
        self.sprite = PowerUp._SPRITES[kind]

    def colors(self):
        return {
            "speed": ((90, 220, 240), (20, 90, 130)),
            "damage": ((255, 110, 70), (140, 30, 20)),
            "shield": ((150, 200, 255), (40, 90, 170)),
        }[self.kind]

    def update(self):
        self.bob_offset = math.sin((pygame.time.get_ticks() - self.spawn_tick) * 0.005) * 6
        self.rect.x = self.world_x - self.size // 2
        self.rect.y = int(self.world_y - self.size // 2 + self.bob_offset)

    def check_collect(self, player):
        if self.collected or not self.rect.colliderect(player.rect):
            return False
        duration = 60 * 8
        if self.kind == "speed":
            player.speed_boost_timer = duration
        elif self.kind == "damage":
            player.double_dmg_timer = duration
        elif self.kind == "shield":
            player.shield_timer = duration
        self.collected = True
        return True

    def draw(self, surface, scroll_offset):
        sx = self.world_x - scroll_offset
        if sx < -50 or sx > SCREEN_WIDTH + 50:
            return
        w = self.sprite.get_width()
        surface.blit(self.sprite, (int(sx - w // 2), int(self.world_y - w // 2 + self.bob_offset)))


class LavaParticle:
    LIFETIME = 90

    def __init__(self, world_x, world_y, intensity=1.0):
        self.world_x = world_x
        self.world_y = world_y
        self.vx = random.uniform(-3, 3)
        self.vy = random.uniform(-12, -7) * intensity
        self.life = 0
        self.dead = False
        self.size = random.randint(3, 7)
        self.color = random.choice([(255, 200, 60), (255, 140, 40), (255, 80, 30), (220, 50, 20)])

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.45
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -20 or sx > SCREEN_WIDTH + 20:
            return
        t = 1 - self.life / self.LIFETIME
        size = max(2, int(self.size * t))
        glow = pygame.Surface((size * 4, size * 4), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*self.color, 80), (size * 2, size * 2), size * 2)
        pygame.draw.circle(glow, (*self.color, 220), (size * 2, size * 2), size)
        surface.blit(glow, (sx - size * 2, sy - size * 2), special_flags=pygame.BLEND_RGBA_ADD)
