import asyncio
import pygame
import random
import math

from entity import (
    Entity, TreasureChest, Particle, Spark, DamageNumber, PowerUp,
    DemonicTower, LavaParticle, BOSS_VARIANTS, SHIELD_BLUE, CRIT_ORANGE, _get_font
)

pygame.init()

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = int(SCREEN_WIDTH * 0.8)
FPS = 60

try:
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SCALED | pygame.DOUBLEBUF, vsync=1)
except Exception:
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

pygame.display.set_caption("A Knight's Last Stand")
clock = pygame.time.Clock()

# Fantasy palette
BG_VOID = (8, 6, 10)
BG_IRON = (24, 22, 30)
BG_STONE = (38, 34, 44)
PARCHMENT = (240, 222, 184)
PARCH_DIM = (190, 170, 130)
PARCH_QUIET = (130, 115, 88)
GILT = (220, 174, 88)
GILT_BRIGHT = (255, 220, 130)
GILT_DEEP = (130, 96, 40)
RUNE_RED = (200, 60, 50)
HP_GOOD = (130, 195, 135)
HP_MID = (220, 180, 90)
HP_LOW = (200, 70, 70)
SPEED_C = (90, 220, 240)
DMG_C = (255, 130, 80)
SHIELD_C = (150, 200, 255)
FURY_C = (245, 110, 70)
BLACK = (0, 0, 0)

font_display = _get_font(40)
font_h1 = _get_font(28)
font_h2 = _get_font(20)
font_body = _get_font(15)
font_label = _get_font(12)
font_caption = _get_font(10)

# Background
try:
    bg_image = pygame.image.load("img/Background/Background.png").convert()
    bg_tile = pygame.transform.scale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
except Exception:
    bg_tile = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        col = (int(18 + 15 * t), int(20 + 24 * t), int(28 + 14 * t))
        pygame.draw.line(bg_tile, col, (0, y), (SCREEN_WIDTH, y))


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_color(c1, c2, t):
    return (int(lerp(c1[0], c2[0], t)), int(lerp(c1[1], c2[1], t)), int(lerp(c1[2], c2[2], t)))


def build_atmosphere_overlay():
    surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        if t < 0.4:
            a = int(35 * (1 - t / 0.4))
            c = (60, 80, 110, a)
        elif t > 0.7:
            a = int(45 * ((t - 0.7) / 0.3))
            c = (10, 12, 18, a)
        else:
            c = (0, 0, 0, 0)
        pygame.draw.line(surf, c, (0, y), (SCREEN_WIDTH, y))
    return surf.convert_alpha()


ATMOSPHERE = build_atmosphere_overlay()
_HELL_BG = None
_PANEL_CACHE = {}


def build_hellscape_bg():
    surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        if t < 0.35:
            c = lerp_color((35, 8, 8), (140, 35, 18), t / 0.35)
        elif t < 0.55:
            c = lerp_color((140, 35, 18), (220, 80, 30), (t - 0.35) / 0.20)
        elif t < 0.75:
            c = lerp_color((220, 80, 30), (90, 25, 15), (t - 0.55) / 0.20)
        else:
            c = lerp_color((90, 25, 15), (15, 5, 5), (t - 0.75) / 0.25)
        pygame.draw.line(surf, c, (0, y), (SCREEN_WIDTH, y))

    horizon = int(SCREEN_HEIGHT * 0.55)
    for offset in range(-3, 4):
        alpha = max(0, 80 - abs(offset) * 25)
        line_surf = pygame.Surface((SCREEN_WIDTH, 1), pygame.SRCALPHA)
        line_surf.fill((255, 180, 80, alpha))
        surf.blit(line_surf, (0, horizon + offset))

    ground_y = int(SCREEN_HEIGHT * 0.8)
    pygame.draw.rect(surf, (18, 8, 8), (0, ground_y, SCREEN_WIDTH, SCREEN_HEIGHT - ground_y))
    rng = random.Random(99)
    for _ in range(7):
        cx = rng.randint(20, SCREEN_WIDTH - 20)
        cy = rng.randint(ground_y + 15, SCREEN_HEIGHT - 15)
        pts = [(cx, cy)]
        for _ in range(rng.randint(3, 5)):
            cx += rng.randint(-25, 25)
            cy += rng.randint(-6, 6)
            pts.append((cx, cy))
        for i in range(len(pts) - 1):
            pygame.draw.line(surf, (255, 90, 30), pts[i], pts[i + 1], 3)
            pygame.draw.line(surf, (255, 220, 120), pts[i], pts[i + 1], 1)
    return surf.convert()


def get_hell_bg():
    global _HELL_BG
    if _HELL_BG is None:
        _HELL_BG = build_hellscape_bg()
    return _HELL_BG


def draw_world_bg(surface, scroll_offset, hell_amount):
    if hell_amount >= 0.999:
        surface.blit(get_hell_bg(), (0, 0))
        return
    first_tile = int(scroll_offset // SCREEN_WIDTH)
    for i in range(first_tile, first_tile + 3):
        tile_world_x = i * SCREEN_WIDTH
        sx = tile_world_x - scroll_offset
        surface.blit(bg_tile, (sx, 0))
    surface.blit(ATMOSPHERE, (0, 0))
    if hell_amount > 0:
        hell = get_hell_bg().copy()
        hell.set_alpha(int(255 * hell_amount))
        surface.blit(hell, (0, 0))


def build_fantasy_panel(w, h):
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(surf, (4, 3, 6, 230), (2, 2, w, h))
    pygame.draw.rect(surf, BG_IRON, (0, 0, w, h))
    pygame.draw.line(surf, BG_STONE, (1, 1), (w - 2, 1), 1)
    pygame.draw.line(surf, BG_STONE, (1, 1), (1, h - 2), 1)
    pygame.draw.line(surf, BG_VOID, (w - 1, 0), (w - 1, h - 1), 1)
    pygame.draw.line(surf, BG_VOID, (0, h - 1), (w - 1, h - 1), 1)
    inset = 6
    pygame.draw.rect(surf, BG_VOID, (inset, inset, w - inset * 2, h - inset * 2))
    pygame.draw.rect(surf, GILT_DEEP, (inset, inset, w - inset * 2, h - inset * 2), 1)

    def corner(cx, cy, dx, dy):
        pygame.draw.line(surf, GILT, (cx, cy), (cx + 14 * dx, cy), 2)
        pygame.draw.line(surf, GILT, (cx, cy), (cx, cy + 14 * dy), 2)
        pygame.draw.circle(surf, GILT_BRIGHT, (cx, cy), 2)
        pygame.draw.circle(surf, RUNE_RED, (cx, cy), 1)

    corner(2, 2, 1, 1)
    corner(w - 3, 2, -1, 1)
    corner(2, h - 3, 1, -1)
    corner(w - 3, h - 3, -1, -1)
    return surf.convert_alpha()


def get_panel(w, h):
    key = (w, h)
    if key not in _PANEL_CACHE:
        _PANEL_CACHE[key] = build_fantasy_panel(w, h)
    return _PANEL_CACHE[key]


def draw_panel(surface, x, y, w, h):
    surface.blit(get_panel(w, h), (x, y))


def draw_hud(surface, player, distance):
    x, y, w, h = 12, 12, 290, 134
    draw_panel(surface, x, y, w, h)
    pad = 18
    title = font_caption.render("VITALITY", True, GILT_BRIGHT)
    surface.blit(title, (x + pad, y + 12))

    bar_x, bar_y, bar_w, bar_h = x + pad, y + 28, w - pad * 2, 12
    ratio = max(0, min(1, player.health / player.max_health))
    pygame.draw.rect(surface, GILT_DEEP, (bar_x - 2, bar_y - 2, bar_w + 4, bar_h + 4))
    pygame.draw.rect(surface, (40, 12, 12), (bar_x, bar_y, bar_w, bar_h))
    hp_color = HP_GOOD if ratio > 0.6 else (HP_MID if ratio > 0.3 else HP_LOW)
    pygame.draw.rect(surface, hp_color, (bar_x, bar_y, int(bar_w * ratio), bar_h))
    pygame.draw.line(surface, GILT_BRIGHT, (bar_x, bar_y), (bar_x + bar_w, bar_y), 1)
    hp_text = font_label.render(f"{int(player.health)} / {player.max_health}", True, PARCHMENT)
    surface.blit(hp_text, (bar_x + bar_w // 2 - hp_text.get_width() // 2, bar_y + bar_h // 2 - hp_text.get_height() // 2))

    div_y = bar_y + bar_h + 12
    pygame.draw.line(surface, GILT_DEEP, (x + 16, div_y), (x + w - 16, div_y), 1)
    dx = x + w // 2
    pygame.draw.polygon(surface, GILT, [(dx, div_y - 3), (dx + 4, div_y), (dx, div_y + 3), (dx - 4, div_y)])

    row_y = div_y + 8
    surface.blit(font_caption.render("VALOR", True, PARCH_QUIET), (x + pad, row_y))
    score = font_h1.render(str(player.score), True, GILT)
    surface.blit(score, (x + pad, row_y + 12))
    surface.blit(font_caption.render("MARCH", True, PARCH_QUIET), (x + w - pad - 80, row_y))
    dist = font_h2.render(f"{distance}m", True, PARCHMENT)
    surface.blit(dist, (x + w - pad - dist.get_width(), row_y + 14))


def draw_shrine_tracker(surface, shrines_activated, total_shrines, next_dist_m):
    x, y, w, h = 12, 156, 290, 56
    draw_panel(surface, x, y, w, h)
    pad = 16
    surface.blit(font_caption.render("EXORCISM TOWERS", True, GILT_BRIGHT), (x + pad, y + 10))
    if next_dist_m is not None and next_dist_m > 0:
        val = font_label.render(f"{next_dist_m}m", True, PARCHMENT)
        lab = font_caption.render("NEXT", True, PARCH_QUIET)
        vx = x + w - pad - val.get_width()
        surface.blit(lab, (vx - lab.get_width() - 6, y + 10))
        surface.blit(val, (vx, y + 9))

    icon_y = y + 32
    spacing = 30
    start_x = x + w // 2 - ((total_shrines - 1) * spacing) // 2
    for i in range(total_shrines):
        ix = start_x + i * spacing
        if i < shrines_activated:
            pygame.draw.circle(surface, GILT, (ix, icon_y), 9)
            pygame.draw.circle(surface, BG_VOID, (ix, icon_y), 7)
            pygame.draw.line(surface, RUNE_RED, (ix, icon_y - 4), (ix, icon_y + 4), 2)
            pygame.draw.line(surface, RUNE_RED, (ix - 4, icon_y), (ix + 4, icon_y), 2)
            pygame.draw.circle(surface, GILT_BRIGHT, (ix, icon_y), 1)
        else:
            pygame.draw.circle(surface, GILT_DEEP, (ix, icon_y), 9)
            pygame.draw.circle(surface, BG_VOID, (ix, icon_y), 7)
            pygame.draw.line(surface, PARCH_QUIET, (ix, icon_y - 3), (ix, icon_y + 3), 1)
            pygame.draw.line(surface, PARCH_QUIET, (ix - 3, icon_y), (ix + 3, icon_y), 1)


def draw_strength_indicator(surface, player):
    if player.shrines_cleared <= 0:
        return
    x, y, w, h = 12, 222, 290, 32
    draw_panel(surface, x, y, w, h)
    cx, cy = x + 22, y + h // 2
    pygame.draw.circle(surface, GILT, (cx, cy), 8)
    pygame.draw.circle(surface, BG_VOID, (cx, cy), 6)
    pygame.draw.line(surface, RUNE_RED, (cx, cy - 3), (cx, cy + 3), 2)
    pygame.draw.line(surface, RUNE_RED, (cx - 3, cy), (cx + 3, cy), 2)
    surface.blit(font_caption.render("SOULS BOUND", True, PARCH_QUIET), (x + 38, y + 6))
    surface.blit(font_label.render(f"+{player.shrines_cleared * 8}% Strength", True, GILT_BRIGHT), (x + 38, y + 18))


def draw_powerup_strip(surface, player):
    icons = []
    if player.speed_boost_timer > 0:
        icons.append(("speed", player.speed_boost_timer, 60 * 8, SPEED_C))
    if player.double_dmg_timer > 0:
        icons.append(("damage", player.double_dmg_timer, 60 * 8, DMG_C))
    if player.shield_timer > 0:
        icons.append(("shield", player.shield_timer, 60 * 8, SHIELD_C))
    if player.fury_timer > 0:
        icons.append(("fury", player.fury_timer, 60 * 30, FURY_C))
    if not icons:
        return

    size, gap = 52, 10
    x = SCREEN_WIDTH - (len(icons) * size + (len(icons) - 1) * gap) - 16
    y = 16
    for kind, timer, max_t, color in icons:
        ratio = min(1.0, timer / max_t)
        secs = timer // 60
        pygame.draw.rect(surface, BG_VOID, (x, y, size, size))
        pygame.draw.rect(surface, BG_IRON, (x + 2, y + 2, size - 4, size - 4))
        pygame.draw.rect(surface, GILT_DEEP, (x, y, size, size), 1)
        pygame.draw.rect(surface, GILT, (x + 3, y + 3, size - 6, size - 6), 1)
        cx, cy = x + size // 2, y + size // 2 - 4

        if kind == "speed":
            for i, length in enumerate([8, 6, 4]):
                yo = -3 + i * 3
                pygame.draw.line(surface, color, (cx - 5, cy + yo), (cx - 5 - length, cy + yo - 2), 2)
            pygame.draw.polygon(surface, color, [(cx - 3, cy - 4), (cx + 5, cy - 4), (cx + 5, cy + 3),
                                                (cx + 9, cy + 3), (cx + 9, cy + 6), (cx - 3, cy + 6)])
        elif kind == "damage":
            # Single greatsword with a thick blade.
            blade = [
                (cx + 9, cy - 12),
                (cx + 13, cy - 8),
                (cx - 2, cy + 11),
                (cx - 6, cy + 7),
            ]
            pygame.draw.polygon(surface, (225, 228, 236), blade)
            pygame.draw.polygon(surface, GILT_DEEP, blade, 1)
            pygame.draw.line(surface, (245, 245, 250), (cx + 8, cy - 9), (cx - 3, cy + 7), 1)
            pygame.draw.line(surface, GILT, (cx - 5, cy + 7), (cx - 11, cy + 13), 3)
            pygame.draw.line(surface, GILT_BRIGHT, (cx - 4, cy + 8), (cx - 10, cy + 14), 1)
            pygame.draw.line(surface, GILT, (cx - 8, cy + 6), (cx - 2, cy + 12), 3)
            pygame.draw.circle(surface, GILT, (cx - 12, cy + 14), 2)
        elif kind == "shield":
            kite = [(cx, cy - 9), (cx + 8, cy - 5), (cx + 8, cy + 2), (cx, cy + 11), (cx - 8, cy + 2), (cx - 8, cy - 5)]
            pygame.draw.polygon(surface, color, kite)
            pygame.draw.polygon(surface, GILT, kite, 1)
            pygame.draw.line(surface, GILT, (cx, cy - 6), (cx, cy + 9), 2)
            pygame.draw.line(surface, GILT, (cx - 5, cy + 1), (cx + 5, cy + 1), 2)
        elif kind == "fury":
            flame = [(cx, cy - 11), (cx + 4, cy - 5), (cx + 7, cy + 2), (cx + 4, cy + 9),
                     (cx, cy + 11), (cx - 4, cy + 9), (cx - 7, cy + 2), (cx - 4, cy - 5)]
            pygame.draw.polygon(surface, color, flame)
            pygame.draw.circle(surface, GILT_BRIGHT, (cx, cy + 1), 3)

        track_y = y + size - 8
        pygame.draw.rect(surface, BG_VOID, (x + 4, track_y, size - 8, 3))
        pygame.draw.rect(surface, color, (x + 4, track_y, int((size - 8) * ratio), 3))
        t = font_caption.render(f"{secs}s", True, PARCHMENT)
        surface.blit(t, (x + size - t.get_width() - 4, y + size - 18))
        x += size + gap


def draw_keys(surface):
    hints = [("WASD", "Move"), ("F", "Strike"), ("ESC", "Pause")]
    y = SCREEN_HEIGHT - 32
    x = SCREEN_WIDTH - 14
    for key, action in reversed(hints):
        act_text = font_label.render(action, True, PARCH_DIM)
        key_text = font_label.render(key, True, PARCHMENT)
        key_w, key_h = key_text.get_width() + 16, 22
        x -= act_text.get_width()
        surface.blit(act_text, (x, y + 4))
        x -= key_w + 6
        pygame.draw.rect(surface, BG_VOID, (x, y, key_w, key_h))
        pygame.draw.rect(surface, BG_STONE, (x + 1, y + 1, key_w - 2, key_h - 2))
        pygame.draw.rect(surface, GILT_DEEP, (x, y, key_w, key_h), 1)
        pygame.draw.line(surface, GILT, (x + 2, y + 1), (x + key_w - 3, y + 1), 1)
        surface.blit(key_text, (x + 8, y + 4))
        x -= 18


BUTTON_RECT = pygame.Rect(SCREEN_WIDTH // 2 - 130, SCREEN_HEIGHT // 2 + 60, 260, 56)


def draw_fantasy_button(surface, rect, label):
    hovered = rect.collidepoint(pygame.mouse.get_pos())
    pygame.draw.rect(surface, BG_VOID, rect)
    pygame.draw.rect(surface, (50, 40, 30) if hovered else BG_STONE, rect.inflate(-4, -4))
    pygame.draw.rect(surface, GILT_BRIGHT if hovered else GILT, rect, 2)
    pygame.draw.rect(surface, GILT_DEEP, rect.inflate(-8, -8), 1)
    for cx, cy in [(rect.x + 6, rect.y + 6), (rect.right - 7, rect.y + 6), (rect.x + 6, rect.bottom - 7), (rect.right - 7, rect.bottom - 7)]:
        pygame.draw.circle(surface, GILT, (cx, cy), 2)
        pygame.draw.circle(surface, RUNE_RED, (cx, cy), 1)
    text = font_h2.render(label, True, PARCHMENT)
    surface.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))


def draw_death_screen(surface, score, distance):
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((*BG_VOID, 200))
    surface.blit(overlay, (0, 0))
    title = font_display.render("YOU HAVE FALLEN", True, HP_LOW)
    surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 150))
    card_w, card_h = 360, 100
    card_x, card_y = SCREEN_WIDTH // 2 - card_w // 2, SCREEN_HEIGHT // 2 - 70
    draw_panel(surface, card_x, card_y, card_w, card_h)
    pygame.draw.line(surface, GILT_DEEP, (card_x + card_w // 2, card_y + 14), (card_x + card_w // 2, card_y + card_h - 14), 1)
    for i, (name, value, color) in enumerate([("VALOR", str(score), GILT), ("MARCH", f"{distance}m", PARCHMENT)]):
        cx = card_x + card_w // 4 + i * card_w // 2
        lab = font_caption.render(name, True, PARCH_QUIET)
        val = font_h1.render(value, True, color)
        surface.blit(lab, (cx - lab.get_width() // 2, card_y + 22))
        surface.blit(val, (cx - val.get_width() // 2, card_y + 50))
    draw_fantasy_button(surface, BUTTON_RECT, "RISE AGAIN")


def draw_pause_screen(surface):
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((*BG_VOID, 160))
    surface.blit(overlay, (0, 0))
    title = font_display.render("PAUSED", True, PARCHMENT)
    surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 70))
    hint = font_body.render("Press ESC to resume", True, PARCH_DIM)
    surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT // 2 - 10))


def draw_victory_screen(surface):
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((*BG_VOID, 220))
    surface.blit(overlay, (0, 0))
    title = font_display.render("THE DAMNED ARE FREED", True, GILT)
    surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 110))
    sub = font_body.render("All exorcism towers have been activated.", True, PARCH_DIM)
    surface.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, SCREEN_HEIGHT // 2 - 60))
    draw_fantasy_button(surface, BUTTON_RECT, "PLAY AGAIN")


GROUND_Y = SCREEN_HEIGHT - 66
ACTIVE_RANGE = SCREEN_WIDTH + 400
TOTAL_SHRINES = 5
PIXELS_PER_METER = 50
SHRINE_SPACING = 500 * PIXELS_PER_METER
CHUNK_SIZE = 1500

spawned_chunks = set()
skeletons = []
chests = []
particles = []
sparks = []
damage_numbers = []
powerups = []
lava_particles = []
towers = []
tower_bosses = {}


def get_shrine_world_x(index):
    return 90 + (index + 1) * SHRINE_SPACING


def spawn_chunk(chunk_index, current_tier):
    if chunk_index in spawned_chunks:
        return
    spawned_chunks.add(chunk_index)
    chunk_start = chunk_index * CHUNK_SIZE
    chunk_end = chunk_start + CHUNK_SIZE

    if chunk_index == 0:
        skeletons.append(Entity("Skeleton", random.randint(chunk_start + 700, chunk_end - 200), GROUND_Y - 10, 3, tier=current_tier))
        return

    spawned_tower = False
    for tower_idx in range(TOTAL_SHRINES):
        shrine_x = get_shrine_world_x(tower_idx)
        if chunk_start <= shrine_x < chunk_end:
            is_final = tower_idx == TOTAL_SHRINES - 1
            tower = DemonicTower(shrine_x, GROUND_Y, tower_idx, is_final=is_final)
            towers.append(tower)
            variant = None if is_final else (tower_idx % len(BOSS_VARIANTS))
            boss = Entity("Skeleton", shrine_x - 120, GROUND_Y - 10, 3,
                          force_lucky=True, tier=tower_idx, is_final_boss=is_final,
                          boss_variant=variant)
            skeletons.append(boss)
            tower_bosses[tower_idx] = boss
            spawned_tower = True
            break

    lucky_chance = 0.20 + current_tier * 0.12
    num_skels = random.randint(2, 3) + min(2, current_tier // 2)
    if spawned_tower:
        num_skels = max(1, num_skels - 1)
    for _ in range(num_skels):
        x = random.randint(chunk_start + 100, chunk_end - 100)
        s = Entity("Skeleton", x, GROUND_Y - 10, 3, tier=current_tier)
        if random.random() < lucky_chance and not s.lucky_skel:
            s.lucky_skel = True
            s.health = int(70 * (1 + current_tier * 0.20))
            s.max_health = s.health
            s.base_dmg_min = int(12 * (1 + current_tier * 0.15))
            s.base_dmg_max = int(22 * (1 + current_tier * 0.15))
            s.attack_cooldown_max = 55
        skeletons.append(s)

    # Chests should feel rare and valuable, not like constant clutter.
    # Roughly 1 chest every ~12 chunks on average, and never more than 1 per chunk.
    CHEST_SPAWN_CHANCE = 0.08
    if not spawned_tower and random.random() < CHEST_SPAWN_CHANCE:
        x = random.randint(chunk_start + 180, chunk_end - 180)
        chests.append(TreasureChest(x, GROUND_Y))


def ensure_world_around(player_x, current_tier):
    current_chunk = int(player_x // CHUNK_SIZE)
    for i in range(current_chunk, current_chunk + 4):
        if i >= 0:
            spawn_chunk(i, current_tier)


def cull_far_behind(player_x):
    cutoff = player_x - CHUNK_SIZE * 2
    skeletons[:] = [s for s in skeletons if s.anchor_x > cutoff]
    chests[:] = [c for c in chests if c.world_x > cutoff and not c.collected]
    powerups[:] = [p for p in powerups if p.world_x > cutoff and not p.collected]


def reset_game():
    global spawned_chunks, skeletons, chests, particles, sparks, damage_numbers
    global powerups, lava_particles, towers, tower_bosses
    spawned_chunks = set()
    skeletons = []
    chests = []
    particles = []
    sparks = []
    damage_numbers = []
    powerups = []
    lava_particles = []
    towers = []
    tower_bosses = {}
    player = Entity("Player", 90, GROUND_Y - 10, 3)
    for i in range(3):
        spawn_chunk(i, 0)
    return player, 0.0


def trigger_lava_burst(x, y, count=10, intensity=1.0):
    for _ in range(count):
        lava_particles.append(LavaParticle(x + random.randint(-30, 30), y, intensity=intensity))


def apply_enemy_reward_drop(ev):
    """Apply enemy reward drops.

    Normal skeletons send heal_amount=0 and drop_powerup=False, so they only give score.
    Lucky skeletons can give health, power-ups, or rarely both.
    Bosses always give health and may also drop a power-up.
    """
    heal_amount = ev.get("heal_amount", 0)
    if heal_amount > 0:
        player.health = min(player.max_health, player.health + heal_amount)
        damage_numbers.append(DamageNumber(
            ev["x"], ev["y"] - 10, f"+{heal_amount}", color=HP_GOOD
        ))
        for _ in range(4):
            particles.append(Particle(ev["x"], ev["y"] + 22, "heart"))

    if ev.get("drop_powerup"):
        powerups.append(PowerUp(
            ev["x"], ev["y"] + 20, random.choice(["speed", "damage", "shield"])
        ))


def get_next_shrine_x(shrines_activated):
    for tower in towers:
        if not tower.activated:
            return tower.world_x
    if shrines_activated < TOTAL_SHRINES:
        return get_shrine_world_x(shrines_activated)
    return None

def spawn_covenant_bosses(center_x):
    # 4 named bosses + final boss
    positions = [-700, -350, 0, 350, 700]

    for i, offset in enumerate(positions[:4]):
        boss = Entity(
            "Skeleton",
            center_x + offset,
            GROUND_Y - 10,
            3,
            force_lucky=True,
            tier=i,
            boss_variant=i
        )
        skeletons.append(boss)

    final_boss = Entity(
        "Skeleton",
        center_x + positions[4],
        GROUND_Y - 10,
        3,
        force_lucky=True,
        tier=TOTAL_SHRINES - 1,
        is_final_boss=True
    )
    skeletons.append(final_boss)

def draw_covenant_prompt(surface):
    box_x = 16
    box_y = 18
    box_w = SCREEN_WIDTH - 32
    box_h = 260

    draw_panel(surface, box_x, box_y, box_w, box_h)

    title_font = _get_font(64)
    main_font = _get_font(34)
    sub_font = _get_font(22)

    title = title_font.render("ANCIENT COVENANT", True, GILT_BRIGHT)
    line1 = main_font.render("Type GOD to accept the covenant.", True, PARCHMENT)
    line2 = sub_font.render("Heavenly ichor shall descend upon the chosen.", True, PARCH_DIM)

    title_x = SCREEN_WIDTH // 2 - title.get_width() // 2
    line1_x = SCREEN_WIDTH // 2 - line1.get_width() // 2
    line2_x = SCREEN_WIDTH // 2 - line2.get_width() // 2

    surface.blit(title, (title_x, box_y + 34))
    surface.blit(line1, (line1_x, box_y + 122))
    surface.blit(line2, (line2_x, box_y + 178))
# Hidden cheat sequence: type GODMODE during gameplay.
CHEAT_SEQUENCE = "god"
cheat_buffer = ""
cheat_message_timer = 0
covenant_triggered = False
covenant_prompt_active = False
covenant_prompt_timer = 0

async def main():
    global player, scroll_offset, game_over, victory, paused, hitstop_timer, cull_counter
    global shrines_activated, current_tier, hellscape_progress, hellscape_target
    global final_animation_phase, final_animation_timer, cheat_buffer, cheat_message_timer
    global covenant_triggered, covenant_prompt_active, covenant_prompt_timer

    player, scroll_offset = reset_game()
    #temp
    player.anchor_x = 145090
    player._sync_rect_to_anchor()
    scroll_offset = max(0, player.anchor_x - SCREEN_WIDTH // 2)
    
    game_over = False
    victory = False
    paused = False
    hitstop_timer = 0
    cull_counter = 0
    shrines_activated = 0
    current_tier = 0
    hellscape_progress = 0.0
    hellscape_target = 0.0
    final_animation_phase = 0
    final_animation_timer = 0
    covenant_triggered = False
    covenant_prompt_active = False

    run = True
    while run:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and not game_over and not victory:
                    paused = not paused
                elif not game_over and not victory:
                    typed = getattr(event, "unicode", "").lower()
                    if typed and typed.isprintable() and len(typed) == 1:
                        cheat_buffer = (cheat_buffer + typed)[-len(CHEAT_SEQUENCE):]

                        if cheat_buffer == CHEAT_SEQUENCE:
                            player.activate_cheat_mode()

                            covenant_prompt_active = False
                            covenant_prompt_timer = 0   # this instantly removes the big Ancient Covenant box

                            cheat_message_timer = 240   # this shows Ancient Power Awakened after
                            cheat_buffer = ""
            elif event.type == pygame.MOUSEBUTTONDOWN and (game_over or victory):
                if BUTTON_RECT.collidepoint(event.pos):
                    player, scroll_offset = reset_game()
                    game_over = False
                    victory = False
                    paused = False
                    shrines_activated = 0
                    current_tier = 0
                    hellscape_progress = 0.0
                    hellscape_target = 0.0
                    final_animation_phase = 0
                    final_animation_timer = 0
                    cheat_buffer = ""
                    cheat_message_timer = 0

        if hellscape_progress < hellscape_target:
            hellscape_progress = min(hellscape_target, hellscape_progress + 0.005)

        if final_animation_phase == 1:
            final_animation_timer += 1
            if final_animation_timer % 4 == 0:
                lava_x = scroll_offset + random.randint(0, SCREEN_WIDTH)
                trigger_lava_burst(lava_x, GROUND_Y, count=6, intensity=1.5)
            hellscape_target = 1.0
            if final_animation_timer > 240:
                final_animation_phase = 2
                victory = True

        tick_world = not paused and not game_over and not victory and hitstop_timer <= 0 and final_animation_phase != 1
        if hitstop_timer > 0:
            hitstop_timer -= 1
        if cheat_message_timer > 0:
            cheat_message_timer -= 1
        if covenant_prompt_timer > 0:
            covenant_prompt_timer -= 1

        distance_m = max(0, int((player.anchor_x - 90) / PIXELS_PER_METER))
        if not covenant_triggered and distance_m >= 3000:
            covenant_triggered = True
            covenant_prompt_active = True
            covenant_prompt_timer = 360
            cheat_buffer = ""
            spawn_covenant_bosses(player.anchor_x + 250)

        current_tier = shrines_activated
        ensure_world_around(player.anchor_x, current_tier)

        if tick_world:
            target_scroll = max(0.0, player.anchor_x - SCREEN_WIDTH // 2)
            scroll_offset += (target_scroll - scroll_offset) * 0.18
        else:
            scroll_offset = max(0.0, scroll_offset)

        draw_world_bg(screen, scroll_offset, hellscape_progress)

        for tower in towers:
            if abs(tower.world_x - player.anchor_x) > ACTIVE_RANGE:
                continue
            if tick_world:
                boss = tower_bosses.get(tower.tier_index)
                result = tower.update(player, boss)
                if result == "activated":
                    shrines_activated += 1
                    player.shrines_cleared += 1
                    player.ethereal_glow_timer = 120
                    player.health = min(player.max_health, player.health + 30)
                    if tower.is_final and final_animation_phase == 0:
                        hellscape_target = 1.0
                        final_animation_phase = 1
                        final_animation_timer = 0
                    for _ in range(15):
                        sparks.append(Spark(tower.world_x + random.randint(-30, 30), GROUND_Y - 100, color=GILT))
            tower.draw(screen, scroll_offset)

        for chest in chests:
            if abs(chest.world_x - player.anchor_x) > ACTIVE_RANGE:
                continue
            if tick_world:
                chest.check_collect(player, particles, powerups, lucky_skeleton=None)
                chest.update()
            chest.draw(screen, scroll_offset)

        for pu in powerups:
            if abs(pu.world_x - player.anchor_x) > ACTIVE_RANGE:
                continue
            if tick_world:
                pu.update()
                if pu.check_collect(player):
                    for _ in range(8):
                        sparks.append(Spark(pu.world_x, pu.world_y, color=pu.colors()[0]))
            if not pu.collected:
                pu.draw(screen, scroll_offset)
        if tick_world:
            powerups[:] = [p for p in powerups if not p.collected]

        for particle in particles:
            if tick_world:
                particle.update()
            particle.draw(screen, scroll_offset)
        if tick_world:
            particles[:] = [p for p in particles if not p.dead]

        for lp in lava_particles:
            if tick_world:
                lp.update()
            lp.draw(screen, scroll_offset)
        if tick_world:
            lava_particles[:] = [lp for lp in lava_particles if not lp.dead]

        if not game_over and final_animation_phase != 1:
            active_skels = [s for s in skeletons if abs(s.anchor_x - player.anchor_x) <= ACTIVE_RANGE]
            alive_active = [s for s in active_skels if s.alive]

            if tick_world:
                player.move(SCREEN_HEIGHT, screen, alive_active)
                player.update()

                for skel in active_skels:
                    if skel.alive:
                        skel.ai(screen, player)
                    skel.check_alive()
                    skel.update()

                if player.heal_on_kill > 0:
                    damage_numbers.append(DamageNumber(player.rect.centerx, player.rect.top, f"+{player.heal_on_kill}", color=HP_GOOD))
                    player.health = min(player.max_health, player.health + player.heal_on_kill)
                    player.heal_on_kill = 0

                for ev in player.events:
                    et = ev["type"]
                    if et == "hit_landed":
                        hitstop_timer = max(hitstop_timer, 4 if ev.get("crit") else 2)
                        color = CRIT_ORANGE if ev.get("crit") else (255, 230, 80)
                        text = f"{ev['damage']}!" if ev.get("crit") else str(ev["damage"])
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"], text, color=color, big=ev.get("crit", False)))
                        for _ in range(6 if ev.get("crit") else 3):
                            sparks.append(Spark(ev["x"], ev["y"], color=(255, 160, 60) if ev.get("crit") else (255, 220, 100)))
                    elif et == "hit_taken":
                        hitstop_timer = max(hitstop_timer, 4)
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"], str(ev["damage"]), color=(255, 80, 80), big=True))
                        for _ in range(5):
                            sparks.append(Spark(ev["x"], ev["y"], color=(255, 80, 80)))
                    elif et == "shield_block":
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"], "BLOCKED", color=SHIELD_BLUE))
                        for _ in range(8):
                            sparks.append(Spark(ev["x"], ev["y"], color=SHIELD_BLUE))
                    elif et == "enemy_died":
                        apply_enemy_reward_drop(ev)
                    elif et == "boss_died":
                        trigger_lava_burst(ev["x"], ev["y"] + 50, count=12)
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"] - 20, "BOSS DEFEATED", color=GILT, big=True))
                        apply_enemy_reward_drop(ev)
                    elif et == "final_boss_died":
                        for _ in range(40):
                            trigger_lava_burst(ev["x"], ev["y"] + 50, count=3, intensity=1.5)
                        damage_numbers.append(DamageNumber(ev["x"], ev["y"] - 40, "THE DAMNED KING FALLS", color=(255, 100, 30), big=True))
                        apply_enemy_reward_drop(ev)
                player.events.clear()

                cull_counter += 1
                if cull_counter >= 60:
                    cull_counter = 0
                    cull_far_behind(player.anchor_x)
                if not player.alive:
                    game_over = True

            player.draw(screen, scroll_offset)
            for skel in active_skels:
                if skel.alive or skel.respawn_timer < 250:
                    skel.draw(screen, scroll_offset)
                    skel.draw_health_bar(screen, scroll_offset)
        else:
            player.draw(screen, scroll_offset)

        for sp in sparks:
            if tick_world:
                sp.update()
            sp.draw(screen, scroll_offset)
        if tick_world:
            sparks[:] = [s for s in sparks if not s.dead]

        for dn in damage_numbers:
            if tick_world:
                dn.update()
            dn.draw(screen, scroll_offset)
        if tick_world:
            damage_numbers[:] = [d for d in damage_numbers if not d.dead]

        if not game_over and not victory:
            next_x = get_next_shrine_x(shrines_activated)
            next_dist_m = None if next_x is None else max(0, int((next_x - player.anchor_x) / PIXELS_PER_METER))
            draw_hud(screen, player, distance_m)
            draw_shrine_tracker(screen, shrines_activated, TOTAL_SHRINES, next_dist_m)
            draw_strength_indicator(screen, player)
            draw_powerup_strip(screen, player)
            draw_keys(screen)
            if covenant_prompt_timer > 0:
                draw_covenant_prompt(screen)
            elif cheat_message_timer > 0:
                cheat_text = "ANCIENT POWER AWAKENED"
                cheat_surface = font_label.render(cheat_text, True, GILT_BRIGHT)
                outline = font_label.render(cheat_text, True, BLACK)

                cx = SCREEN_WIDTH // 2 - cheat_surface.get_width() // 2
                cy = 18

                for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    screen.blit(outline, (cx + ox, cy + oy))

                screen.blit(cheat_surface, (cx, cy))

            if cheat_message_timer > 0:
                cheat_text = "ANCIENT POWER AWAKENED"
                cheat_surface = font_label.render(cheat_text, True, GILT_BRIGHT)
                outline = font_label.render(cheat_text, True, BLACK)
                cx = SCREEN_WIDTH // 2 - cheat_surface.get_width() // 2
                cy = 18
                for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    screen.blit(outline, (cx + ox, cy + oy))
                screen.blit(cheat_surface, (cx, cy))

        if final_animation_phase == 1:
            t = final_animation_timer / 240.0
            alpha = int(40 + 60 * math.sin(final_animation_timer * 0.2) + t * 80)
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((255, 50, 20, max(0, min(255, alpha))))
            screen.blit(overlay, (0, 0))
            if final_animation_timer < 120:
                size = int(40 + (final_animation_timer / 120.0) * 30)
                f = _get_font(size)
                txt = f.render("THE WORLD BURNS", True, (255, 220, 100))
                outline = f.render("THE WORLD BURNS", True, BG_VOID)
                x = SCREEN_WIDTH // 2 - txt.get_width() // 2
                y = SCREEN_HEIGHT // 2 - txt.get_height() // 2
                for ox, oy in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
                    screen.blit(outline, (x + ox, y + oy))
                screen.blit(txt, (x, y))

        if game_over:
            draw_death_screen(screen, player.score, distance_m)
        elif paused:
            draw_pause_screen(screen)
        elif victory:
            draw_victory_screen(screen)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
