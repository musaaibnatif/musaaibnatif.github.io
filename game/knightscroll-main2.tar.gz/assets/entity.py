import pygame
import random
import os
import math

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = int(SCREEN_WIDTH * 0.8)

GREEN = (0, 255, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GOLD = (255, 223, 0)
COIN_GOLD = (255, 200, 30)
COIN_DARK = (180, 130, 10)
HEART_RED = (220, 40, 60)
CRIT_ORANGE = (255, 140, 30)
SHIELD_BLUE = (80, 180, 255)
BLOOD_RED = (140, 15, 20)

_SPRITE_CACHE = {}
_FLIPPED_CACHE = {}
_FONTS = {}
_DAMAGE_TEXT_CACHE = {}
_PARTICLE_FRAMES = None

# OPT (pygbag): pygame.time.get_ticks() crosses the Python→WASM boundary on
# every call. The hot draw paths used to call it 5–10 times per entity per
# frame. We snapshot it once per frame from main.py via set_frame_ticks() and
# hot paths read this local int instead. Falls back to a real call if the
# snapshot hasn't been taken (e.g. unit-test-style usage).
_FRAME_TICKS = 0


def set_frame_ticks(t):
    """Called once per frame by main.py before any drawing happens."""
    global _FRAME_TICKS
    _FRAME_TICKS = t


def _ticks():
    return _FRAME_TICKS or pygame.time.get_ticks()

# ---------------------------------------------------------------------------
# OPT: Tinted-silhouette cache.
# `mask.from_surface(img)` followed by `mask.to_surface(setcolor=...)` was the
# #1 hot path in this code: ran every frame for shield/godmode/strength/flash
# effects on every animation frame of the player. Since each animation frame
# is a stable cached Surface object, we can key by id(img) + (color+alpha).
# Each entry returns a *display-format* Surface ready to blit (with BLEND_ADD
# in the case of additive effects). Bounded LRU-ish via dict insertion order.
# ---------------------------------------------------------------------------
_SILHOUETTE_CACHE = {}
_SILHOUETTE_CACHE_LIMIT = 256

_MASK_CACHE = {}
_MASK_CACHE_LIMIT = 512


def _get_mask(img):
    key = id(img)
    mask = _MASK_CACHE.get(key)
    if mask is not None:
        return mask
    mask = pygame.mask.from_surface(img)
    if len(_MASK_CACHE) >= _MASK_CACHE_LIMIT:
        _MASK_CACHE.pop(next(iter(_MASK_CACHE)))
    _MASK_CACHE[key] = mask
    return mask

def _get_silhouette(img, rgba):
    """Return a per-pixel-alpha surface that is `img`'s opaque pixels recolored
    to the given (r, g, b, a). Cached by id(img) + rgba so repeated calls per
    frame are free after the first."""
    key = (id(img), rgba)
    surf = _SILHOUETTE_CACHE.get(key)
    if surf is not None:
        return surf
    mask = _get_mask(img)
    surf = mask.to_surface(setcolor=rgba, unsetcolor=(0, 0, 0, 0)).convert_alpha()
    if len(_SILHOUETTE_CACHE) >= _SILHOUETTE_CACHE_LIMIT:
        # Drop oldest entry. dict preserves insertion order in Py3.7+.
        _SILHOUETTE_CACHE.pop(next(iter(_SILHOUETTE_CACHE)))
    _SILHOUETTE_CACHE[key] = surf
    return surf

# ---------------------------------------------------------------------------
# OPT: Glow-circle atlas.
# Lots of effects allocate a small SRCALPHA surface every frame and draw 1-2
# circles on it just to additively blit. Pre-render once per (color, size).
# Each glow surface is sized (size*4, size*4) with two concentric circles to
# match the original look exactly.
# ---------------------------------------------------------------------------
_GLOW_CACHE = {}
_GLOW_CACHE_LIMIT = 256

def _get_two_circle_glow(outer_rgba, inner_rgba, outer_r, inner_r, surf_w=None):
    """Build (or fetch) a soft glow surface: outer circle (rgba=outer_rgba,
    radius=outer_r) then inner circle (rgba=inner_rgba, radius=inner_r), both
    drawn at the center of a square surface.

    surf_w is the side length (default = max(outer_r, inner_r) * 4 to leave
    room for soft edges, but call sites can match the original allocation).
    The centering offset returned by `glow_offset(...)` below is what callers
    should subtract from world positions when blitting.
    """
    if surf_w is None:
        surf_w = max(outer_r, inner_r) * 4
    key = (outer_rgba, inner_rgba, outer_r, inner_r, surf_w)
    surf = _GLOW_CACHE.get(key)
    if surf is not None:
        return surf
    surf = pygame.Surface((surf_w, surf_w), pygame.SRCALPHA)
    cx = surf_w // 2
    pygame.draw.circle(surf, outer_rgba, (cx, cx), outer_r)
    if inner_r > 0:
        pygame.draw.circle(surf, inner_rgba, (cx, cx), inner_r)
    surf = surf.convert_alpha()
    if len(_GLOW_CACHE) >= _GLOW_CACHE_LIMIT:
        _GLOW_CACHE.pop(next(iter(_GLOW_CACHE)))
    _GLOW_CACHE[key] = surf
    return surf

# ---------------------------------------------------------------------------
# OPT: Faded-image cache.
# Particle.draw and DamageNumber.draw used `img = img.copy(); img.set_alpha(a)`
# every frame, allocating a fresh surface per particle per frame. Since alpha
# changes monotonically over a small number of life-frames, we can cache by
# (id(img), alpha-bucket) and reuse. Alpha quantized to 16 buckets keeps the
# cache tiny while remaining visually identical.
# ---------------------------------------------------------------------------
_FADED_CACHE = {}
_FADED_CACHE_LIMIT = 512

def _get_faded(img, alpha):
    """Return a copy of `img` with set_alpha applied. Quantized to 16 levels."""
    if alpha >= 255:
        return img
    bucket = (alpha >> 4) << 4   # 16-step quantization, always <= 255
    if bucket <= 0:
        bucket = 1
    key = (id(img), bucket)
    surf = _FADED_CACHE.get(key)
    if surf is not None:
        return surf
    surf = img.copy()
    surf.set_alpha(bucket)
    if len(_FADED_CACHE) >= _FADED_CACHE_LIMIT:
        _FADED_CACHE.pop(next(iter(_FADED_CACHE)))
    _FADED_CACHE[key] = surf
    return surf

ACT_IDLE = 0
ACT_RUN = 1
ACT_JUMP = 2
ACT_ATTACK = 3
ACT_DEATH = 4
ACT_HIT = 5
ACT_REACT = 6
ANIMATION_TYPES = ["idle", "run", "jump", "attack", "death", "hit", "react"]
FRAME_MS = 90

# (name, primary color, secondary color, crown style)
BOSS_VARIANTS = [
    ("Warden",  (180, 80, 200),  (90, 40, 120),  "spiked"),
    ("Reaper",  (40, 180, 200),  (15, 90, 130),  "horned"),
    ("Defiler", (90, 230, 130),  (30, 120, 60),  "antler"),
    ("Tyrant",  (255, 200, 60),  (180, 120, 20), "regal"),
]

CUSTOM_FONT_FILENAME = "Broken Console Bold.ttf"


def _resolve_custom_font_path():
    """Find the bundled custom TTF font from common game launch locations."""
    base_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
    candidates = (
        os.path.join(base_dir, CUSTOM_FONT_FILENAME),
        os.path.join(os.getcwd(), CUSTOM_FONT_FILENAME),
        CUSTOM_FONT_FILENAME,
    )
    for path in candidates:
        if os.path.exists(path):
            return path
    return CUSTOM_FONT_FILENAME


def _get_font(size):
    if size not in _FONTS:
        try:
            _FONTS[size] = pygame.font.Font(_resolve_custom_font_path(), size)
        except Exception:
            # Fallback keeps the game playable if the TTF is missing from a build.
            _FONTS[size] = pygame.font.Font(None, size)
    return _FONTS[size]

_TEXT_SURF_CACHE = {}
_TEXT_SURF_CACHE_LIMIT = 512


def _get_text_surf(font, text, color):
    key = (id(font), str(text), color)
    surf = _TEXT_SURF_CACHE.get(key)
    if surf is not None:
        return surf
    surf = font.render(str(text), True, color).convert_alpha()
    if len(_TEXT_SURF_CACHE) >= _TEXT_SURF_CACHE_LIMIT:
        _TEXT_SURF_CACHE.pop(next(iter(_TEXT_SURF_CACHE)))
    _TEXT_SURF_CACHE[key] = surf
    return surf


_SCRATCH_ALPHA_SURFACES = {}
_SCRATCH_ALPHA_CACHE_LIMIT = 64


def _get_scratch_alpha_surface(w, h):
    key = (max(1, int(w)), max(1, int(h)))
    surf = _SCRATCH_ALPHA_SURFACES.get(key)
    if surf is None:
        surf = pygame.Surface(key, pygame.SRCALPHA).convert_alpha()
        if len(_SCRATCH_ALPHA_SURFACES) >= _SCRATCH_ALPHA_CACHE_LIMIT:
            _SCRATCH_ALPHA_SURFACES.pop(next(iter(_SCRATCH_ALPHA_SURFACES)))
        _SCRATCH_ALPHA_SURFACES[key] = surf
    surf.fill((0, 0, 0, 0))
    return surf


def _placeholder_frame(char_type, animation, scale):
    w = int(28 * scale)
    h = int(42 * scale)
    surf = pygame.Surface((max(8, w), max(8, h)), pygame.SRCALPHA)
    color = (210, 210, 230) if char_type == "Player" else (190, 180, 160)
    pygame.draw.rect(surf, color, surf.get_rect(), border_radius=4)
    pygame.draw.rect(surf, BLACK, surf.get_rect(), 1, border_radius=4)
    return surf.convert_alpha()


def _numeric_key(filename):
    stem = os.path.splitext(filename)[0]
    try:
        return int(stem)
    except ValueError:
        return stem


def load_animations(char_type, scale):
    key = (char_type, round(scale, 3))
    if key in _SPRITE_CACHE:
        return _SPRITE_CACHE[key]

    animation_list = []
    for animation in ANIMATION_TYPES:
        frames = []
        folder = f"img/{char_type}/{animation}"
        if os.path.isdir(folder):
            pngs = [f for f in os.listdir(folder) if f.lower().endswith(".png")]
            pngs.sort(key=_numeric_key)
            for filename in pngs:
                path = os.path.join(folder, filename)
                try:
                    orig_img = pygame.image.load(path).convert_alpha()
                    crop_rect = orig_img.get_bounding_rect()
                    # OPT: skip the intermediate .copy(). pygame.transform.scale
                    # always allocates a new surface, so feeding it a subsurface
                    # view is fine and saves an entire surface allocation+copy.
                    if crop_rect.width <= 0 or crop_rect.height <= 0:
                        crop_img = orig_img
                    else:
                        crop_img = orig_img.subsurface(crop_rect)
                    img = pygame.transform.scale(
                        crop_img,
                        (max(1, int(crop_img.get_width() * scale)),
                         max(1, int(crop_img.get_height() * scale)))
                    ).convert_alpha()
                    frames.append(img)
                except Exception:
                    pass
        if not frames:
            frames.append(_placeholder_frame(char_type, animation, scale))
        animation_list.append(frames)

    _SPRITE_CACHE[key] = animation_list
    _FLIPPED_CACHE[key] = [
        [pygame.transform.flip(frame, True, False).convert_alpha() for frame in frames]
        for frames in animation_list
    ]
    return animation_list


def get_flipped(char_type, scale):
    return _FLIPPED_CACHE.get((char_type, round(scale, 3)))


def draw_boss_crown(surface, x, y, w, style, color, time_offset=0):
    t = _ticks() * 0.003 + time_offset
    cx = x + w // 2
    cy = y - 4

    if style == "spiked":
        pts = [(cx - 14, cy), (cx - 10, cy - 14), (cx - 4, cy - 6),
               (cx, cy - 18), (cx + 4, cy - 6), (cx + 10, cy - 14), (cx + 14, cy)]
        pygame.draw.polygon(surface, (20, 10, 15), pts)
        pygame.draw.polygon(surface, color, pts, 2)
        pygame.draw.circle(surface, color, (cx, cy - 4), 3)
    elif style == "horned":
        pts_l = []
        for i in range(8):
            ang = math.pi - (i / 7) * math.pi * 0.5
            r = 4 + i * 2
            pts_l.append((cx - 6 + math.cos(ang) * r, cy - math.sin(ang) * r))
        pts_r = []
        for i in range(8):
            ang = (i / 7) * math.pi * 0.5
            r = 4 + i * 2
            pts_r.append((cx + 6 + math.cos(ang) * r, cy - math.sin(ang) * r))
        pygame.draw.lines(surface, (15, 8, 12), False, pts_l, 5)
        pygame.draw.lines(surface, color, False, pts_l, 2)
        pygame.draw.lines(surface, (15, 8, 12), False, pts_r, 5)
        pygame.draw.lines(surface, color, False, pts_r, 2)
    elif style == "antler":
        def branch(ox, oy, angle, length, depth):
            ex = ox + math.cos(angle) * length
            ey = oy + math.sin(angle) * length
            pygame.draw.line(surface, (15, 8, 12), (ox, oy), (ex, ey), 4)
            pygame.draw.line(surface, color, (ox, oy), (ex, ey), 2)
            if depth > 0:
                branch(ex, ey, angle - 0.6, length * 0.6, depth - 1)
                branch(ex, ey, angle + 0.6, length * 0.6, depth - 1)
        branch(cx - 5, cy, -math.pi / 2 - 0.3, 12, 1)
        branch(cx + 5, cy, -math.pi / 2 + 0.3, 12, 1)
    elif style == "regal":
        band_top = cy - 6
        pygame.draw.rect(surface, (20, 12, 8), (cx - 16, band_top, 32, 8))
        pygame.draw.rect(surface, color, (cx - 16, band_top, 32, 8), 1)
        for offset, h in [(-12, 6), (0, 12), (12, 6)]:
            pygame.draw.polygon(surface, color, [
                (cx + offset - 3, band_top),
                (cx + offset + 3, band_top),
                (cx + offset, band_top - h)
            ])
            pygame.draw.circle(surface, (255, 80, 80), (cx + offset, band_top - h + 2), 2)
        pygame.draw.circle(surface, (255, 60, 60), (cx, band_top + 4), 2)

def draw_final_boss_crown(surface, x, y, w):
    t = _ticks() * 0.005
    cx = x + w // 2
    cy = y - 4
    for i in range(-2, 3):
        ox = i * 6
        h = 18 if i == 0 else (14 if abs(i) == 1 else 10)
        pygame.draw.polygon(surface, (60, 20, 5), [(cx + ox - 4, cy), (cx + ox + 4, cy), (cx + ox, cy - h)])
        pygame.draw.polygon(surface, (255, 200, 60), [(cx + ox - 3, cy), (cx + ox + 3, cy), (cx + ox, cy - h + 2)])
        flicker = int(math.sin(t + i) * 50 + 200)
        pygame.draw.circle(surface, (flicker, flicker // 2, 30), (cx + ox, cy - h + 4), 1)
    pygame.draw.circle(surface, (255, 40, 30), (cx, cy + 2), 4)
    pygame.draw.circle(surface, (255, 200, 200), (cx - 1, cy + 1), 1)


class Entity:
    def __init__(self, char_type, x, y, scale, force_lucky=False, tier=0,
                 is_final_boss=False, boss_variant=None):
        self.alive = True
        self.char_type = char_type
        self.direction = 1
        self.vel_y = 0
        self.jump = False
        self.flip = False
        self.attacking = False
        self.running = False
        self.hit = False
        self.hit_stun_immunity = 0
        self.reacting = False
        self.has_seen_player = False
        self.frame_index = 0
        self.action = ACT_IDLE
        self.update_time = pygame.time.get_ticks()

        self.move_counter = 0
        self.idling = False
        self.idling_counter = 0
        self.lucky_skel = False
        self.is_boss = False
        self.is_final_boss = is_final_boss
        self.boss_variant = boss_variant
        self.tier = tier
        self.respawn_timer = 0
        self.heal_on_kill = 0
        self.collected = False
        self.score = 0

        self.swing_active = False
        self.swing_locked_rect = None
        self.swing_mask = None
        self.swing_mask_rect = None
        # Tracks every target hit during the current swing.
        # This lets one player attack damage multiple overlapping enemies,
        # while still preventing repeated damage to the same enemy in one swing.
        self.swing_dealt = False
        self.swing_hit_targets = set()
        self.swing_started_this_attack = False

        self.attack_cooldown = 0
        self.attack_cooldown_max = 70
        self.fury_timer = 0
        self.speed_boost_timer = 0
        self.double_dmg_timer = 0
        self.shield_timer = 0
        self.invuln_timer = 0
        self.shrines_cleared = 0
        self.ethereal_glow_timer = 0

        # Hidden cheat mode. Activated from main.py by typing the cheat sequence.
        self.cheat_mode = False
        self.cheat_speed = 25
        self.cheat_damage = 999999
        self.cheat_mode = False
        self.covenant_fx_timer = 0
        
        self.events = []

        if char_type == "Skeleton":
            if force_lucky:
                self.lucky_skel = True
                self.is_boss = True
            elif random.randint(1, 12) == 1:
                self.lucky_skel = True

        if char_type == "Skeleton":
            if self.is_final_boss:
                actual_scale = scale * 2.4
            elif self.is_boss:
                actual_scale = scale * 1.9
            elif self.lucky_skel:
                actual_scale = scale * 1.4
            else:
                actual_scale = scale
        else:
            actual_scale = scale
        self.actual_scale = actual_scale

        self.animation_list = load_animations(char_type, actual_scale)
        self.flipped_list = get_flipped(char_type, actual_scale)
        self.image = self.animation_list[ACT_IDLE][0]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.anchor_x = self.rect.centerx
        self.anchor_y = self.rect.bottom
        self.vision = pygame.Rect(0, 0, int(280 + actual_scale * 30), 80)

        hp_mul = 1 + tier * 0.20
        dmg_mul = 1 + tier * 0.15

        if char_type == "Player":
            self.health = 100
            self.max_health = 100
            self.attack_rect_w = int(2.6 * self.rect.width)
            self.attack_rect_h = int(1.0 * self.rect.height)
            self.base_dmg_min, self.base_dmg_max = 13, 24
            self.attack_cooldown_max = 25
        else:
            w = self.rect.width
            h = self.rect.height
            if self.is_final_boss:
                self.health = int(300 * hp_mul)
                self.base_dmg_min = int(22 * dmg_mul)
                self.base_dmg_max = int(38 * dmg_mul)
                self.attack_cooldown_max = 35
            elif self.is_boss:
                self.health = int(180 * hp_mul)
                self.base_dmg_min = int(18 * dmg_mul)
                self.base_dmg_max = int(35 * dmg_mul)
                self.attack_cooldown_max = 25
            elif self.lucky_skel:
                self.health = int(70 * hp_mul)
                self.base_dmg_min = int(12 * dmg_mul)
                self.base_dmg_max = int(22 * dmg_mul)
                self.attack_cooldown_max = 30
            else:
                self.health = int(40 * hp_mul)
                self.base_dmg_min = int(8 * dmg_mul)
                self.base_dmg_max = int(16 * dmg_mul)
                self.attack_cooldown_max = 40
            self.max_health = self.health
            self.attack_rect_w = int(0.85 * w)
            self.attack_rect_h = int(0.85 * h)

        # Stable body dimensions used for UI and body-blocking. The sprite frames are
        # cropped per-frame, so current image width/height can change during run/attack
        # animations. Keeping a stable body size prevents bars from wobbling and keeps
        # elite collision from changing frame-to-frame.
        body_actions = [ACT_IDLE, ACT_RUN, ACT_JUMP, ACT_HIT, ACT_REACT]
        body_frames = []
        for action_id in body_actions:
            if 0 <= action_id < len(self.animation_list):
                body_frames.extend(self.animation_list[action_id])
        if not body_frames:
            body_frames = [frame for frames in self.animation_list for frame in frames]
        self.body_visual_w = max(frame.get_width() for frame in body_frames)
        self.body_visual_h = max(frame.get_height() for frame in body_frames)
        self.cooldown_bar_w = max(42, int(self.body_visual_w * 0.65))

    def activate_cheat_mode(self):
        """Enable hidden god-mode cheat for the player."""
        if self.char_type != "Player":
            return
        self.cheat_mode = True
        self.cheat_speed = 25
        # Keep the visible HP normal so the HUD/browser does not get weird.
        # Infinite health is handled by ignoring enemy damage and refilling every frame.
        self.health = self.max_health
        # Damage is calculated from the target's current HP, so it one-shots
        # without rendering massive 999999 damage numbers.
        self.speed_boost_timer = 0
        self.double_dmg_timer = 0
        self.fury_timer = 0
        self.invuln_timer = 0
        self.attack_cooldown_max = 0
        self.covenant_fx_timer = 180
        

    def _sync_rect_to_anchor(self):
        new_rect = self.image.get_rect()
        new_rect.midbottom = (int(self.anchor_x), int(self.anchor_y))
        self.rect = new_rect

    def _attack_impact_frame(self):
        frames = len(self.animation_list[ACT_ATTACK])
        if frames <= 0:
            return 0
        if self.char_type == "Skeleton":
            # The skeleton impact frame is the 8th image: zero-based index 7.
            return min(7, frames - 1)
        return min(2, frames - 1)
    
    def _is_attack_damage_frame(self):
        if self.action != ACT_ATTACK:
            return False

        frames = len(self.animation_list[ACT_ATTACK])

        if self.char_type == "Player":
            # For your uploaded knight frames:
            # frame 0 = windup
            # frame 1-2 = real slash
            # frame 3 = recovery
            return 1 <= self.frame_index <= min(2, frames - 1)

        if self.char_type == "Skeleton":
            impact = self._attack_impact_frame()
            return impact <= self.frame_index <= min(impact + 1, frames - 1)

        return False

    def update(self):
        if self.alive:
            if self.hit:
                self._set_action(ACT_HIT)
            elif self.attacking:
                self._set_action(ACT_ATTACK)
            elif self.reacting:
                self._set_action(ACT_REACT)
            elif self.jump and self.char_type == "Player":
                self._set_action(ACT_JUMP)
            elif self.running:
                self._set_action(ACT_RUN)
            else:
                self._set_action(ACT_IDLE)

        if self.char_type == "Player" and self.cheat_mode:
            self.health = self.max_health

        self.check_alive()
        self.image = self.animation_list[self.action][self.frame_index]
        self._sync_rect_to_anchor()

        if self.action == ACT_ATTACK and self.alive:
            if self._is_attack_damage_frame():
                self._start_swing()
            else:
                if self.swing_active:
                    self._end_swing()

        now = pygame.time.get_ticks()
        if now - self.update_time > FRAME_MS:
            self.update_time = now
            self.frame_index += 1

        if self.frame_index >= len(self.animation_list[self.action]):
            if self.action == ACT_REACT:
                self.reacting = False
                self.frame_index = 0
            elif self.action == ACT_HIT:
                self.hit = False
                self.frame_index = 0
            elif self.action == ACT_DEATH:
                self.frame_index = len(self.animation_list[self.action]) - 1
                self.alive = False
            elif self.action == ACT_ATTACK:
                self._end_swing()
                self.attacking = False
                self.swing_started_this_attack = False
                if self.attack_cooldown_max > 0:
                    # Cooldown starts AFTER the swing finishes. Before this, the timer
                    # was burning down during the attack animation, which made higher
                    # cooldown settings feel like they did nothing.
                    self.attack_cooldown = max(self.attack_cooldown, self.attack_cooldown_max)
                self.frame_index = 0
            else:
                self.frame_index = 0

        # OPT: was a getattr/setattr loop over 8 attribute names every frame on
        # every entity. Direct decrements are roughly 10x faster and remove a
        # tuple+name-lookup per timer per entity per frame.
        if self.speed_boost_timer > 0:
            self.speed_boost_timer -= 1
        if self.double_dmg_timer > 0:
            self.double_dmg_timer -= 1
        if self.shield_timer > 0:
            self.shield_timer -= 1
        if self.invuln_timer > 0:
            self.invuln_timer -= 1
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        if self.fury_timer > 0:
            self.fury_timer -= 1
        if self.ethereal_glow_timer > 0:
            self.ethereal_glow_timer -= 1
        if self.covenant_fx_timer > 0:
            self.covenant_fx_timer -= 1
        if self.hit_stun_immunity > 0:
            self.hit_stun_immunity -= 1

    def _set_action(self, new_action):
        if new_action != self.action:
            self.action = new_action
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()
            if new_action == ACT_ATTACK:
                self.swing_started_this_attack = self.swing_active
            else:
                self.swing_started_this_attack = False
                if self.swing_active:
                    self._end_swing()

    def _start_swing(self):
        # Use the exact visible attack sprite as the hitbox.
        # This includes the sword/slash pixels instead of a giant rectangle.

        if self.flip:
            img = self.flipped_list[self.action][self.frame_index]
        else:
            img = self.image

        self.swing_mask = _get_mask(img)
        self.swing_mask_rect = self.rect.copy()

        self.swing_active = True
        self.swing_dealt = False

    def _end_swing(self):
        self.swing_active = False
        self.swing_locked_rect = None
        self.swing_mask = None
        self.swing_mask_rect = None
        self.swing_dealt = False
        self.swing_hit_targets.clear()

    def move(self, screen_height, surface, targets):
        base_speed = 10
        if self.cheat_mode:
            speed = self.cheat_speed
        else:
            speed = int(base_speed * 1.6) if self.speed_boost_timer > 0 else base_speed
        gravity = 0.75
        dx = 0
        dy = 0
        self.running = False
        key = pygame.key.get_pressed()

        if self.alive and not self.attacking:
            if key[pygame.K_a] and not key[pygame.K_d]:
                dx = -speed
                self.flip = True
                self.direction = -1
                self.running = True
            elif key[pygame.K_d] and not key[pygame.K_a]:
                dx = speed
                self.flip = False
                self.direction = 1
                self.running = True
            if key[pygame.K_w] and not self.jump:
                self.vel_y = -11
                self.jump = True
            if key[pygame.K_f] and self.attack_cooldown <= 0:
                self.attacking = True
                self.swing_started_this_attack = False
                self.frame_index = 0
                self.swing_hit_targets.clear()

        if self.swing_active:
            self._try_apply_swing(targets)

        self.vel_y += gravity
        dy += self.vel_y
        ground_y = screen_height - 66
        if self.anchor_y + dy > ground_y:
            self.vel_y = 0
            self.jump = False
            dy = ground_y - self.anchor_y

        old_rect = self.rect.copy()
        self.anchor_x += dx

        # Body-blocking only applies to elites: lucky skeletons and bosses.
        # Normal skeletons stay pass-through so the player can run through them.
        #
        # Godmode/cheat mode: pass through every mob, including lucky skeletons,
        # bosses, and the final boss.
        #
        # Speed boost: pass through normal lucky skeletons, but bosses and the
        # final boss still block the player.
        if self.char_type == "Player" and dx != 0 and targets and not self.cheat_mode:
            self._sync_rect_to_anchor()
            swept_rect = old_rect.union(self.rect)
            for target in targets:
                # OPT: every Entity has these attributes - avoid getattr overhead.
                if not target.alive:
                    continue
                if target.char_type != "Skeleton":
                    continue

                is_boss_blocker = target.is_boss or target.is_final_boss
                is_lucky_blocker = target.lucky_skel and not is_boss_blocker

                # Normal skeletons never body-block.
                if not (is_lucky_blocker or is_boss_blocker):
                    continue

                # Speed boost lets you run through normal lucky skeletons,
                # but not bosses or the final boss.
                if self.speed_boost_timer > 0 and is_lucky_blocker:
                    continue

                block_rect = target.rect
                if not (self.rect.colliderect(block_rect) or swept_rect.colliderect(block_rect)):
                    continue

                # Resolve based on where the player came from, not just the key being
                # pressed. This fixes the exploit where starting slightly overlapped and
                # pressing away could snap the player through the elite to the other side.
                if old_rect.right <= block_rect.left and dx > 0:
                    self.rect.right = block_rect.left
                elif old_rect.left >= block_rect.right and dx < 0:
                    self.rect.left = block_rect.right
                elif old_rect.centerx <= block_rect.centerx:
                    self.rect.right = block_rect.left
                else:
                    self.rect.left = block_rect.right

                self.anchor_x = self.rect.centerx
                dx = 0
                break

        self.anchor_y += dy
        if self.anchor_x < 30:
            self.anchor_x = 30
        self._sync_rect_to_anchor()

    def ai(self, surface, target):
        if self.is_final_boss:
            speed = 3.5
        elif self.is_boss:
            speed = 3.0
        elif self.lucky_skel:
            speed = 2.6
        else:
            speed = 2.2

        gravity = 0.75
        dx = 0
        dy = 0
        self.running = False

        if self.alive and not self.attacking:
            dist_to_player = target.rect.centerx - self.rect.centerx
            abs_dist = abs(dist_to_player)

            if abs_dist < 500:
                self.direction = 1 if dist_to_player > 0 else -1
                self.flip = self.direction == -1

            self.vision.center = (self.rect.centerx + 140 * self.direction, self.rect.centery)
            can_see = self.vision.colliderect(target.rect) and abs_dist < 350

            if can_see and not self.has_seen_player and not self.reacting:
                self.reacting = True
                self.has_seen_player = True
                self.frame_index = 0

            attack_range = self.rect.width * 0.7
            if can_see and not self.reacting:
                if abs_dist < attack_range and self.attack_cooldown <= 0:
                    if target.alive:
                        self.attacking = True
                        self.swing_started_this_attack = False
                        self.swing_hit_targets.clear()
                        self.frame_index = 0
                else:
                    dx = speed * self.direction
                    self.running = True
            elif not self.reacting:
                if not self.idling and random.randint(1, 800) == 1:
                    self.idling = True
                    self.idling_counter = 60
                if not self.idling:
                    dx = speed * self.direction * 0.7
                    self.running = True
                    self.move_counter += 1
                    if self.move_counter > 60:
                        self.direction *= -1
                        self.flip = self.direction == -1
                        self.move_counter = 0
                else:
                    self.idling_counter -= 1
                    if self.idling_counter <= 0:
                        self.idling = False

        if self.swing_active:
            self._try_apply_swing([target])

        self.vel_y += gravity
        dy += self.vel_y
        ground_y = SCREEN_HEIGHT - 66
        if self.anchor_y + dy > ground_y:
            self.vel_y = 0
            self.jump = False
            dy = ground_y - self.anchor_y

        self.anchor_x += dx
        self.anchor_y += dy
        self._sync_rect_to_anchor()

    def _try_apply_swing(self, targets):
        if not self.swing_active or self.swing_mask is None or self.swing_mask_rect is None:
            return

        hit_anything = False
        is_player = self.char_type == "Player"

        for target in targets:
            if not target.alive:
                continue

            target_id = id(target)
            if target_id in self.swing_hit_targets:
                continue

            # Quick rectangle check first for performance
            if not self.swing_mask_rect.colliderect(target.rect):
                continue

            # Use the target's actual visible sprite too
            if target.flip:
                target_img = target.flipped_list[target.action][target.frame_index]
            else:
                target_img = target.image

            target_mask = _get_mask(target_img)

            offset = (
                target.rect.x - self.swing_mask_rect.x,
                target.rect.y - self.swing_mask_rect.y
            )

            # Pixel-perfect collision:
            # damage only happens if the visible slash/sword pixels touch the target sprite
            if self.swing_mask.overlap(target_mask, offset):
                self._deal_damage(target)
                self.swing_hit_targets.add(target_id)
                hit_anything = True

                # Player can cleave multiple enemies.
                # Skeleton only needs to hit the player once.
                if not is_player:
                    break

        if hit_anything:
            self.swing_dealt = True

    def _deal_damage(self, target):
        if self.char_type == "Player":
            if self.cheat_mode:
                is_crit = False
                # OPT: target is always an Entity which always has .health.
                dmg = max(1, int(target.health))
            else:
                is_crit = random.random() < 0.15
                dmg = random.randint(self.base_dmg_min, self.base_dmg_max)
                if self.shrines_cleared > 0:
                    dmg = int(dmg * (1 + 0.08 * self.shrines_cleared))
                if self.fury_timer > 0:
                    dmg = int(dmg * 1.25)
                if self.double_dmg_timer > 0:
                    dmg *= 2
                if is_crit:
                    dmg = int(dmg * 1.8)
            target.health -= dmg
            if target.hit_stun_immunity <= 0 and not target.attacking:
                target.hit = True
                target.frame_index = 0
                target.hit_stun_immunity = 40
            target.check_alive()
            self.events.append({"type": "hit_landed", "x": target.rect.centerx, "y": target.rect.top,
                                "damage": dmg, "crit": is_crit})

            if not target.alive and not target.collected:
                if target.is_final_boss:
                    self.score += 500
                    # Bosses always give health and have a chance to drop a power-up.
                    self.events.append({
                        "type": "final_boss_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "heal_amount": 100,
                        "drop_powerup": random.random() < 0,
                    })
                elif target.is_boss:
                    self.score += random.randint(150, 250)
                    # Bosses always give health and have a chance to drop a power-up.
                    self.events.append({
                        "type": "boss_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "heal_amount": random.randint(40, 60),
                        "drop_powerup": random.random() < 0.55,
                    })
                elif target.lucky_skel:
                    self.score += random.randint(40, 70)
                    # Lucky skeletons are the only normal enemy type that can reward health/power-ups.
                    # These are independent rolls, so getting both is possible but rare.
                    drop_health = random.random() < 0.28
                    drop_powerup = random.random() < 0.15
                    self.events.append({
                        "type": "enemy_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "lucky": True,
                        "heal_amount": random.randint(15, 25) if drop_health else 0,
                        "drop_powerup": drop_powerup,
                    })
                else:
                    self.score += random.randint(15, 24)

                    # Very low chance for normal skeletons to drop health
                    drop_health = random.random() < 0.08  # 8% chance
                    
                    self.events.append({
                        "type": "enemy_died",
                        "x": target.rect.centerx,
                        "y": target.rect.top,
                        "lucky": False,
                        "heal_amount": random.randint(10, 18) if drop_health else 0,
                        "drop_powerup": False,
                    })
                target.collected = True

        elif self.char_type == "Skeleton":
            if target.cheat_mode:
                target.health = target.max_health
                return

            if target.invuln_timer > 0:
                return

            dmg = random.randint(self.base_dmg_min, self.base_dmg_max)

            if target.shield_timer > 0:
                original_dmg = dmg
                dmg = max(1, int(dmg * 0.5))
                target.events.append({
                    "type": "shield_reduce",
                    "x": target.rect.centerx,
                    "y": target.rect.top,
                    "blocked": original_dmg - dmg,
                    "damage": dmg,
                })

            target.health -= dmg
            target.hit = True
            target.frame_index = 0
            target.invuln_timer = 30
            target.events.append({"type": "hit_taken", "x": target.rect.centerx, "y": target.rect.top, "damage": dmg})

    def _get_tier_color(self):
        if self.tier <= 0:
            return None

        tier_colors = [
            (120, 170, 255),  # tier 1 blue
            (120, 255, 160),  # tier 2 green
            (255, 210, 90),   # tier 3 gold
            (255, 130, 70),   # tier 4 orange
            (130, 10, 18),    # tier 5+ dark red
        ]

        return tier_colors[min(self.tier - 1, len(tier_colors) - 1)]
    
    def _draw_tier_aura(self, surface, screen_x, img):
        if self.char_type != "Skeleton":
            return
        if self.tier <= 0:
            return
        if self.is_boss or self.is_final_boss:
            return

        color = self._get_tier_color()
        if color is None:
            return

        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2

        # Keep radius stable so the glow cache reuses the same surfaces.
        base_radius = int(max(img.get_width(), img.get_height()) * 0.38)

        glow = _get_two_circle_glow(
            (color[0], color[1], color[2], 22),
            (color[0], color[1], color[2], 8),
            base_radius,
            max(6, base_radius // 2),
            surf_w=base_radius * 2 + 20
        )

        surface.blit(
            glow,
            (cx - glow.get_width() // 2, cy - glow.get_height() // 2),
            special_flags=pygame.BLEND_RGBA_ADD
        )
        
    def _get_enemy_overlay_color(self):
        if self.char_type != "Skeleton":
            return None

        # Final boss keeps its own special color
        if self.is_final_boss:
            return (255, 70, 30)

        # Lucky skeletons should follow tier color, not gold.
        # Put this BEFORE boss because some forced lucky skels can also have is_boss = True.
        if self.lucky_skel:
            return self._get_tier_color()

        # Regular bosses keep boss variant colors
        if self.is_boss:
            if self.boss_variant is not None and self.boss_variant < len(BOSS_VARIANTS):
                _, primary_color, _, _ = BOSS_VARIANTS[self.boss_variant]
                return primary_color
            return GOLD

        # Normal skeletons only get tier color if tier > 0
        if self.tier > 0:
            return self._get_tier_color()

        return None


    def _draw_enemy_color_overlay(self, surface, screen_x, img):
        if self.char_type != "Skeleton" or not self.alive:
            return

        color = self._get_enemy_overlay_color()
        if color is None:
            return

        if self.is_final_boss:
            alpha = 95

        # Lucky skeletons get a clear tier tint, but not gold.
        # Put this BEFORE boss for the same reason as above.
        elif self.lucky_skel:
            alpha = 55

        elif self.is_boss:
            alpha = 85
        else:
            # Normal skeletons barely show their tier color.
            alpha = min(20, 6 + self.tier * 3)

        overlay = _get_silhouette(img, (color[0], color[1], color[2], alpha))

        # Keep this as a normal alpha blit, not BLEND_ADD.
        # This makes it an actual sprite-shaped tint, not a glow/orb.
        surface.blit(overlay, (screen_x, self.rect.y))
        
    def draw_health_bar(self, surface, scroll_offset):
        if self.char_type == "Player" or not self.alive:
            return
        ratio = max(0, min(1, self.health / self.max_health))
        if self.is_final_boss:
            bar_len = 140
            bar_color = (255, 80, 30)
        elif self.is_boss:
            if self.boss_variant is not None and self.boss_variant < len(BOSS_VARIANTS):
                _, bar_color, _, _ = BOSS_VARIANTS[self.boss_variant]
            else:
                bar_color = GOLD
            bar_len = 110
        elif self.lucky_skel:
            bar_len = 80
            bar_color = self._get_tier_color() or (255, 200, 80)
        else:
            bar_len = 56
            bar_color = (80, 220, 100)

        screen_x = int(self.rect.centerx - scroll_offset - bar_len // 2)
        bar_y = self.rect.y - 12
        pygame.draw.rect(surface, BLACK, (screen_x - 1, bar_y, bar_len + 2, 6))
        pygame.draw.rect(surface, (50, 15, 15), (screen_x, bar_y + 1, bar_len, 4))
        pygame.draw.rect(surface, bar_color, (screen_x, bar_y + 1, int(bar_len * ratio), 4))

        if self.tier > 0 and not self.is_boss and not self.is_final_boss:
            pip_color = self._get_tier_color()

            shown_pips = min(self.tier, 5)
            pip_radius = 4
            pip_gap = 10

            pip_y = bar_y - 8
            start_x = screen_x + bar_len // 2 - ((shown_pips - 1) * pip_gap) // 2

            for i in range(shown_pips):
                px = start_x + i * pip_gap

                # black outer circle for readability
                pygame.draw.circle(surface, BLACK, (px, pip_y), pip_radius + 1)

                # colored tier pip
                pygame.draw.circle(surface, pip_color, (px, pip_y), pip_radius)
                
        if self.attack_cooldown > 0:
            cd_ratio = self.attack_cooldown / self.attack_cooldown_max
            cd_y = bar_y - 5
            pygame.draw.line(surface, (55, 45, 60), (screen_x, cd_y), (screen_x + bar_len, cd_y), 2)
            pygame.draw.line(surface, (200, 100, 200), (screen_x, cd_y),
                             (screen_x + int(bar_len * cd_ratio), cd_y), 2)

        if self.is_final_boss:
            label_text = "THE DAMNED KING"
            label_color = (255, 100, 50)
        elif self.is_boss and self.boss_variant is not None and self.boss_variant < len(BOSS_VARIANTS):
            name, primary_color, _, _ = BOSS_VARIANTS[self.boss_variant]
            label_text = name.upper()
            label_color = primary_color
        else:
            label_text = None
            label_color = None

        if label_text:
            font = _get_font(13)
            label = _get_text_surf(font, label_text, label_color)
            outline = _get_text_surf(font, label_text, BLACK)
            lx = self.rect.centerx - scroll_offset - label.get_width() // 2
            for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                surface.blit(outline, (lx + ox, bar_y - 18 + oy))
            surface.blit(label, (lx, bar_y - 18))

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.alive = False
            self._set_action(ACT_DEATH)

    def draw(self, surface, scroll_offset):
        screen_x = int(self.rect.x - scroll_offset)
        if screen_x < -self.rect.width or screen_x > SCREEN_WIDTH:
            return
        img = self.flipped_list[self.action][self.frame_index] if self.flip else self.image

        if self.alive:
            # OPT: cache char_type comparisons. The original code branched on
            # `self.char_type == "Player"` 8+ times in a row and `== "Skeleton"`
            # 4+ times. Each comparison is a string compare; consolidating cuts
            # ~12 string compares per entity per frame.
            is_player = self.char_type == "Player"
            is_skeleton = self.char_type == "Skeleton"
            rect_y = self.rect.y

            # ----------------------------------------------------------------
            # BEHIND-SPRITE EFFECTS (drawn first so the sprite covers them)
            # ----------------------------------------------------------------
            if is_player:
                if self.cheat_mode:
                    self._draw_godmode_tracers(surface, screen_x, img)
                    self._draw_godmode_glow(surface, screen_x, img)
                    if self.covenant_fx_timer > 0:
                        self._draw_covenant_descent(surface, screen_x, img)

                if self.speed_boost_timer > 0:
                    self._draw_speed_aura(surface, screen_x, img)

                if self.double_dmg_timer > 0:
                    self._draw_strength_aura(surface, screen_x, img)

                if self.shield_timer > 0:
                    self._draw_shield_aura(surface, screen_x, img)

                if self.fury_timer > 0:
                    self._draw_fury_aura(surface, screen_x, img)

                if self.ethereal_glow_timer > 0:
                    self._draw_ethereal_descent(surface, screen_x, img)

                # OPT: was called twice in the original (literally back-to-back
                # `if self.char_type == "Player": self._draw_shrine_sigils(...)`
                # blocks). The duplicate just re-blitted the same orbs, costing
                # a full set of sigil draws every frame for nothing.
                self._draw_shrine_sigils(surface, screen_x, img, layer="back")

            # ----------------------------------------------------------------
            # ENTITY SPRITE
            # ----------------------------------------------------------------
            surface.blit(img, (screen_x, rect_y))

            # ----------------------------------------------------------------
            # ON-TOP-OF-SPRITE EFFECTS
            # ----------------------------------------------------------------
            if is_skeleton:
                # OPT: was called twice (once before sprite blit, once after)
                # which doubled the silhouette alpha and visibly oversaturated
                # tier colors. Keep only the on-top call as the comment in the
                # original code intended ("Colored enemy overlay ON TOP of the
                # sprite").
                self._draw_enemy_color_overlay(surface, screen_x, img)
                if self.is_boss or self.is_final_boss:
                    self._draw_boss_flame_core(surface, screen_x, img)

            if is_player:
                if self.cheat_mode:
                    self._draw_godmode_core(surface, screen_x, img)

                if self.ethereal_glow_timer > 0:
                    self._draw_ethereal_absorb_core(surface, screen_x, img)

                if self.shield_timer > 0:
                    self._draw_shield_core(surface, screen_x, img)

                if self.double_dmg_timer > 0:
                    self._draw_strength_core(surface, screen_x, img)

                if self.invuln_timer > 0:
                    self._draw_damage_flash(surface, screen_x, img)

                self._draw_shrine_sigils(surface, screen_x, img, layer="front")
                self._draw_player_cooldown(surface, scroll_offset)

            # ----------------------------------------------------------------
            # BOSS CROWNS
            # ----------------------------------------------------------------
            if is_skeleton:
                if (self.is_boss and not self.is_final_boss
                        and self.boss_variant is not None):
                    name, aura_color, secondary_color, crown_style = BOSS_VARIANTS[self.boss_variant]
                    draw_boss_crown(
                        surface,
                        screen_x,
                        rect_y,
                        img.get_width(),
                        crown_style,
                        aura_color,
                        time_offset=self.boss_variant * 0.7
                    )
                elif self.is_final_boss:
                    draw_final_boss_crown(surface, screen_x, rect_y, img.get_width())

        elif self.respawn_timer < 250:
            self.respawn_timer += 1
            rest_y = self.anchor_y - img.get_height()
            surface.blit(img, (screen_x, rest_y))

    def _draw_player_cooldown(self, surface, scroll_offset):
        if self.char_type != "Player" or self.attack_cooldown <= 0 or self.attack_cooldown_max <= 0:
            return
        ratio = max(0, min(1, self.attack_cooldown / self.attack_cooldown_max))
        bar_w = self.cooldown_bar_w
        bar_x = int(self.anchor_x - scroll_offset - bar_w // 2)
        bar_y = int(self.anchor_y - self.body_visual_h - 10)
        # No box. Fixed width and fixed anchor-based position, so it no longer
        # grows/shrinks or jitters when the sprite frame changes.
        pygame.draw.line(surface, (70, 70, 80), (bar_x, bar_y), (bar_x + bar_w, bar_y), 2)
        pygame.draw.line(surface, (180, 210, 255), (bar_x, bar_y),
                         (bar_x + int(bar_w * ratio), bar_y), 2)

    # OPT: pre-baked offset list reused by every mask-based aura effect, so it
    # isn't reallocated 60+ times per second. Order kept identical to original.
    _AURA_OFFSETS = ((-2, 0), (2, 0), (0, -2), (0, 2),
                     (-1, -1), (1, -1), (-1, 1), (1, 1))
    _BUFF_OFFSETS = ((-2, 0), (2, 0), (0, -2), (0, 2),
                     (-2, -1), (2, -1), (-1, 2), (1, 2))

    def _draw_shield_aura(self, surface, screen_x, img):
        # Same role as _draw_strength_aura: drawn BEHIND the player.
        glow = _get_silhouette(img, (80, 180, 255, 10))
        rect_y = self.rect.y

        for ox, oy in self._BUFF_OFFSETS:
            surface.blit(
                glow,
                (screen_x + ox, rect_y + oy),
                special_flags=pygame.BLEND_RGBA_ADD
            )

    def _draw_shield_core(self, surface, screen_x, img):
        if self.cheat_mode:
            return
        # Same role as _draw_strength_core: only one light tint ON TOP.
        core = _get_silhouette(img, (120, 210, 255, 14))

        surface.blit(
            core,
            (screen_x, self.rect.y),
            special_flags=pygame.BLEND_RGBA_ADD
        )        
    def _draw_godmode_tracers(self, surface, screen_x, img):
        trail_dir = -self.direction
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2
        t = _ticks() * 0.02

        if self.running:
            # Same body tracer style as speed boost, but golden.
            for i in range(4):
                line_len = 10 + i * 6
                line_x = cx + trail_dir * (12 + i * 8)
                line_y = cy - 10 + i * 7 + math.sin(t + i * 0.8) * 2

                pygame.draw.line(
                    surface,
                    (235, 210, 110),
                    (line_x, line_y),
                    (line_x + trail_dir * line_len, line_y),
                    2
                )

                pygame.draw.line(
                    surface,
                    (255, 245, 180),
                    (line_x, line_y - 1),
                    (line_x + trail_dir * max(4, line_len - 4), line_y - 1),
                    1
                )

            # Exact same foot-tracer shape as speed boost:
            # 2 short streaks, same position, same length.
            foot_y = self.rect.y + img.get_height() - 6
            for i in range(2):
                streak_x = cx + trail_dir * (8 + i * 10)
                streak_y = foot_y + i * 2

                pygame.draw.line(
                    surface,
                    (245, 220, 120),
                    (streak_x, streak_y),
                    (streak_x + trail_dir * (8 + i * 4), streak_y),
                    2
                )

        else:
            # Idle state: same as speed boost idle sparks, but golden.
            foot_y = self.rect.y + img.get_height() - 6

            for i in range(2):
                spark_x = cx + math.cos(t * 0.7 + i * math.pi) * 6
                spark = _get_two_circle_glow(
                    (240, 215, 120, 55),
                    (255, 245, 180, 110),
                    3,
                    1,
                    surf_w=10,
                )
                surface.blit(
                    spark,
                    (spark_x - 5, foot_y - 5),
                    special_flags=pygame.BLEND_RGBA_ADD
                )
                
    def _draw_godmode_glow(self, surface, screen_x, img):
        # Same role as strength aura: drawn BEHIND the player.
        glow = _get_silhouette(img, (235, 205, 110, 8))
        rect_y = self.rect.y

        for ox, oy in self._BUFF_OFFSETS:
            surface.blit(
                glow,
                (screen_x + ox, rect_y + oy),
                special_flags=pygame.BLEND_RGBA_ADD
            )

    def _draw_godmode_core(self, surface, screen_x, img):
        # Same role as strength core: one subtle tint ON TOP.
        core = _get_silhouette(img, (255, 235, 150, 10))

        surface.blit(
            core,
            (screen_x, self.rect.y),
            special_flags=pygame.BLEND_RGBA_ADD
        )        

    def _get_boss_fx_colors(self):
        if self.is_final_boss:
            return (255, 86, 28), (255, 205, 95)

        if self.boss_variant is not None and self.boss_variant < len(BOSS_VARIANTS):
            _, primary, secondary, _ = BOSS_VARIANTS[self.boss_variant]
            return primary, secondary

        return GOLD, (255, 120, 60)


    def _draw_boss_flame_aura(self, surface, screen_x, img):
        if self.char_type != "Skeleton" or not self.alive:
            return
        if not (self.is_boss or self.is_final_boss):
            return

        primary, secondary = self._get_boss_fx_colors()
        rect_y = self.rect.y
        t = _ticks() * (0.008 if self.is_final_boss else 0.006)

        # Low-alpha sprite-shaped aura. This keeps the sprite readable.
        pulse = 0.65 + 0.35 * math.sin(t * 2.0 + self.tier)
        base_alpha = 6 if self.is_final_boss else 5
        aura_alpha = int(base_alpha + (5 if self.is_final_boss else 3) * pulse)

        aura = _get_silhouette(img, (primary[0], primary[1], primary[2], aura_alpha))

        spread = 4 if self.is_final_boss else 3
        aura_offsets = (
            (-spread, 0), (spread, 0), (0, -spread), (0, spread),
            (-spread, -spread), (spread, -spread),
            (-spread, spread), (spread, spread),
            (-spread * 2, 0), (spread * 2, 0),
        )

        for ox, oy in aura_offsets:
            surface.blit(
                aura,
                (screen_x + ox, rect_y + oy),
                special_flags=pygame.BLEND_RGBA_ADD
            )

        # Very light secondary aura, still transparent.
        shadow = _get_silhouette(img, (secondary[0], secondary[1], secondary[2], 2))
        for ox, oy in ((-2, -1), (2, -1), (-1, 2), (1, 2)):
            surface.blit(
                shadow,
                (screen_x + ox, rect_y + oy),
                special_flags=pygame.BLEND_RGBA_ADD
            )

        # Back-half flame wisps.
        cx = screen_x + img.get_width() // 2
        chest_y = rect_y + int(img.get_height() * 0.46)
        radius_x = max(18, img.get_width() * (0.58 if self.is_final_boss else 0.50))
        radius_y = max(18, img.get_height() * (0.38 if self.is_final_boss else 0.33))
        flame_count = 9 if self.is_final_boss else 6

        for i in range(flame_count):
            angle = t + i * math.tau / flame_count + self.tier * 0.35

            # Back flames only here. Front flames are drawn after the sprite.
            if math.sin(angle) > 0.10:
                continue

            wobble = math.sin(t * 1.7 + i) * 4
            flame_x = cx + math.cos(angle) * (radius_x + wobble)
            flame_y = chest_y + math.sin(angle * 1.22) * radius_y - 6
            size = 3 + (i % 3) + (1 if self.is_final_boss else 0)
            alpha = 55 + int(30 * (0.5 + 0.5 * math.sin(t * 2.3 + i)))

            flame = _get_two_circle_glow(
                (primary[0], max(0, primary[1] - 20), primary[2], alpha),
                (255, 220, 120, min(235, alpha + 70)),
                size * 2,
                size,
                surf_w=size * 6,
            )

            surface.blit(
                flame,
                (flame_x - size * 3, flame_y - size * 3),
                special_flags=pygame.BLEND_RGBA_ADD
            )


    def _draw_boss_flame_core(self, surface, screen_x, img):
        if self.char_type != "Skeleton" or not self.alive:
            return
        if not (self.is_boss or self.is_final_boss):
            return

        primary, secondary = self._get_boss_fx_colors()
        rect_y = self.rect.y
        t = _ticks() * (0.009 if self.is_final_boss else 0.007)

        # Low alpha so the sprite stays visible.
        pulse = 0.60 + 0.40 * math.sin(t * 1.8 + self.tier)
        core_alpha = int((7 if self.is_final_boss else 5) + (5 if self.is_final_boss else 3) * pulse)

        core = _get_silhouette(img, (primary[0], primary[1], primary[2], core_alpha))
        surface.blit(core, (screen_x, rect_y), special_flags=pygame.BLEND_RGBA_ADD)

        hot_core = _get_silhouette(img, (secondary[0], secondary[1], secondary[2], 2))
        surface.blit(hot_core, (screen_x, rect_y), special_flags=pygame.BLEND_RGBA_ADD)

        # Front-half flame wisps.
        cx = screen_x + img.get_width() // 2
        chest_y = rect_y + int(img.get_height() * 0.46)
        radius_x = max(18, img.get_width() * (0.58 if self.is_final_boss else 0.50))
        radius_y = max(18, img.get_height() * (0.38 if self.is_final_boss else 0.33))
        flame_count = 9 if self.is_final_boss else 6

        for i in range(flame_count):
            angle = t + i * math.tau / flame_count + self.tier * 0.35

            if math.sin(angle) <= 0.10:
                continue

            wobble = math.sin(t * 1.7 + i) * 4
            flame_x = cx + math.cos(angle) * (radius_x + wobble)
            flame_y = chest_y + math.sin(angle * 1.22) * radius_y - 6
            size = 3 + (i % 3) + (1 if self.is_final_boss else 0)
            alpha = 60 + int(35 * (0.5 + 0.5 * math.sin(t * 2.4 + i)))

            flame = _get_two_circle_glow(
                (primary[0], max(0, primary[1] - 20), primary[2], alpha),
                (255, 225, 135, min(240, alpha + 75)),
                size * 2,
                size,
                surf_w=size * 6,
            )

            surface.blit(
                flame,
                (flame_x - size * 3, flame_y - size * 3),
                special_flags=pygame.BLEND_RGBA_ADD
            )

        # Small chest glow, not a big circle.
        pulse_size = 3 + int(2 * pulse) + (1 if self.is_final_boss else 0)

        chest = _get_two_circle_glow(
            (primary[0], primary[1], primary[2], 45),
            (255, 230, 150, 95),
            pulse_size * 2,
            pulse_size,
            surf_w=pulse_size * 6,
        )

        surface.blit(
            chest,
            (cx - chest.get_width() // 2, chest_y - chest.get_height() // 2),
            special_flags=pygame.BLEND_RGBA_ADD
        )
    def _draw_covenant_descent(self, surface, screen_x, img):
        progress = 1.0 - max(0, self.covenant_fx_timer) / 180.0
        ticks = _ticks()
        t = ticks * 0.01
        cx = screen_x + img.get_width() // 2

        # Full-screen golden ascension pillar
        # Golden ascension pillar: starts at top of screen, ends at player's feet
        top_y = 0
        feet_y = self.rect.bottom - 6
        beam_h = max(1, int(feet_y - top_y))
        beam_w = max(img.get_width() + 100, 120)

        beam = _get_scratch_alpha_surface(beam_w, beam_h)
        mid = beam_w // 2

        # Soft golden beam with bright center
        for x in range(0, beam_w, 3):
            dist = abs(x - mid) / max(1, mid)
            falloff = max(0.0, 1.0 - dist)
            shimmer = 0.5 + 0.5 * math.sin(t + x * 0.11)
            alpha = int(12 + 72 * (falloff ** 1.8) + 18 * shimmer * falloff)
            color = (255, 225 + int(25 * shimmer), 135, max(0, min(120, alpha)))
            pygame.draw.line(beam, color, (x, 0), (x, beam_h), 2)

        # Bright vertical streaks
        for i in range(10):
            ox = int(mid + math.sin(t * 0.45 + i * 1.7) * beam_w * 0.36)
            alpha = 42 + int(28 * math.sin(t + i))
            pygame.draw.line(
                beam,
                (255, 250, 205, max(20, alpha)),
                (ox, 0),
                (ox, beam_h),
                1
            )

        # Falling golden ichor
        for i in range(12):
            lane = 0.08 + i * 0.084
            drip_x = int(lane * beam_w + math.sin(t * 0.55 + i) * 5)
            speed_offset = (i * 37 + int(progress * (beam_h + 150))) % (beam_h + 150)
            drip_y = speed_offset - 90
            length = 20 + (i % 4) * 8

            pygame.draw.line(
                beam,
                (255, 205 + (i % 3) * 12, 80, 145),
                (drip_x, max(0, drip_y - length)),
                (drip_x, min(beam_h, drip_y)),
                2 + (i % 2)
            )

            if 0 <= drip_y < beam_h:
                pygame.draw.circle(
                    beam,
                    (255, 244, 170, 210),
                    (drip_x, drip_y),
                    3 + (i % 2)
                )

        # Rising divine sparks
        for i in range(20):
            mote_x = int(mid + math.sin(t * 0.7 + i * 2.1) * beam_w * (0.12 + (i % 5) * 0.045))
            mote_y = int(beam_h - ((progress * 260 + i * 53 + ticks * 0.035) % (beam_h + 80)))
            mote_size = 1 + (i % 3)
            pygame.draw.circle(
                beam,
                (255, 255, 215, 100 + (i % 4) * 25),
                (mote_x, mote_y),
                mote_size
            )

        # Glowing opening at top of screen
        pygame.draw.ellipse(
            beam,
            (255, 250, 200, 70),
            (mid - beam_w // 3, -18, beam_w * 2 // 3, 42)
        )
        pygame.draw.ellipse(
            beam,
            (255, 255, 235, 115),
            (mid - beam_w // 5, -10, beam_w * 2 // 5, 24)
        )

        surface.blit(
            beam,
            (cx - beam_w // 2, top_y),
            special_flags=pygame.BLEND_RGBA_ADD
        )


        for r_i, base_r in enumerate((34, 50, 68)):
            wobble = int(math.sin(t * 0.7 + r_i) * 4)
            rect = pygame.Rect(
                0,
                0,
                (base_r + wobble) * 2,
                int((base_r + wobble) * 0.62)
            )
            rect.center = (int(cx), int(feet_y - r_i * 5))
            pygame.draw.ellipse(
                surface,
                (255, 218, 100, 52 - r_i * 10),
                rect,
                2
            )

        for i in range(9):
            ang = t * 0.45 + i * math.tau / 9
            rx = cx + math.cos(ang) * 54
            ry = feet_y - 8 + math.sin(ang) * 16
            pygame.draw.circle(surface, (255, 240, 165), (int(rx), int(ry)), 2)
            pygame.draw.circle(surface, (255, 190, 70), (int(rx), int(ry)), 4, 1)

    def _draw_strength_aura(self, surface, screen_x, img):
        # OPT: silhouette cached.
        glow = _get_silhouette(img, (255, 110, 70, 10))
        rect_y = self.rect.y
        for ox, oy in self._BUFF_OFFSETS:
            surface.blit(glow, (screen_x + ox, rect_y + oy), special_flags=pygame.BLEND_RGBA_ADD)

        cx = screen_x + img.get_width() // 2 + self.direction * int(img.get_width() * 0.30)
        cy = rect_y + int(img.get_height() * 0.62)
        t = _ticks() * 0.01
        # OPT: ember glows are cached by (color, size). Inner radius = size for
        # size=2 and =3 in original; pattern preserved.
        for i in range(4):
            ang = t + i * 1.55
            ember_x = cx + math.cos(ang) * 6 + self.direction * 3
            ember_y = cy + math.sin(ang * 1.4) * 8
            size = 2 + (i % 2)
            # OPT: cached. Original: Surface(size*6,size*6) outer r=size*2 inner r=size.
            ember = _get_two_circle_glow(
                (255, 90, 50, 90), (255, 205, 120, 180),
                size * 2, size, surf_w=size * 6,
            )
            surface.blit(ember, (ember_x - size * 3, ember_y - size * 3),
                         special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_strength_core(self, surface, screen_x, img):
        if self.cheat_mode or self.shield_timer > 0:
            return
        core = _get_silhouette(img, (255, 165, 95, 14))
        surface.blit(core, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_speed_aura(self, surface, screen_x, img):
        trail_dir = -self.direction
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2
        t = _ticks() * 0.02

        if self.running:
            # Clean speed lines behind the player instead of a full-body glow.
            for i in range(4):
                line_len = 10 + i * 6
                line_x = cx + trail_dir * (12 + i * 8)
                line_y = cy - 10 + i * 7 + math.sin(t + i * 0.8) * 2

                pygame.draw.line(
                    surface,
                    (90, 220, 240),
                    (line_x, line_y),
                    (line_x + trail_dir * line_len, line_y),
                    2
                )

                pygame.draw.line(
                    surface,
                    (200, 250, 255),
                    (line_x, line_y - 1),
                    (line_x + trail_dir * max(4, line_len - 4), line_y - 1),
                    1
                )

            # Small foot streaks so the buff still reads as active when moving.
            foot_y = self.rect.y + img.get_height() - 6
            for i in range(2):
                streak_x = cx + trail_dir * (8 + i * 10)
                streak_y = foot_y + i * 2

                pygame.draw.line(
                    surface,
                    (120, 235, 255),
                    (streak_x, streak_y),
                    (streak_x + trail_dir * (8 + i * 4), streak_y),
                    2
                )

        else:
            # Idle state: tiny hint near the feet, not a shield-like body glow.
            foot_y = self.rect.y + img.get_height() - 6

            for i in range(2):
                spark_x = cx + math.cos(t * 0.7 + i * math.pi) * 6
                # OPT: cached. Original: Surface(10,10) outer r=3 inner r=1.
                spark = _get_two_circle_glow(
                    (120, 235, 255, 55), (220, 250, 255, 110), 3, 1, surf_w=10,
                )
                surface.blit(
                    spark,
                    (spark_x - 5, foot_y - 5),
                    special_flags=pygame.BLEND_RGBA_ADD
                )
    def _draw_damage_flash(self, surface, screen_x, img):
        """Red damage flash that follows only the visible sprite pixels.
        This avoids the ugly red square/box that happens when tinting the
        whole transparent sprite surface.
        """
        if self.invuln_timer <= 0:
            return

        alpha = 70 if (self.invuln_timer // 4) % 2 == 0 else 35
        # OPT: cached. There are only two distinct alphas (70 and 35) so the
        # cache holds at most 2 entries per animation frame.
        flash = _get_silhouette(img, (255, 65, 55, alpha))
        surface.blit(flash, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_fury_aura(self, surface, screen_x, img):
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + img.get_height() // 2
        t = _ticks() * 0.006
        for i in range(3):
            angle = t + i * 2.1
            wisp_x = cx + math.cos(angle) * (img.get_width() // 2 + 4)
            wisp_y = cy + math.sin(angle * 1.3) * (img.get_height() // 3) - 4
            size = 4 + int(math.sin(t * 2 + i) * 2)
            # OPT: cached. Original: Surface(size*4,size*4), outer r=size, inner r=max(1,size//2).
            inner_r = max(1, size // 2)
            s = _get_two_circle_glow(
                (255, 80, 30, 120), (255, 200, 80, 200),
                size, inner_r, surf_w=size * 4,
            )
            surface.blit(s, (wisp_x - size * 2, wisp_y - size * 2), special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_ethereal_descent(self, surface, screen_x, img):
        """Shrine activation aura drawn behind the player.

        Uses sprite-shaped silhouettes instead of a plain circle/ellipse.
        Wisps begin outside the sprite and get pulled inward toward the chest,
        making the shrine power look absorbed into the body.
        """
        if self.ethereal_glow_timer <= 0:
            return

        max_t = 120
        progress = max(0, min(1, 1.0 - self.ethereal_glow_timer / max_t))

        cx = screen_x + img.get_width() // 2
        rect_y = self.rect.y
        body_cy = rect_y + img.get_height() // 2
        chest_y = rect_y + int(img.get_height() * 0.42)
        ticks = _ticks()
        t = ticks * 0.012

        # Fade in, hold, fade out. Duration stays exactly the same.
        if progress < 0.18:
            aura_power = progress / 0.18
        elif progress > 0.82:
            aura_power = 1.0 - ((progress - 0.82) / 0.18)
        else:
            aura_power = 1.0

        aura_power = max(0.0, min(1.0, aura_power))

        # Sprite-shaped aura behind the player. The offset spread shrinks over
        # time, so the glow looks like it is getting pulled into the body.
        absorb_t = max(0.0, min(1.0, (progress - 0.18) / 0.64))
        spread = max(1, int(5 - 4 * absorb_t))

        glow_alpha = int(3 + 10 * aura_power)
        glow = _get_silhouette(img, (255, 76, 48, glow_alpha))

        absorb_offsets = (
            (-spread, 0), (spread, 0), (0, -spread), (0, spread),
            (-spread, -spread), (spread, -spread),
            (-spread, spread), (spread, spread),
        )

        for ox, oy in absorb_offsets:
            surface.blit(
                glow,
                (screen_x + ox, rect_y + oy),
                special_flags=pygame.BLEND_RGBA_ADD
            )

        # Early phase: shrine light drops from above, but as small wisps rather
        # than one big orb/circle.
        if progress < 0.35:
            descent_t = progress / 0.35
            target_y = chest_y
            start_y = rect_y - 86
            stream_y = start_y + (target_y - start_y) * descent_t

            for i in range(7):
                trail_y = stream_y - i * 7
                wobble_x = math.sin(t * 1.4 + i * 0.9) * (8 - min(i, 6))
                alpha = max(0, int(150 * (1 - i / 8) * (0.35 + descent_t)))
                size = max(2, 7 - i)

                wisp = _get_two_circle_glow(
                    (255, 70, 40, alpha),
                    (255, 190, 110, min(210, alpha + 55)),
                    size * 2,
                    size,
                    surf_w=size * 4,
                )

                surface.blit(
                    wisp,
                    (cx + wobble_x - size * 2, trail_y - size * 2),
                    special_flags=pygame.BLEND_RGBA_ADD
                )

        # Middle/final phase: wisps orbit close to the sprite, then collapse
        # inward toward the chest.
        pull_t = max(0.0, min(1.0, (progress - 0.22) / 0.68))
        radius_x = max(4, img.get_width() * (0.72 - 0.62 * pull_t))
        radius_y = max(3, img.get_height() * (0.46 - 0.39 * pull_t))

        # Strongest in the middle, fades near the end.
        wisp_power = math.sin(max(0.0, min(1.0, progress)) * math.pi)
        wisp_alpha = int(55 + 120 * wisp_power * aura_power)

        for i in range(8):
            angle = t + i * math.tau / 8 + progress * 4.0

            # As pull_t rises, the wisps collapse toward the chest.
            wisp_x = cx + math.cos(angle) * radius_x
            wisp_y = chest_y + math.sin(angle * 1.35) * radius_y

            # Slight trail point halfway between wisp and chest, making the
            # motion read like energy being drawn inward.
            trail_x = (wisp_x + cx) * 0.5
            trail_y = (wisp_y + chest_y) * 0.5

            size = 3 + (i % 2)

            trail = _get_two_circle_glow(
                (255, 65, 45, max(0, wisp_alpha // 2)),
                (255, 170, 100, max(0, wisp_alpha)),
                size,
                max(1, size // 2),
                surf_w=size * 4,
            )

            core = _get_two_circle_glow(
                (255, 70, 45, max(0, wisp_alpha)),
                (255, 210, 130, min(230, wisp_alpha + 50)),
                size * 2,
                size,
                surf_w=size * 5,
            )

            surface.blit(
                trail,
                (trail_x - size * 2, trail_y - size * 2),
                special_flags=pygame.BLEND_RGBA_ADD
            )

            surface.blit(
                core,
                (wisp_x - size * 2, wisp_y - size * 2),
                special_flags=pygame.BLEND_RGBA_ADD
            )
    def _draw_ethereal_absorb_core(self, surface, screen_x, img):
        """Transparent on-sprite core for shrine activation.

        This is drawn after the sprite, so the activation reads as power being
        absorbed into the character instead of sitting behind them as a circle.
        """
        if self.ethereal_glow_timer <= 0:
            return

        max_t = 120
        progress = max(0, min(1, 1.0 - self.ethereal_glow_timer / max_t))

        cx = screen_x + img.get_width() // 2
        chest_y = self.rect.y + int(img.get_height() * 0.42)

        if progress < 0.20:
            core_power = progress / 0.20
        elif progress > 0.86:
            core_power = 1.0 - ((progress - 0.86) / 0.14)
        else:
            core_power = 1.0

        core_power = max(0.0, min(1.0, core_power))

        # Soft sprite-shaped core. Keep alpha low so the actual knight sprite
        # remains visible underneath.
        pulse = 0.75 + 0.25 * math.sin(_ticks() * 0.025)
        core_alpha = int((6 + 10 * pulse) * core_power)

        core = _get_silhouette(img, (255, 125, 74, core_alpha))
        surface.blit(core, (screen_x, self.rect.y), special_flags=pygame.BLEND_RGBA_ADD)

        # Tiny chest absorption pulse. This is intentionally small, not a big
        # background circle.
        pulse_size = 3 + int(3 * math.sin(progress * math.pi))
        pulse_alpha = int(105 * core_power)

        chest = _get_two_circle_glow(
            (255, 82, 48, pulse_alpha),
            (255, 225, 145, min(230, pulse_alpha + 80)),
            pulse_size * 2,
            pulse_size,
            surf_w=pulse_size * 5,
        )

        surface.blit(
            chest,
            (cx - chest.get_width() // 2, chest_y - chest.get_height() // 2),
            special_flags=pygame.BLEND_RGBA_ADD
        )
        
    def _draw_shrine_sigils(self, surface, screen_x, img, layer="front"):
        if self.shrines_cleared <= 0:
            return

        orb_count = self.shrines_cleared

        # center of the orbit around upper torso / chest
        cx = screen_x + img.get_width() // 2
        cy = self.rect.y + int(img.get_height() * 0.38)

        # ellipse size
        radius_x = max(20, int(img.get_width() * 0.55))
        radius_y = max(16, int(img.get_height() * 0.3))

        t = _ticks() * 0.0045

        orbiters = []
        for i in range(orb_count):
            angle = t + (i * math.tau / orb_count)

            sx = cx + math.cos(angle) * radius_x
            sy = cy + math.sin(angle) * radius_y

            # lower half of the ellipse = front
            # upper half = back
            in_front = math.sin(angle) > 0

            if layer == "front" and not in_front:
                continue
            if layer == "back" and in_front:
                continue

            # make back orbs a little smaller/dimmer
            if in_front:
                size = 5
                glow_alpha = 80
            else:
                size = 4
                glow_alpha = 45

            orbiters.append((sx, sy, size, glow_alpha))

        for sx, sy, size, glow_alpha in orbiters:
            # OPT: cached. Original: Surface(size*4,size*4), outer r=size*2, inner r=size+1.
            glow = _get_two_circle_glow(
                (255, 70, 50, glow_alpha), (255, 140, 110, glow_alpha // 2),
                size * 2, size + 1, surf_w=size * 4,
            )
            surface.blit(glow, (sx - size * 2, sy - size * 2), special_flags=pygame.BLEND_RGBA_ADD)

            isx, isy = int(sx), int(sy)
            pygame.draw.circle(surface, (245, 120, 100), (isx, isy), size)
            pygame.draw.circle(surface, (255, 175, 150), (isx, isy), max(2, size - 2))
            pygame.draw.line(surface, (170, 35, 30), (isx, isy - size + 1), (isx, isy + size - 1), 1)
            pygame.draw.line(surface, (170, 35, 30), (isx - size + 1, isy), (isx + size - 1, isy), 1)
            pygame.draw.circle(surface, (255, 225, 200), (isx, isy), 1)

CHEST_BODY = (110, 70, 35)
CHEST_LID = (75, 45, 20)
CHEST_BAND = (50, 30, 15)
CHEST_GOLD = (255, 200, 60)
CHEST_HIGHLIGHT = (160, 110, 60)


class TreasureChest:
    def __init__(self, x, y, guarded=False):
        self.world_x = x
        self.y = y
        self.width = 52
        self.height = 40
        self.rect = pygame.Rect(self.world_x, self.y - self.height, self.width, self.height)
        self.opened = False
        self.collected = False
        self.open_timer = 0
        self.display_timer = 90
        self.reward_text = ""
        self.reward_color = GREEN
        self.guarded = guarded
        self.guard_alive = guarded
        self._closed = self._build_closed()
        self._open = self._build_open()

    def _build_closed(self):
        surf = pygame.Surface((self.width + 4, self.height + 4), pygame.SRCALPHA)
        w, h = self.width, self.height
        ox, oy = 2, 2
        pygame.draw.rect(surf, CHEST_BODY, (ox, oy, w, h), border_radius=5)
        pygame.draw.rect(surf, CHEST_LID, (ox, oy, w, h // 2), border_radius=5)
        for gx in range(ox + 6, ox + w - 6, 8):
            pygame.draw.line(surf, CHEST_HIGHLIGHT, (gx, oy + h // 2 + 2), (gx, oy + h - 4), 1)
        pygame.draw.rect(surf, CHEST_BAND, (ox, oy + h // 2 - 2, w, 4))
        for cx, cy in [(ox + 4, oy + 4), (ox + w - 6, oy + 4), (ox + 4, oy + h - 6), (ox + w - 6, oy + h - 6)]:
            pygame.draw.circle(surf, CHEST_GOLD, (cx, cy), 2)
        lx, ly = ox + w // 2, oy + h // 2
        pygame.draw.rect(surf, CHEST_GOLD, (lx - 5, ly - 4, 10, 10), border_radius=2)
        pygame.draw.rect(surf, CHEST_BAND, (lx - 5, ly - 4, 10, 10), 1, border_radius=2)
        pygame.draw.circle(surf, CHEST_BAND, (lx, ly + 1), 2)
        pygame.draw.rect(surf, CHEST_BAND, (ox, oy, w, h), 2, border_radius=5)
        return surf.convert_alpha()

    def _build_open(self):
        surf = pygame.Surface((self.width + 4, self.height + 16), pygame.SRCALPHA)
        w, h = self.width, self.height
        ox, oy = 2, 14
        glow = pygame.Surface((w, h // 2 + 4), pygame.SRCALPHA)
        for r in range(6):
            pygame.draw.ellipse(glow, (255, 220, 100, max(0, 25 - r * 4)),
                                (r * 2, r * 2, w - r * 4, h // 2 + 4 - r * 4))
        surf.blit(glow, (ox, oy + 4))
        pygame.draw.rect(surf, CHEST_BODY, (ox, oy + h // 3, w, h * 2 // 3), border_radius=4)
        pygame.draw.rect(surf, CHEST_BAND, (ox, oy + h // 3, w, h * 2 // 3), 2, border_radius=4)
        lid_pts = [(ox + 2, oy + h // 3), (ox + w - 2, oy + h // 3), (ox + w - 4, oy - 12), (ox + 4, oy - 12)]
        pygame.draw.polygon(surf, CHEST_LID, lid_pts)
        pygame.draw.polygon(surf, CHEST_BAND, lid_pts, 2)
        for px, py in [(ox + 12, oy + h // 3), (ox + 24, oy + h // 3 - 2), (ox + 36, oy + h // 3)]:
            pygame.draw.circle(surf, CHEST_GOLD, (px, py), 4)
        return surf.convert_alpha()

    def can_open(self, lucky_skeleton=None):
        if not self.guarded:
            return True
        if lucky_skeleton is None or not lucky_skeleton.alive:
            self.guard_alive = False
            return True
        return False

    def check_collect(self, player, particles, powerups, lucky_skeleton=None):
        if self.opened or not self.rect.colliderect(player.rect):
            return
        if not self.can_open(lucky_skeleton):
            return
        self.opened = True
        # Chests only give health or power-ups now. No score/coin rewards.
        # Health is slightly more common so a rare chest usually feels useful.
        roll = "powerup" if self.guarded else random.choices(
            ["heal", "powerup"],
            weights=[70, 30],
            k=1
        )[0]

        if roll == "heal":
            heal = random.randint(20, 45)
            player.health = min(player.max_health, player.health + heal)
            self.reward_text = f"+{heal} HP"
            self.reward_color = (80, 230, 100)
            for _ in range(5):
                particles.append(Particle(self.world_x + self.width // 2, self.rect.y, "heart"))
        else:
            kind = random.choice(["speed", "damage", "shield"])
            powerups.append(PowerUp(self.world_x + self.width // 2, self.rect.y - 10, kind))
            self.reward_text = "POWER-UP!"
            self.reward_color = SHIELD_BLUE

    def update(self):
        if self.opened:
            self.open_timer += 1
            if self.open_timer > self.display_timer:
                self.collected = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        if sx < -self.width or sx > SCREEN_WIDTH + self.width:
            return
        if not self.opened:
            surface.blit(self._closed, (sx - 2, self.rect.y - 2))
        else:
            surface.blit(self._open, (sx - 2, self.rect.y - 14))
            if self.open_timer < self.display_timer:
                font = _get_font(18)
                float_offset = min(self.open_timer, 30)
                txt = _get_text_surf(font, self.reward_text, self.reward_color)
                outline = _get_text_surf(font, self.reward_text, BLACK)
                ox_pos = sx + self.width // 2 - txt.get_width() // 2
                oy_pos = self.rect.y - 30 - float_offset
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    surface.blit(outline, (ox_pos + dx, oy_pos + dy))
                surface.blit(txt, (ox_pos, oy_pos))


class DemonicTower:
    WIDTH = 90
    HEIGHT = 220

    _TEXT_OFFSETS = ((-1, 0), (1, 0), (0, -1), (0, 1), (2, 2))

    def __init__(self, world_x, ground_y, tier_index, is_final=False):
        self.world_x = world_x
        self.ground_y = ground_y
        self.tier_index = tier_index
        self.is_final = is_final
        self.rect = pygame.Rect(world_x - self.WIDTH // 2, ground_y - self.HEIGHT, self.WIDTH, self.HEIGHT)
        self.bound = True
        self.activating = False
        self.activated = False
        self.channel_progress = 0
        self.channel_max = 120

        # Precompute all decorative randomness once.
        # No random.Random(...) inside draw().
        rng = random.Random(world_x)

        eye_count = 24 if is_final else 16
        self.eye_positions = []

        for i in range(eye_count):
            ey = rng.randint(28, self.HEIGHT - 38)

            # Keeps eyes inside the obelisk shape:
            # narrow near the top, wider near the base.
            y_ratio = ey / self.HEIGHT
            half_w = int(9 + 27 * y_ratio)
            ex = rng.randint(-half_w, half_w)

            size = rng.choice((7, 8, 9, 10))
            if is_final and i % 4 == 0:
                size += 1

            delay = rng.uniform(0.0, 0.65)
            blood_len = rng.randint(10, 26) + (6 if is_final else 0)

            self.eye_positions.append((
                ex,
                ey,
                size,
                rng.uniform(0, math.tau),
                delay,
                blood_len
            ))

        self.crack_lines = []
        crack_count = 14 if is_final else 10

        for _ in range(crack_count):
            y = rng.randint(24, self.HEIGHT - 18)
            y_ratio = y / self.HEIGHT
            half_w = int(10 + 30 * y_ratio)
            x = rng.randint(-half_w, half_w)

            self.crack_lines.append((
                x,
                y,
                rng.randint(-7, 7),
                rng.randint(18, 48),
                rng.random()
            ))

        self.soul_wisps = []
        soul_count = 9 if is_final else 6

        for _ in range(soul_count):
            self.soul_wisps.append((
                rng.randint(-28, 28),
                rng.randint(42, self.HEIGHT - 45),
                rng.uniform(0, math.tau),
                rng.uniform(0.65, 1.25),
            ))

    def update(self, player, boss):
        if self.activated:
            return None

        if self.bound and (boss is None or not boss.alive):
            self.bound = False

        if not self.bound and not self.activated:
            touching = self.rect.colliderect(player.rect)

            if touching:
                self.activating = True
                self.channel_progress += 1

                if self.channel_progress >= self.channel_max:
                    self.activated = True
                    self.activating = False
                    return "activated"
            else:
                self.channel_progress = max(0, self.channel_progress - 2)
                self.activating = self.channel_progress > 0

        return None

    def _body_points(self, bx, by):
        base_w = self.WIDTH
        top_w = int(self.WIDTH * 0.46)

        return [
            (bx + 4, by + self.HEIGHT),
            (bx, by + self.HEIGHT - 30),
            (bx + 6, by + self.HEIGHT - 82),
            (bx, by + self.HEIGHT - 132),
            (bx + 8, by + 62),
            (bx + (base_w - top_w) // 2, by + 30),
            (bx + base_w // 2 - 7, by + 5),
            (bx + base_w // 2 + 3, by - 5),
            (bx + base_w // 2 + 15, by + 8),
            (bx + base_w - (base_w - top_w) // 2, by + 30),
            (bx + base_w - 6, by + 62),
            (bx + base_w + 2, by + 132),
            (bx + base_w - 4, by + self.HEIGHT - 82),
            (bx + base_w + 2, by + self.HEIGHT - 30),
            (bx + base_w - 6, by + self.HEIGHT),
        ]

    def _open_amount_for_eye(self, progress, delay, activated):
        if activated:
            return 1.0

        if progress <= delay:
            return 0.0

        return max(0.0, min(1.0, (progress - delay) / 0.35))

    def _draw_cached_aura(
        self,
        surface,
        cx,
        cy,
        radius,
        outer_rgba,
        inner_rgba=(0, 0, 0, 0),
        inner_r=0,
        blend=True
    ):
        aura = _get_two_circle_glow(
            outer_rgba,
            inner_rgba,
            radius,
            inner_r,
            surf_w=radius * 2
        )

        flags = pygame.BLEND_RGBA_ADD if blend else 0

        surface.blit(
            aura,
            (cx - radius, cy - radius),
            special_flags=flags
        )

    def _draw_aura(self, surface, sx, top_y, t, progress):
        cx = sx + self.WIDTH // 2
        cy = top_y + self.HEIGHT // 2

        # Fixed radii + small alpha buckets = cache-friendly glows.
        pulse_bucket = int((math.sin(t * 3.0) + 1) * 2)

        if self.activated:
            self._draw_cached_aura(
                surface,
                cx,
                cy,
                160,
                (255, 45, 18, 18 + pulse_bucket * 3)
            )

            self._draw_cached_aura(
                surface,
                cx,
                cy + 8,
                118,
                (150, 10, 8, 28 + pulse_bucket * 3)
            )

            self._draw_cached_aura(
                surface,
                cx,
                cy - 12,
                70,
                (255, 130, 45, 28 + pulse_bucket * 4),
                (255, 210, 110, 35),
                18
            )

        elif self.activating:
            alpha = int(10 + 28 * progress)

            self._draw_cached_aura(
                surface,
                cx,
                cy,
                125,
                (255, 120, 35, alpha)
            )

            self._draw_cached_aura(
                surface,
                cx,
                cy,
                78,
                (255, 210, 90, max(6, alpha // 2))
            )

        elif self.bound:
            # Dark sealed aura. Plain alpha blit feel, not too bright.
            self._draw_cached_aura(
                surface,
                cx,
                cy,
                68,
                (90, 30, 110, 42 + pulse_bucket * 2),
                blend=False
            )

    def _draw_souls(self, surface, sx, top_y, t, progress):
        cx = sx + self.WIDTH // 2

        soul_color = (140, 190, 255) if not self.activated else (255, 115, 55)
        alpha = 42 if not self.activated else 55

        for ox, oy, phase, speed in self.soul_wisps:
            drift = math.sin(t * speed + phase) * 5
            lift = 0

            if self.activated:
                lift = (math.sin(t * 1.6 + phase) + 1) * 16

            x = int(cx + ox + drift)
            y = int(top_y + oy - lift)

            glow = _get_two_circle_glow(
                (soul_color[0], soul_color[1], soul_color[2], alpha),
                (235, 245, 255, alpha + 30),
                5,
                2,
                surf_w=18,
            )

            surface.blit(
                glow,
                (x - 9, y - 9),
                special_flags=pygame.BLEND_RGBA_ADD
            )

            pygame.draw.line(
                surface,
                soul_color,
                (x, y + 3),
                (x + int(drift * 0.6), y + 13),
                1
            )

    def _draw_cracks(self, surface, bx, by, progress):
        activated = self.activated

        for x, y, dx, length, phase in self.crack_lines:
            sx = bx + self.WIDTH // 2 + x
            sy = by + y
            ex = sx + dx
            ey = sy + length

            pygame.draw.line(surface, (45, 12, 20), (sx, sy), (ex, ey), 2)

            if activated or progress > phase:
                pygame.draw.line(surface, (210, 42, 20), (sx, sy), (ex, ey), 1)

                if activated:
                    pygame.draw.circle(surface, (255, 120, 45), (sx, sy), 1)

    def _draw_eye(self, surface, eye_x, eye_y, size, seed, open_amt, t, blood_len):
        if open_amt <= 0:
            pygame.draw.line(
                surface,
                (72, 22, 34),
                (eye_x - size // 2, eye_y),
                (eye_x + size // 2, eye_y),
                2
            )

            pygame.draw.line(
                surface,
                (18, 5, 8),
                (eye_x - size // 2, eye_y + 1),
                (eye_x + size // 2, eye_y + 1),
                1
            )

            return

        eye_w = int(size + 4 * open_amt)
        eye_h = max(2, int(size * 0.35 + size * 0.70 * open_amt))
        eye_rect = (
            eye_x - eye_w // 2,
            eye_y - eye_h // 2,
            eye_w,
            eye_h
        )

        pygame.draw.ellipse(
            surface,
            (20, 3, 5),
            (eye_rect[0] - 1, eye_rect[1] - 1, eye_w + 2, eye_h + 2)
        )

        pygame.draw.ellipse(surface, (224, 205, 184), eye_rect)

        pdx = int(math.cos(t * 2.2 + seed) * 2)
        pdy = int(math.sin(t * 1.7 + seed) * 1)
        iris_r = max(2, int(2 + 2 * open_amt))

        pygame.draw.circle(surface, (185, 24, 18), (eye_x + pdx, eye_y + pdy), iris_r + 1)
        pygame.draw.circle(surface, BLACK, (eye_x + pdx, eye_y + pdy), iris_r)
        pygame.draw.circle(surface, WHITE, (eye_x + pdx - 1, eye_y + pdy - 1), 1)

        # Blood starts once the eye is mostly open.
        # Draw primitives only; no new surfaces.
        bleed = max(0.0, min(1.0, (open_amt - 0.55) / 0.45))

        if bleed > 0:
            wobble = 0.7 + 0.3 * math.sin(t * 3.0 + seed)
            drip_len = int(blood_len * bleed * wobble)

            if drip_len > 1:
                blood_x = eye_x + int(math.sin(seed) * max(1, eye_w // 4))
                start_y = eye_y + eye_h // 2 - 1

                pygame.draw.line(
                    surface,
                    (65, 0, 0),
                    (blood_x, start_y),
                    (blood_x + 1, start_y + drip_len),
                    3
                )

                pygame.draw.line(
                    surface,
                    BLOOD_RED,
                    (blood_x, start_y),
                    (blood_x, start_y + drip_len),
                    1
                )

                pygame.draw.circle(
                    surface,
                    BLOOD_RED,
                    (blood_x, start_y + drip_len),
                    2
                )

    def _draw_all_eyes(self, surface, bx, by, t, progress):
        activated = self.activated
        is_final = self.is_final

        for ex, ey, size, seed, delay, blood_len in self.eye_positions:
            # Only the final tower opens its full eye-swarm with bleeding.
            # Normal towers keep the small scattered eyes shut so the central
            # crown eye is the single focal point.
            if is_final:
                open_amt = self._open_amount_for_eye(progress, delay, activated)
            else:
                open_amt = 0.0

            self._draw_eye(
                surface,
                bx + self.WIDTH // 2 + ex,
                by + ey,
                size,
                seed,
                open_amt,
                t,
                blood_len
            )

        # Big crown eye near the top.
        main_open = 1.0 if activated else max(0.0, min(1.0, progress * 1.35))
        mex = bx + self.WIDTH // 2
        mey = by + 40

        if main_open <= 0:
            pygame.draw.line(surface, (95, 28, 38), (mex, mey - 13), (mex, mey + 13), 4)
        else:
            eye_w = int(20 + main_open * 12)
            eye_h = int(7 + main_open * 17)

            pygame.draw.ellipse(
                surface,
                (20, 3, 5),
                (mex - eye_w // 2 - 2, mey - eye_h // 2 - 2, eye_w + 4, eye_h + 4)
            )

            pygame.draw.ellipse(
                surface,
                (240, 220, 200),
                (mex - eye_w // 2, mey - eye_h // 2, eye_w, eye_h)
            )

            iris_r = int(4 + main_open * 5)

            pygame.draw.circle(surface, (200, 35, 18), (mex, mey), iris_r)
            pygame.draw.circle(surface, BLACK, (mex, mey), max(2, iris_r - 2))

            if activated:
                for ox in (-6, 5):
                    pygame.draw.line(
                        surface,
                        (65, 0, 0),
                        (mex + ox, mey + eye_h // 2),
                        (mex + ox, mey + eye_h // 2 + 30),
                        3
                    )

                    pygame.draw.line(
                        surface,
                        BLOOD_RED,
                        (mex + ox, mey + eye_h // 2),
                        (mex + ox, mey + eye_h // 2 + 30),
                        1
                    )

    def _draw_horns_and_maw(self, surface, bx, by):
        base_w = self.WIDTH

        for sign in (-1, 1):
            pygame.draw.polygon(surface, (10, 5, 8), [
                (bx + base_w // 2 + 8 * sign, by + 4),
                (bx + base_w // 2 + 24 * sign, by - 20),
                (bx + base_w // 2 + 14 * sign, by - 5),
            ])

            pygame.draw.line(
                surface,
                (90, 20, 16),
                (bx + base_w // 2 + 9 * sign, by + 3),
                (bx + base_w // 2 + 21 * sign, by - 15),
                1
            )

        mouth_y = by + self.HEIGHT - 58
        mouth_x = bx + base_w // 2

        if self.activated:
            maw_pts = [
                (mouth_x - 15, mouth_y),
                (mouth_x - 10, mouth_y - 5),
                (mouth_x, mouth_y - 7),
                (mouth_x + 10, mouth_y - 5),
                (mouth_x + 15, mouth_y),
                (mouth_x + 9, mouth_y + 14),
                (mouth_x, mouth_y + 18),
                (mouth_x - 9, mouth_y + 14)
            ]

            pygame.draw.polygon(surface, (8, 0, 0), maw_pts)
            pygame.draw.polygon(surface, (120, 15, 10), maw_pts, 1)

            for i in range(-2, 3):
                tx = mouth_x + i * 5

                pygame.draw.polygon(
                    surface,
                    (220, 210, 190),
                    [(tx - 1, mouth_y - 1), (tx + 1, mouth_y - 1), (tx, mouth_y + 5)]
                )

                pygame.draw.polygon(
                    surface,
                    (220, 210, 190),
                    [(tx - 1, mouth_y + 15), (tx + 1, mouth_y + 15), (tx, mouth_y + 10)]
                )
        else:
            pygame.draw.line(
                surface,
                (42, 8, 10),
                (mouth_x - 14, mouth_y + 3),
                (mouth_x + 14, mouth_y + 3),
                3
            )

    def _draw_channel_bar(self, surface, bx, by):
        if not self.activating or self.activated:
            return

        progress = self.channel_progress / self.channel_max
        bar_w, bar_h = 100, 6
        bar_x = bx + self.WIDTH // 2 - bar_w // 2
        bar_y = by - 30

        pygame.draw.rect(surface, (10, 5, 5), (bar_x - 2, bar_y - 2, bar_w + 4, bar_h + 4))
        pygame.draw.rect(surface, (40, 10, 10), (bar_x, bar_y, bar_w, bar_h))
        pygame.draw.rect(surface, (255, 80, 25), (bar_x, bar_y, int(bar_w * progress), bar_h))

        if self.is_final:
            shrine_text = "UNLEASHING THE CHAINS OF THE ANCIENT ONES"
            shrine_color = (170, 0, 0)
            shadow_color = (30, 0, 0)
            label_font = _get_font(9)
        else:
            shrine_text = "EXORCISING"
            shrine_color = (255, 180, 80)
            shadow_color = (10, 5, 5)
            label_font = _get_font(11)

        label = _get_text_surf(label_font, shrine_text, shrine_color)
        shadow = _get_text_surf(label_font, shrine_text, shadow_color)

        label_x = bar_x + bar_w // 2 - label.get_width() // 2
        label_y = bar_y - 16

        surface.blits(
            ((shadow, (label_x + ox, label_y + oy)) for ox, oy in self._TEXT_OFFSETS),
            doreturn=False
        )

        surface.blit(label, (label_x, label_y))

        if self.is_final:
            hint_font = _get_font(10)
            hint = _get_text_surf(hint_font, "DON'T DO IT", (190, 0, 0))
            hint_shadow = _get_text_surf(hint_font, "DON'T DO IT", (20, 0, 0))

            hint_x = bar_x + bar_w // 2 - hint.get_width() // 2
            hint_y = bar_y - 32

            surface.blits(
                ((hint_shadow, (hint_x + ox, hint_y + oy)) for ox, oy in self._TEXT_OFFSETS[:4]),
                doreturn=False
            )

            surface.blit(hint, (hint_x, hint_y))

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset - self.WIDTH // 2)

        if sx < -self.WIDTH * 2 or sx > SCREEN_WIDTH + self.WIDTH:
            return

        t = _ticks() * 0.001
        top_y = self.rect.y
        bx, by = sx, top_y

        progress = 1.0 if self.activated else (
            self.channel_progress / self.channel_max if self.activating else 0.0
        )

        self._draw_aura(surface, sx, top_y, t, progress)
        self._draw_souls(surface, sx, top_y, t, progress)

        body_color = (14, 7, 11) if not self.activated else (34, 7, 6)
        highlight = (52, 24, 52) if not self.activated else (112, 24, 15)

        body_pts = self._body_points(bx, by)

        pygame.draw.polygon(surface, body_color, body_pts)
        pygame.draw.polygon(surface, highlight, body_pts, 2)

        # Inner red heat once the exorcism breaks the seal.
        if self.activated:
            heat = 18 + int((math.sin(t * 4.0) + 1) * 8)

            pygame.draw.line(
                surface,
                (255, 80, 24),
                (bx + self.WIDTH // 2, by + 16),
                (bx + self.WIDTH // 2, by + self.HEIGHT - 22),
                1
            )

            glow = _get_two_circle_glow(
                (255, 65, 20, heat),
                (255, 180, 80, 30),
                16,
                5,
                surf_w=48
            )

            surface.blit(
                glow,
                (bx + self.WIDTH // 2 - 24, by + 48),
                special_flags=pygame.BLEND_RGBA_ADD
            )

        self._draw_cracks(surface, bx, by, progress)
        self._draw_all_eyes(surface, bx, by, t, progress)
        self._draw_horns_and_maw(surface, bx, by)
        self._draw_channel_bar(surface, bx, by)

def _build_particle_frames():
    frames = {"coin": [], "heart": None}
    for i in range(8):
        squash = abs(math.cos(i * math.pi / 8))
        w = max(2, int(14 * squash))
        h = 14
        surf = pygame.Surface((16, 16), pygame.SRCALPHA)
        ox = (16 - w) // 2
        oy = (16 - h) // 2
        pygame.draw.ellipse(surf, COIN_DARK, (ox - 1, oy - 1, w + 2, h + 2))
        pygame.draw.ellipse(surf, COIN_GOLD, (ox, oy, w, h))
        if w > 4:
            pygame.draw.ellipse(surf, (255, 240, 150), (ox + 1, oy + 1, max(2, w // 3), max(2, h // 3)))
        frames["coin"].append(surf.convert_alpha())
    size = 14
    heart_surf = pygame.Surface((size + 2, size + 2), pygame.SRCALPHA)
    r = size // 4
    pygame.draw.circle(heart_surf, HEART_RED, (r + 1, r + 2), r)
    pygame.draw.circle(heart_surf, HEART_RED, (size - r + 1, r + 2), r)
    pygame.draw.polygon(heart_surf, HEART_RED, [(1, r + 2), (size + 1, r + 2), (size // 2 + 1, size + 1)])
    pygame.draw.circle(heart_surf, (255, 200, 210), (r, r + 1), max(1, r // 2))
    frames["heart"] = heart_surf.convert_alpha()
    return frames


def _get_particle_frames():
    global _PARTICLE_FRAMES
    if _PARTICLE_FRAMES is None:
        _PARTICLE_FRAMES = _build_particle_frames()
    return _PARTICLE_FRAMES


class Particle:
    LIFETIME = 60

    def __init__(self, world_x, world_y, kind):
        self.world_x = world_x
        self.world_y = world_y
        self.kind = kind
        angle = random.uniform(-2.6, -0.6)
        speed = random.uniform(3.5, 6.0)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.life = 0
        self.dead = False
        self.spin_offset = random.randint(0, 7)
        self.spin_speed = random.uniform(0.5, 1.0)

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.25
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -20 or sx > SCREEN_WIDTH + 20:
            return
        frames = _get_particle_frames()
        img = frames["coin"][(int(self.life * self.spin_speed) + self.spin_offset) % 8] if self.kind == "coin" else frames["heart"]
        if self.life > self.LIFETIME * 0.66:
            t = (self.life - self.LIFETIME * 0.66) / (self.LIFETIME * 0.34)
            # OPT: avoid img.copy()+set_alpha() every frame per particle.
            # _get_faded caches faded surfaces in 16-step alpha buckets.
            img = _get_faded(img, max(0, int(255 * (1 - t))))
        surface.blit(img, (sx - img.get_width() // 2, sy - img.get_height() // 2))


class Spark:
    LIFETIME = 18

    def __init__(self, world_x, world_y, color=(255, 220, 100)):
        self.world_x = world_x
        self.world_y = world_y
        angle = random.uniform(0, math.tau)
        speed = random.uniform(2, 6)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed - 1
        self.life = 0
        self.color = color
        self.dead = False

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.3
        self.vx *= 0.92
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -10 or sx > SCREEN_WIDTH + 10:
            return
        t = 1 - self.life / self.LIFETIME
        size = max(1, int(4 * t))
        pygame.draw.circle(surface, self.color, (sx, sy), size)


def _get_damage_surf(text, color, size):
    key = (text, color, size)
    if key not in _DAMAGE_TEXT_CACHE:
        font = _get_font(size)
        main = _get_text_surf(font, text, color)
        outline = _get_text_surf(font, text, BLACK)
        _DAMAGE_TEXT_CACHE[key] = (main, outline)
        if len(_DAMAGE_TEXT_CACHE) > 256:
            _DAMAGE_TEXT_CACHE.pop(next(iter(_DAMAGE_TEXT_CACHE)))
    return _DAMAGE_TEXT_CACHE[key]


class DamageNumber:
    LIFETIME = 50

    def __init__(self, world_x, world_y, text, color=(255, 230, 80), big=False, size=None):
        self.world_x = world_x + random.randint(-15, 15)
        self.world_y = world_y
        self.vx = random.uniform(-0.6, 0.6)
        self.vy = -2.2
        self.text = text
        self.color = color
        self.big = big
        self.life = 0
        self.dead = False
        self.size = size if size is not None else (28 if big else 20)

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.08
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -50 or sx > SCREEN_WIDTH + 50:
            return
        main, outline = _get_damage_surf(self.text, self.color, self.size)
        t = self.life / self.LIFETIME
        alpha = int(255 * (1 - max(0, t - 0.5) * 2))
        if alpha < 255:
            # OPT: was main.copy()+set_alpha and outline.copy()+set_alpha every
            # frame per damage number. Cached now.
            main = _get_faded(main, alpha)
            outline = _get_faded(outline, alpha)
        ox = sx - main.get_width() // 2
        oy = sy
        # OPT: batch the 4 outline blits.
        surface.blits(
            ((outline, (ox - 1, oy)),
             (outline, (ox + 1, oy)),
             (outline, (ox, oy - 1)),
             (outline, (ox, oy + 1))),
            doreturn=False,
        )
        surface.blit(main, (ox, oy))

class PowerUp:
    _SPRITES = None
    _ICON_CACHE = {}
    _ICON_CACHE_LIMIT = 96

    # One canonical duration per buff.
    # Picking up the same buff again resets this timer instead of creating another HUD entry.
    DURATIONS = {
        "speed": 60 * 10,
        "damage": 60 * 10,
        "shield": 60 * 10,
        "fury": 60 * 30,
    }

    _TIMER_ATTRS = {
        "speed": "speed_boost_timer",
        "damage": "double_dmg_timer",
        "shield": "shield_timer",
        "fury": "fury_timer",
    }

    # Shared by dropped pickups and the HUD buff strip.
    _COLORS = {
        "speed": ((90, 230, 255), (10, 54, 92)),
        "damage": ((255, 70, 55), (95, 10, 18)),
        "shield": ((95, 210, 255), (18, 50, 105)),
        "fury": ((245, 110, 70), (115, 28, 18)),
    }

    DURATIONS = {
        "speed": 60 * 10,
        "damage": 60 * 10,
        "shield": 60 * 10,
        "fury": 60 * 30,
    }

    TIMER_ATTRS = {
        "speed": "speed_boost_timer",
        "damage": "double_dmg_timer",
        "shield": "shield_timer",
        "fury": "fury_timer",
    }

    @classmethod
    def _build_sprites(cls):
        cls._SPRITES = {
            kind: cls.get_icon(kind, 60, glow=True)
            for kind in ("speed", "damage", "shield", "fury")
        }

    @classmethod
    def get_icon(cls, kind, canvas_size=40, glow=False):
        """Return cached pixel-art power-up icon."""
        canvas_size = max(24, int(canvas_size))
        key = (kind, canvas_size, bool(glow))

        surf = cls._ICON_CACHE.get(key)
        if surf is not None:
            return surf

        fg, bg = cls._COLORS.get(kind, cls._COLORS["shield"])
        s = pygame.Surface((canvas_size, canvas_size), pygame.SRCALPHA)
        cx = cy = canvas_size // 2
        scale = canvas_size / 80.0

        # Drop glow / magic aura.
        if glow:
            for i in range(10, 0, -1):
                radius = int((20 + i * 2.0) * scale)
                alpha = max(4, int(40 - i * 3))
                pygame.draw.circle(s, (*fg, alpha), (cx, cy), radius)

        # Always keep a small identity glow so the HUD logo reads clearly.
        if kind == "damage":
            glow_color = (255, 35, 35)
        elif kind == "speed":
            glow_color = (80, 225, 255)
        elif kind == "shield":
            glow_color = (90, 210, 255)
        else:
            glow_color = fg

        for i in range(4, 0, -1):
            radius = int((14 + i * 2) * scale)
            alpha = int(16 if glow else 9)
            pygame.draw.circle(s, (*glow_color, alpha), (cx, cy), radius)

        pixel_icon = cls._build_pixel_symbol(kind)
        icon_size = int(canvas_size * 0.88)
        icon = pygame.transform.scale(pixel_icon, (icon_size, icon_size)).convert_alpha()

        s.blit(
            icon,
            (
                canvas_size // 2 - icon_size // 2,
                canvas_size // 2 - icon_size // 2,
            )
        )

        surf = s.convert_alpha()

        if len(cls._ICON_CACHE) >= cls._ICON_CACHE_LIMIT:
            cls._ICON_CACHE.pop(next(iter(cls._ICON_CACHE)))

        cls._ICON_CACHE[key] = surf
        return surf

    @staticmethod
    def _build_pixel_symbol(kind):
        """Draws the logo at 32x32, then get_icon scales it up with hard pixel edges."""
        px_size = 32
        s = pygame.Surface((px_size, px_size), pygame.SRCALPHA)

        def px(x, y, w, h, color):
            pygame.draw.rect(s, color, (int(x), int(y), int(w), int(h)))

        if kind == "speed":
            # Blue winged boot.
            dark = (3, 22, 54)
            mid = (14, 105, 210)
            bright = (45, 205, 255)
            hi = (205, 250, 255)
            sole = (2, 14, 36)

            wing_dark = (90, 100, 115)
            wing_mid = (180, 200, 215)
            wing_hi = (245, 250, 255)

            # Wing.
            px(1, 8, 12, 3, wing_dark)
            px(0, 11, 16, 3, wing_dark)
            px(0, 14, 11, 3, wing_dark)
            px(3, 17, 9, 3, wing_dark)

            px(2, 9, 10, 2, wing_hi)     # top feather: longer
            px(0, 12, 15, 2, wing_mid)   # second feather: longest
            px(1, 15, 8, 2, wing_hi)     # third feather: shorter
            px(4, 18, 7, 2, wing_mid)    # bottom feather: shortest

            # Boot shaft.
            px(12, 6, 9, 3, dark)
            px(11, 9, 11, 10, dark)
            px(14, 8, 7, 10, mid)
            px(15, 9, 5, 4, bright)
            px(16, 10, 3, 2, hi)

            # Heel / ankle.
            px(8, 17, 12, 5, dark)
            px(10, 18, 10, 3, mid)
            px(11, 18, 6, 1, hi)

            # Foot / toe.
            px(7, 21, 18, 6, dark)
            px(9, 22, 15, 4, mid)
            px(21, 21, 5, 5, bright)
            px(22, 22, 3, 2, hi)

            # Sole.
            px(7, 27, 18, 2, sole)
            px(22, 26, 4, 2, sole)

        elif kind == "damage":
            # Upright straight sword with red power glow.
            glow = (255, 25, 25, 80)
            glow_core = (255, 70, 45, 135)

            outline = (18, 10, 28)

            steel_shadow = (95, 105, 125)
            steel = (190, 200, 220)
            steel_light = (245, 248, 255)

            gold_dark = (130, 82, 18)
            gold = (235, 180, 45)
            gold_light = (255, 230, 95)

            grip_dark = (70, 36, 22)
            grip = (130, 72, 32)

            # Red glow behind the sword.
            pygame.draw.polygon(
                s,
                glow,
                [
                    (16, 0),
                    (25, 9),
                    (22, 23),
                    (20, 31),
                    (12, 31),
                    (10, 23),
                    (7, 9),
                ]
            )
            pygame.draw.rect(s, glow_core, (11, 3, 10, 21))

            # Blade black outline.
            pygame.draw.polygon(
                s,
                outline,
                [
                    (16, 0),   # tip
                    (23, 7),
                    (21, 21),
                    (11, 21),
                    (9, 7),
                ]
            )

            # Blade fill.
            pygame.draw.polygon(
                s,
                steel_shadow,
                [
                    (16, 2),
                    (21, 7),
                    (19, 20),
                    (13, 20),
                    (11, 7),
                ]
            )

            # Left bright blade face.
            pygame.draw.polygon(
                s,
                steel_light,
                [
                    (16, 3),
                    (16, 20),
                    (13, 20),
                    (12, 7),
                ]
            )

            # Right blade face.
            pygame.draw.polygon(
                s,
                steel,
                [
                    (17, 3),
                    (20, 7),
                    (19, 20),
                    (17, 20),
                ]
            )

            # Center ridge.
            px(16, 4, 1, 16, (220, 225, 240))

            # Crossguard outline.
            px(5, 20, 22, 5, outline)
            px(7, 18, 4, 4, outline)
            px(21, 18, 4, 4, outline)

            # Crossguard gold.
            px(7, 21, 18, 3, gold_dark)
            px(8, 20, 16, 2, gold)
            px(9, 20, 5, 1, gold_light)
            px(18, 20, 5, 1, gold_light)

            # Handle outline.
            px(13, 24, 6, 7, outline)

            # Handle fill.
            px(15, 24, 2, 7, grip_dark)
            px(14, 25, 4, 5, grip)

            # Pommel outline.
            px(10, 28, 12, 4, outline)

            # Pommel gold.
            px(12, 28, 8, 3, gold_dark)
            px(13, 28, 6, 2, gold)
            px(13, 28, 3, 1, gold_light)

        elif kind == "shield":
            # Blue pixel kite shield.
            outline = (22, 26, 38)
            rim_dark = (68, 78, 92)
            rim = (130, 145, 160)
            blue_dark = (0, 120, 190)
            blue = (25, 205, 240)
            blue_hi = (105, 245, 255)
            shine = (220, 255, 255)

            # Outer dark shield rows.
            rows = [
                (14, 3, 4),
                (11, 4, 10),
                (9, 5, 14),
                (7, 7, 18),
                (6, 10, 20),
                (7, 14, 18),
                (8, 18, 16),
                (10, 22, 12),
                (12, 25, 8),
                (14, 28, 4),
            ]

            for x, y, w in rows:
                px(x, y, w, 3, outline)

            # Rim.
            rim_rows = [
                (13, 5, 6),
                (10, 6, 12),
                (8, 8, 16),
                (8, 11, 16),
                (9, 15, 14),
                (10, 19, 12),
                (12, 23, 8),
                (14, 26, 4),
            ]

            for x, y, w in rim_rows:
                px(x, y, w, 3, rim_dark)

            inner_rows = [
                (14, 6, 4),
                (11, 8, 10),
                (9, 10, 14),
                (9, 13, 14),
                (10, 16, 12),
                (11, 19, 10),
                (12, 22, 8),
                (14, 25, 4),
            ]

            for x, y, w in inner_rows:
                px(x, y, w, 3, blue_dark)

            core_rows = [
                (15, 7, 3),
                (12, 9, 8),
                (10, 11, 12),
                (10, 14, 12),
                (11, 17, 10),
                (12, 20, 8),
                (13, 23, 6),
            ]

            for x, y, w in core_rows:
                px(x, y, w, 3, blue)

            # Highlights and metallic edge.
            px(11, 9, 3, 11, blue_hi)
            px(14, 7, 2, 4, shine)
            px(19, 8, 2, 14, rim)
            px(15, 5, 2, 22, (160, 245, 255, 150))

        elif kind == "fury":
            # Keep fury as a pixel flame in case you use it later.
            outline = (80, 15, 10)
            red = (230, 45, 28)
            orange = (255, 130, 45)
            yellow = (255, 230, 100)

            flame_rows = [
                (15, 4, 3),
                (13, 7, 6),
                (11, 10, 10),
                (9, 14, 14),
                (8, 18, 16),
                (10, 22, 12),
                (13, 25, 6),
            ]

            for x, y, w in flame_rows:
                px(x - 1, y - 1, w + 2, 4, outline)

            for x, y, w in flame_rows:
                px(x, y, w, 3, red)

            px(14, 9, 5, 13, orange)
            px(12, 16, 8, 6, orange)
            px(15, 15, 3, 8, yellow)

        return s.convert_alpha()

    def __init__(self, world_x, world_y, kind):
        if PowerUp._SPRITES is None:
            PowerUp._build_sprites()

        self.world_x = world_x
        self.world_y = world_y
        self.kind = kind
        self.collected = False
        self.spawn_tick = pygame.time.get_ticks()
        self.bob_offset = 0
        self.size = 22
        self.rect = pygame.Rect(
            world_x - self.size // 2,
            world_y - self.size // 2,
            self.size,
            self.size
        )

        self.sprite = PowerUp._SPRITES.get(kind)
        if self.sprite is None:
            self.sprite = PowerUp.get_icon(kind, 60, glow=True)

        if kind == "speed":
            self.collect_message = "+60% SPEED"
        elif kind == "damage":
            self.collect_message = "+100% DAMAGE"
        elif kind == "shield":
            self.collect_message = "-50% DAMAGE TAKEN"
        elif kind == "fury":
            self.collect_message = "+25% FURY"
        else:
            self.collect_message = "POWER UP"

    def colors(self):
        return self._COLORS.get(self.kind, self._COLORS["shield"])

    def update(self):
        self.bob_offset = math.sin((_ticks() - self.spawn_tick) * 0.005) * 6
        self.rect.x = self.world_x - self.size // 2
        self.rect.y = int(self.world_y - self.size // 2 + self.bob_offset)

    def check_collect(self, player):
        if self.collected or not self.rect.colliderect(player.rect):
            return False

        timer_attr = self.TIMER_ATTRS.get(self.kind)
        duration = self.DURATIONS.get(self.kind)

        if timer_attr is not None and duration is not None:
            # Same buff picked up again resets its one real timer.
            # It does not create another HUD entry.
            setattr(player, timer_attr, duration)

        self.collected = True
        return True

    def draw(self, surface, scroll_offset):
        sx = self.world_x - scroll_offset
        if sx < -50 or sx > SCREEN_WIDTH + 50:
            return

        w = self.sprite.get_width()
        surface.blit(
            self.sprite,
            (int(sx - w // 2), int(self.world_y - w // 2 + self.bob_offset))
        )


class LavaParticle:
    LIFETIME = 90

    def __init__(self, world_x, world_y, intensity=1.0):
        self.world_x = world_x
        self.world_y = world_y
        self.vx = random.uniform(-3, 3)
        self.vy = random.uniform(-12, -7) * intensity
        self.life = 0
        self.dead = False
        self.size = random.randint(3, 7)
        self.color = random.choice([(255, 200, 60), (255, 140, 40), (255, 80, 30), (220, 50, 20)])

    def update(self):
        self.world_x += self.vx
        self.world_y += self.vy
        self.vy += 0.45
        self.life += 1
        if self.life >= self.LIFETIME:
            self.dead = True

    def draw(self, surface, scroll_offset):
        sx = int(self.world_x - scroll_offset)
        sy = int(self.world_y)
        if sx < -20 or sx > SCREEN_WIDTH + 20:
            return
        t = 1 - self.life / self.LIFETIME
        size = max(2, int(self.size * t))
        # OPT: cached. Original: Surface(size*4,size*4) outer alpha=80 inner alpha=220.
        # Color is one of 4 fixed values; size shrinks 7→2 over lifetime, so the
        # cache holds at most 4 colors × 6 sizes = 24 entries total.
        c = self.color
        glow = _get_two_circle_glow(
            (c[0], c[1], c[2], 80), (c[0], c[1], c[2], 220),
            size * 2, size, surf_w=size * 4,
        )
        surface.blit(glow, (sx - size * 2, sy - size * 2), special_flags=pygame.BLEND_RGBA_ADD)
